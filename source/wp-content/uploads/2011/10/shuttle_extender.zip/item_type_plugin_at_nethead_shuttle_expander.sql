set define off
set verify off
set feedback off
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
begin wwv_flow.g_import_in_progress := true; end; 
/
 
--       AAAA       PPPPP   EEEEEE  XX      XX
--      AA  AA      PP  PP  EE       XX    XX
--     AA    AA     PP  PP  EE        XX  XX
--    AAAAAAAAAA    PPPPP   EEEE       XXXX
--   AA        AA   PP      EE        XX  XX
--  AA          AA  PP      EE       XX    XX
--  AA          AA  PP      EEEEEE  XX      XX
prompt  Set Credentials...
 
begin
 
  -- Assumes you are running the script connected to SQL*Plus as the Oracle user APEX_040100 or as the owner (parsing schema) of the application.
  wwv_flow_api.set_security_group_id(p_security_group_id=>nvl(wwv_flow_application_install.get_workspace_id,17151373012351605525));
 
end;
/

begin wwv_flow.g_import_in_progress := true; end;
/
begin 

select value into wwv_flow_api.g_nls_numeric_chars from nls_session_parameters where parameter='NLS_NUMERIC_CHARACTERS';

end;

/
begin execute immediate 'alter session set nls_numeric_characters=''.,''';

end;

/
begin wwv_flow.g_browser_language := 'en'; end;
/
prompt  Check Compatibility...
 
begin
 
-- This date identifies the minimum version required to import this file.
wwv_flow_api.set_version(p_version_yyyy_mm_dd=>'2011.02.12');
 
end;
/

prompt  Set Application ID...
 
begin
 
   -- SET APPLICATION ID
   wwv_flow.g_flow_id := nvl(wwv_flow_application_install.get_application_id,11202);
   wwv_flow_api.g_id_offset := nvl(wwv_flow_application_install.get_offset,0);
null;
 
end;
/

prompt  ...plugins
--
--application/shared_components/plugins/item_type/at_nethead_shuttle_expander
 
begin
 
wwv_flow_api.create_plugin (
  p_id => 17825624632347047270 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_type => 'ITEM TYPE'
 ,p_name => 'AT_NETHEAD_SHUTTLE_EXPANDER'
 ,p_display_name => 'Shuttle Extender'
 ,p_image_prefix => '#PLUGIN_PREFIX#'
 ,p_plsql_code => 
'/*'||unistr('\000a')||
'    APEX Plugin: Shuttle Extender'||unistr('\000a')||
'    '||unistr('\000a')||
'    Copyright (C) 2011 by nethead Antipa & Zimmermann GesbR (http://www.nethead.at/)'||unistr('\000a')||
'    written by Damien Antipa <damien.antipa@nethead.at> http://damien.antipa.at'||unistr('\000a')||
''||unistr('\000a')||
'    This program is free software: you can redistribute it and/or modify'||unistr('\000a')||
'    it under the terms of the GNU General Public License as published by'||unistr('\000a')||
'    the Free Software Foundation, either versi'||
'on 3 of the License, or'||unistr('\000a')||
'    (at your option) any later version.'||unistr('\000a')||
''||unistr('\000a')||
'    This program is distributed in the hope that it will be useful,'||unistr('\000a')||
'    but WITHOUT ANY WARRANTY; without even the implied warranty of'||unistr('\000a')||
'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the'||unistr('\000a')||
'    GNU General Public License for more details.'||unistr('\000a')||
''||unistr('\000a')||
'    You should have received a copy of the GNU General Public License'||unistr('\000a')||
'    along with'||
' this program.  If not, see <http://www.gnu.org/licenses/>.'||unistr('\000a')||
'*/'||unistr('\000a')||
'function nethead_shuttle_ext_render('||unistr('\000a')||
'  p_item in apex_plugin.t_page_item, '||unistr('\000a')||
'  p_plugin in apex_plugin.t_plugin, '||unistr('\000a')||
'  p_value in varchar2, '||unistr('\000a')||
'  p_is_readonly in boolean,'||unistr('\000a')||
'  p_is_printer_friendly in boolean) '||unistr('\000a')||
'  return apex_plugin.t_page_item_render_result'||unistr('\000a')||
'is'||unistr('\000a')||
'  l_name varchar2(30);'||unistr('\000a')||
'  l_result apex_plugin.t_page_item_render_result;'||unistr('\000a')||
'begin'||unistr('\000a')||
'  l_nam'||
'e := apex_plugin.get_input_name_for_page_item(p_is_multi_value=>false);'||unistr('\000a')||
'  htp.p(''<input type="text" name="''||l_name||''" id="''||p_item.name||''"''||''value="''||htf.escape_sc(p_value)||''" size="''||p_item.element_width||''"'||unistr('\000a')||
'    ''||''maxlength="''||p_item.element_max_length||''" ''||p_item.element_attributes||'' /><a class="plugin-shuttle-extander-trigger" res="''|| p_item.name ||''" ref="''|| p_item.attribute_01'||
' ||''" href="#"><img src="''|| p_plugin.file_prefix ||''plus-icon.png" alt="''|| p_item.plain_label ||''" /></a>'');'||unistr('\000a')||
'    apex_css.add_file(p_name => ''plugin.shuttle.extender'', p_directory => p_plugin.file_prefix, p_version => null);'||unistr('\000a')||
'    apex_javascript.add_library(p_name => ''plugin.shuttle.extender.min'', p_directory => p_plugin.file_prefix, p_version => null);'||unistr('\000a')||
'  htp.p(''<script type="text/javascript">$(d'||
'ocument).ready(function(){$(".plugin-shuttle-extander-trigger").pluginShuttleExtender();});</script>'');'||unistr('\000a')||
'  return l_result;'||unistr('\000a')||
'end;'
 ,p_render_function => 'nethead_shuttle_ext_render'
 ,p_standard_attributes => 'VISIBLE:ELEMENT:WIDTH:ELEMENT_OPTION'
 ,p_substitute_attributes => true
 ,p_help_text => '<p>'||unistr('\000a')||
'	just set a shuttle component in the page item settings and you will have a field to modify the shuttle on the fly.</p>'||unistr('\000a')||
''
 ,p_version_identifier => '1.0'
 ,p_about_url => 'http://www.nethead.at'
 ,p_plugin_comment => '/*'||unistr('\000a')||
'    APEX Plugin: Shuttle Extender'||unistr('\000a')||
'    '||unistr('\000a')||
'    Copyright (C) 2011 by nethead Antipa & Zimmermann GesbR (http://www.nethead.at/)'||unistr('\000a')||
'    written by Damien Antipa <damien.antipa@nethead.at> http://damien.antipa.at'||unistr('\000a')||
''||unistr('\000a')||
'    This program is free software: you can redistribute it and/or modify'||unistr('\000a')||
'    it under the terms of the GNU General Public License as published by'||unistr('\000a')||
'    the Free Software Foundation, either version 3 of the License, or'||unistr('\000a')||
'    (at your option) any later version.'||unistr('\000a')||
''||unistr('\000a')||
'    This program is distributed in the hope that it will be useful,'||unistr('\000a')||
'    but WITHOUT ANY WARRANTY; without even the implied warranty of'||unistr('\000a')||
'    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the'||unistr('\000a')||
'    GNU General Public License for more details.'||unistr('\000a')||
''||unistr('\000a')||
'    You should have received a copy of the GNU General Public License'||unistr('\000a')||
'    along with this program.  If not, see <http://www.gnu.org/licenses/>.'||unistr('\000a')||
'*/'
  );
wwv_flow_api.create_plugin_attribute (
  p_id => 17825632647584051604 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 17825624632347047270 + wwv_flow_api.g_id_offset
 ,p_attribute_scope => 'COMPONENT'
 ,p_attribute_sequence => 1
 ,p_display_sequence => 10
 ,p_prompt => 'Shuttle Item'
 ,p_attribute_type => 'PAGE ITEM'
 ,p_is_required => true
 ,p_is_translatable => false
  );
null;
 
end;
/

 
begin
 
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '2F2A0A202020204150455820506C7567696E3A2053687574746C6520457874656E6465720A202020200A20202020436F70797269676874202843292032303131206279206E65746865616420416E746970612026205A696D6D65726D616E6E2047657362';
wwv_flow_api.g_varchar2_table(2) := '522028687474703A2F2F7777772E6E6574686561642E61742F290A202020207772697474656E2062792044616D69656E20416E74697061203C64616D69656E2E616E74697061406E6574686561642E61743E20687474703A2F2F64616D69656E2E616E74';
wwv_flow_api.g_varchar2_table(3) := '6970612E61740A0A20202020546869732070726F6772616D206973206672656520736F6674776172653A20796F752063616E2072656469737472696275746520697420616E642F6F72206D6F646966790A20202020697420756E64657220746865207465';
wwv_flow_api.g_varchar2_table(4) := '726D73206F662074686520474E552047656E6572616C205075626C6963204C6963656E7365206173207075626C69736865642062790A20202020746865204672656520536F66747761726520466F756E646174696F6E2C20656974686572207665727369';
wwv_flow_api.g_varchar2_table(5) := '6F6E2033206F6620746865204C6963656E73652C206F720A2020202028617420796F7572206F7074696F6E2920616E79206C617465722076657273696F6E2E0A0A20202020546869732070726F6772616D20697320646973747269627574656420696E20';
wwv_flow_api.g_varchar2_table(6) := '74686520686F706520746861742069742077696C6C2062652075736566756C2C0A2020202062757420574954484F555420414E592057415252414E54593B20776974686F7574206576656E2074686520696D706C6965642077617272616E7479206F660A';
wwv_flow_api.g_varchar2_table(7) := '202020204D45524348414E544142494C495459206F72204649544E45535320464F52204120504152544943554C415220505552504F53452E2020536565207468650A20202020474E552047656E6572616C205075626C6963204C6963656E736520666F72';
wwv_flow_api.g_varchar2_table(8) := '206D6F72652064657461696C732E0A0A20202020596F752073686F756C642068617665207265636569766564206120636F7079206F662074686520474E552047656E6572616C205075626C6963204C6963656E73650A20202020616C6F6E672077697468';
wwv_flow_api.g_varchar2_table(9) := '20746869732070726F6772616D2E20204966206E6F742C20736565203C687474703A2F2F7777772E676E752E6F72672F6C6963656E7365732F3E2E0A2A2F0A2866756E6374696F6E2861297B612E666E2E657874656E64287B706C7567696E5368757474';
wwv_flow_api.g_varchar2_table(10) := '6C65457874656E6465723A66756E6374696F6E2862297B76617220633D7B7D3B76617220623D612E657874656E6428632C62293B72657475726E20746869732E656163682866756E6374696F6E28297B76617220633D623B76617220643D612874686973';
wwv_flow_api.g_varchar2_table(11) := '293B642E62696E642822636C69636B222C66756E6374696F6E2862297B622E70726576656E7444656661756C7428293B76617220633D61282223222B642E6174747228227265732229293B76617220653D61282223222B642E6174747228227265662229';
wwv_flow_api.g_varchar2_table(12) := '293B76617220663D652E66696E64282273656C6563742E73687574746C655F6C65667422293B76617220673D652E66696E64282273656C6563742E73687574746C655F726967687422293B662E66696E6428276F7074696F6E5B76616C75653D22272B63';
wwv_flow_api.g_varchar2_table(13) := '2E76616C28292B27225D27292E72656D6F766528293B69662821672E66696E6428276F7074696F6E5B76616C75653D22272B632E76616C28292B27225D27292E6C656E67746829672E617070656E64286128223C6F7074696F6E3E222C7B76616C75653A';
wwv_flow_api.g_varchar2_table(14) := '632E76616C28297D292E7465787428632E76616C282929293B632E76616C282222297D297D297D7D297D29286A517565727929';
null;
 
end;
/

 
begin
 
wwv_flow_api.create_plugin_file (
  p_id => 17777367110668520832 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 17825624632347047270 + wwv_flow_api.g_id_offset
 ,p_file_name => 'plugin.shuttle.extender.min.js'
 ,p_mime_type => 'application/x-javascript'
 ,p_file_content => wwv_flow_api.g_varchar2_table
  );
null;
 
end;
/

 
begin
 
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '89504E470D0A1A0A0000000D49484452000000100000001008060000001FF3FF61000001B24944415478DA6364C002FA8FF0FD47172BB4F9C4884D2D232E03324C9F333C6298CD20C790CA30E3B424E906A82B39327CF9FA9241804F96E1EAED9DA41BA0';
wwv_flow_api.g_varchar2_table(2) := '226FCDF0F5DB1B063E5E49869BF70E906640EF2181FF8AB2FA0C3F7F7D66E0E61465B87DFF2443B1FD07EC0674ED13FE0F338A11C882859EBC8C32C3EFBF3F1938D9F918EE3EB88662234C4D99D35B46C6F65DE2FF0BECEF81030C064001B7EEBE15C3DF';
wwv_flow_api.g_varchar2_table(3) := 'BF7F189898981982958E63C84F38A8C450E9F69291B1799BF47F257959865FFFDF83CD86B88211C545C8B682D86C4C620C771FDE63A8F57ACAC858BF51F1BF92122FC39F7F5F9054C2743342C5A0C68043E13F033B9308C3EDBBAF191AFDEF333256AF51';
wwv_flow_api.g_varchar2_table(4) := 'FD8FEA39460646A06679E55F50DBFF333CB8CB0E51F09F01C92D0C0CAD21B719B1866CF90AADFF8A6A1F201CA0FA07B705183A22AEA1A86DDDA2275BED73E93156034A96E8FD57D47809B61D04EEDD9060E889B9447C3A285C60F45F59FB21D8EB200577';
wwv_flow_api.g_varchar2_table(5) := 'AFCB33F4C79F23DE80FC7926FF2D2C39E0FC13C77F304C4C3A43B401A240035EA10B020D10F04866FF0A643201F19F1D737FFEC3668038100B00313710F3A1C9DD82D2CF900501A150A61100BDA5EB0000000049454E44AE426082';
null;
 
end;
/

 
begin
 
wwv_flow_api.create_plugin_file (
  p_id => 17825727946176178488 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 17825624632347047270 + wwv_flow_api.g_id_offset
 ,p_file_name => 'plus-icon.png'
 ,p_mime_type => 'image/png'
 ,p_file_content => wwv_flow_api.g_varchar2_table
  );
null;
 
end;
/

 
begin
 
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '2E706C7567696E2D73687574746C652D657874616E6465722D74726967676572207B0D0A09646973706C61793A20696E6C696E652D626C6F636B3B0D0A096865696768743A20313670783B0D0A0977696474683A20313670783B0D0A096D617267696E3A';
wwv_flow_api.g_varchar2_table(2) := '2030203020327078203270783B0D0A09766572746963616C2D616C69676E3A206D6964646C653B0D0A7D';
null;
 
end;
/

 
begin
 
wwv_flow_api.create_plugin_file (
  p_id => 17826231155256675665 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 17825624632347047270 + wwv_flow_api.g_id_offset
 ,p_file_name => 'plugin.shuttle.extender.css'
 ,p_mime_type => 'text/css'
 ,p_file_content => wwv_flow_api.g_varchar2_table
  );
null;
 
end;
/

commit;
begin 
execute immediate 'begin dbms_session.set_nls( param => ''NLS_NUMERIC_CHARACTERS'', value => '''''''' || replace(wwv_flow_api.g_nls_numeric_chars,'''''''','''''''''''') || ''''''''); end;';
end;
/
set verify on
set feedback on
prompt  ...done
