/*
    APEX Plugin: Shuttle Extender
    
    Copyright (C) 2011 by nethead Antipa & Zimmermann GesbR (http://www.nethead.at/)
    written by Damien Antipa <damien.antipa@nethead.at> http://damien.antipa.at

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
(function($){
	$.fn.extend({
		pluginShuttleExtender: function(options) {
			var defaults = {};
			var options =  $.extend(defaults, options);
			
			return this.each(function() {
				var o = options;
				var $elem = $(this)
				
				$elem.bind('click', function(e) {
					e.preventDefault();
					var $source = $('#' + $elem.attr('res'));
					var $target = $('#' + $elem.attr('ref'));
					var $target_left = $target.find('select.shuttle_left');
					var $target_right = $target.find('select.shuttle_right');
					
					$target_left.find('option[value="'+ $source.val() +'"]').remove();
					if(!$target_right.find('option[value="'+ $source.val() +'"]').length)
						$target_right.append($('<option>', { value : $source.val() }).text($source.val()));
					$source.val('');
				});
			});
		}
	});   
})(jQuery);