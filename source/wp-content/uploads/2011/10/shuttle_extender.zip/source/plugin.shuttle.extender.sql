/*
    APEX Plugin: Shuttle Extender
    
    Copyright (C) 2011 by nethead Antipa & Zimmermann GesbR (http://www.nethead.at/)
    written by Damien Antipa <damien.antipa@nethead.at> http://damien.antipa.at

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
function nethead_shuttle_ext_render(
  p_item in apex_plugin.t_page_item, 
  p_plugin in apex_plugin.t_plugin, 
  p_value in varchar2, 
  p_is_readonly in boolean,
  p_is_printer_friendly in boolean) 
  return apex_plugin.t_page_item_render_result
is
  l_name varchar2(30);
  l_result apex_plugin.t_page_item_render_result;
begin
  l_name := apex_plugin.get_input_name_for_page_item(p_is_multi_value=>false);
  htp.p('<input type="text" name="'||l_name||'" id="'||p_item.name||'"'||'value="'||htf.escape_sc(p_value)||'" size="'||p_item.element_width||'"
    '||'maxlength="'||p_item.element_max_length||'" '||p_item.element_attributes||' /><a class="plugin-shuttle-extander-trigger" res="'|| p_item.name ||'" ref="'|| p_item.attribute_01 ||'" href="#"><img src="'|| p_plugin.file_prefix ||'plus-icon.png" alt="'|| p_item.plain_label ||'" /></a>');
    apex_css.add_file(p_name => 'plugin.shuttle.extender', p_directory => p_plugin.file_prefix, p_version => null);
    apex_javascript.add_library(p_name => 'plugin.shuttle.extender.min', p_directory => p_plugin.file_prefix, p_version => null);
  htp.p('<script type="text/javascript">$(document).ready(function(){$(".plugin-shuttle-extander-trigger").pluginShuttleExtender();});</script>');
  return l_result;
end;