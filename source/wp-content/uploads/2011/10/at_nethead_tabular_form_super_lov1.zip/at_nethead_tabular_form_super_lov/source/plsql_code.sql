FUNCTION hash (
   p_value IN VARCHAR2
)
   
   RETURN VARCHAR2
   
IS

   l_retval VARCHAR2(32);
   l_salt   VARCHAR2(100) := 'A!7&s-$3lK*9N#a20Q1p68(w5z"4o02%';

BEGIN

   IF p_value IS NOT NULL
   THEN
      l_retval := RAWTOHEX(utl_raw.cast_to_raw(dbms_obfuscation_toolkit.md5(
         input_string => p_value || l_salt
      )));
   END IF;
   
   RETURN l_retval;

END hash;

PROCEDURE store_validation_hash(
   p_item_name IN VARCHAR2,
   p_hash      IN VARCHAR2
)

IS

   l_collection_name VARCHAR2(50) := 'SBIP_SUPER_LOV_VALIDATION_VALUES';
   l_seq_id          NUMBER;
   
   FUNCTION existing_seq_id 
   
      RETURN NUMBER
   
   IS
   
      l_retval NUMBER;
   
   BEGIN
   
      SELECT seq_id
      INTO l_retval
      FROM apex_collections
      WHERE collection_name = l_collection_name
         AND c001 = p_item_name;
      
      RETURN l_retval;
   
   EXCEPTION
   
      WHEN NO_DATA_FOUND
      THEN
         RETURN l_retval;
   
   END existing_seq_id;

BEGIN

   IF NOT apex_collection.collection_exists(
      p_collection_name => l_collection_name
   )
   THEN
      apex_collection.create_collection(
         p_collection_name => l_collection_name
      );
   END IF;
   
   l_seq_id := existing_seq_id();
   
   IF l_seq_id IS NOT NULL
   THEN
      apex_collection.update_member_attribute(
         p_collection_name => l_collection_name,
         p_seq             => l_seq_id,
         p_attr_number     => 2,
         p_attr_value      => p_hash
      );
   ELSE
      apex_collection.add_member(
         p_collection_name => l_collection_name,
         p_c001            => p_item_name,
         p_c002            => p_hash
      );
   END IF;

END store_validation_hash;

FUNCTION report_headers_js_array(
   p_sql_statement IN VARCHAR2,
   p_item_name     IN VARCHAR2
)

   RETURN VARCHAR2

IS

   l_column_value_list APEX_PLUGIN_UTIL.T_COLUMN_VALUE_LIST2;
   l_retval            VARCHAR2(32767);

BEGIN

   l_column_value_list := apex_plugin_util.get_data2(
      p_sql_statement  => 'SELECT * FROM ( ' || p_sql_statement || ' ) WHERE 1=2', 
      p_min_columns    => 2, 
      p_max_columns    => 100, 
      p_component_name => p_item_name,
      p_first_row      => 1,
      p_max_rows       => 1
   );  
   
   l_retval := '[''';
   
   FOR x IN 1 .. l_column_value_list.count
   LOOP
      l_retval := l_retval || apex_javascript.escape(l_column_value_list(x).name) || ''',''';
   END LOOP;
   
   l_retval := RTRIM(l_retval, ''',''') || ''']';

   RETURN l_retval;   

END report_headers_js_array;

FUNCTION sbip_super_lov_render (
   p_item                IN APEX_PLUGIN.T_PAGE_ITEM,
   p_plugin              IN APEX_PLUGIN.T_PLUGIN,
   p_value               IN VARCHAR2,
   p_is_readonly         IN BOOLEAN,
   p_is_printer_friendly IN BOOLEAN 
)

   RETURN APEX_PLUGIN.T_PAGE_ITEM_RENDER_RESULT
   
IS

   l_retval             APEX_PLUGIN.T_PAGE_ITEM_RENDER_RESULT;
   l_name               VARCHAR2(30);
   l_validate_value     VARCHAR2(1) := NVL(p_item.attribute_01, 'Y');
   l_dialog_title       VARCHAR2(32767) := NVL(p_item.attribute_02, p_item.plain_label);
   l_dis_ret_cols       VARCHAR2(10) := NVL(p_item.attribute_03, '2,1');
   l_searchable_cols    VARCHAR2(32767) := p_item.attribute_04;
   l_hidden_cols        VARCHAR2(32767) := p_item.attribute_05;
   l_map_from_cols      VARCHAR2(32767) := p_item.attribute_06;
   l_map_to_items       VARCHAR2(32767) := p_item.attribute_07;
   l_no_data_found_msg  VARCHAR2(32767) := NVL(p_item.attribute_08, 'Your search returned no results.');
   l_max_rows_per_page  PLS_INTEGER := NVL(p_item.attribute_09, 15);
   l_search_type        VARCHAR2(32767) := NVL(p_plugin.attribute_01, apex_plugin_util.c_search_contains_ignore);
   l_jqueryui_theme     VARCHAR2(30) := p_plugin.attribute_02;
   l_loading_image_type VARCHAR2(30) := NVL(p_plugin.attribute_03, 'DEFAULT');
   l_loading_image_def  VARCHAR2(30) := NVL(p_plugin.attribute_04, 'bar');
   l_loading_image_cust VARCHAR2(32767) := NVL(p_plugin.attribute_05, apex_application.g_image_prefix || 'processing3.gif');
   l_effects_speed      NUMBER := NVL(p_plugin.attribute_06, 400);
   l_clear_protection   VARCHAR2(1) := NVL(p_plugin.attribute_07, 'Y');
   l_return_col_num     PLS_INTEGER;
   l_display_col_num    PLS_INTEGER;
   l_loading_image_src  VARCHAR2(32767);
   l_display_value      VARCHAR2(32767);
   l_onload_code        VARCHAR2(32767);
   l_crlf               CHAR(2) := CHR(13)||CHR(10);
   l_table_column       VARCHAR2(30) := p_item.attribute_11;
BEGIN

   IF apex_application.g_debug
   THEN
      apex_plugin_util.debug_page_item (
         p_plugin              => p_plugin,
         p_page_item           => p_item,
         p_value               => p_value,
         p_is_readonly         => p_is_readonly,
         p_is_printer_friendly => p_is_printer_friendly
      );
   END IF;
   
   l_display_col_num := SUBSTR(l_dis_ret_cols, 1, INSTR(l_dis_ret_cols, ',') - 1);
   l_return_col_num := SUBSTR(l_dis_ret_cols, INSTR(l_dis_ret_cols, ',') + 1);

   l_name := apex_plugin.get_input_name_for_page_item(FALSE);
   
   IF l_loading_image_type = 'DEFAULT'
   THEN
      l_loading_image_src := p_plugin.file_prefix || l_loading_image_def || '.gif';
   ELSE
      l_loading_image_src := REPLACE(l_loading_image_cust, '#IMAGE_PREFIX#', apex_application.g_image_prefix);
      l_loading_image_src := REPLACE(l_loading_image_src, '#PLUGIN_PREFIX#', p_plugin.file_prefix);
   END IF;
   
   l_display_value := apex_plugin_util.get_display_data (
      p_sql_statement     => p_item.lov_definition,
      p_min_columns       => 1,
      p_max_columns       => 100,
      p_component_name    => p_item.name,
      p_display_column_no => l_display_col_num,
      p_search_column_no  => l_return_col_num,
      p_search_string     => p_value,
      p_display_extra     => p_item.lov_display_extra
   );

   IF p_is_readonly OR p_is_printer_friendly
   THEN
      apex_plugin_util.print_hidden_if_readonly (
         p_item_name           => p_item.name,
         p_value               => p_value,
         p_is_readonly         => p_is_readonly,
         p_is_printer_friendly => p_is_printer_friendly
      );
      
      apex_plugin_util.print_display_only (
         p_item_name        => p_item.name,
         p_display_value    => l_display_value,
         p_show_line_breaks => FALSE,
         p_escape           => TRUE,
         p_attributes       => p_item.element_attributes
      );
   ELSE
      sys.htp.p(
            '<input type="hidden" name="' || l_name || '" id="' || p_item.name || '_HIDDENVALUE" value="' || p_value || '" />' || l_crlf
         || '<fieldset id="' || p_item.name || '_controls" class="superlov-controls lov">' || l_crlf
         || '   <table cellspacing="0" cellpadding="0" border="0" id="' || p_item.name || '_holder" class="lov" summary="">' || l_crlf
         || '      <tbody>' || l_crlf
         || '         <tr>' || l_crlf
         || '            <td class="lov">' || l_crlf
         || '               <input class="superlov-input popup_lov" type="text" disabled="disabled" onfocus="this.blur();"'
                            || ' value="' || l_display_value || '" maxlength="' || p_item.element_max_length || '" size="'
                            || p_item.element_width || '" id="' || p_item.name || '" ' || p_item.element_attributes
                            || ' />' || l_crlf
         || '            </td>' || l_crlf
         || '            <td>' || l_crlf
         || '               <div class="superlov-modal-delete ui-state-highlight" title="Clear"><span class="ui-icon ui-icon-circle-close"></span></div>' || l_crlf
         || '            </td>' || l_crlf
         || '            <td>' || l_crlf
         || '               <div class="superlov-modal-open ui-state-highlight" title="Open"><span class="ui-icon ui-icon-circle-triangle-n"></span></div>' || l_crlf
         || '            </td>' || l_crlf
         || '         </tr>' || l_crlf
         || '      </tbody>' || l_crlf
         || '   </table>' || l_crlf
         || '</fieldset>' || l_crlf
      );
      
      IF l_jqueryui_theme IS NOT NULL
      THEN
         apex_css.add_file(
            p_name      => 'jquery-ui',
            p_directory => apex_application.g_image_prefix || 'libraries/jquery-ui/1.8/themes/' || l_jqueryui_theme || '/',
            p_version   => NULL
         );
      END IF;
      
      apex_css.add_file(
         p_name      => 'com_skillbuilders_sbip_super_lov',
         p_directory => p_plugin.file_prefix,
         p_version   => NULL
      );

      apex_javascript.add_library(
         p_name      => 'jquery.ui.button',
         p_directory => apex_application.g_image_prefix || 'libraries/jquery-ui/1.8/ui/',
         p_version   => NULL
      );

      apex_javascript.add_library(
         p_name      => 'com_skillbuilders_sbip_super_lov.min',
         p_directory => p_plugin.file_prefix,
         p_version   => NULL
      );

      l_onload_code := 'apex.jQuery("input#' || p_item.name || '").sbip_super_lov({' || l_crlf
         || '   ' || apex_javascript.add_attribute('validateValue', sys.htf.escape_sc(l_validate_value)) || l_crlf
         || '   ' || apex_javascript.add_attribute('returnColNum', l_return_col_num) || l_crlf
         || '   ' || apex_javascript.add_attribute('displayColNum', l_display_col_num) || l_crlf
         || '   ' || apex_javascript.add_attribute('hiddenCols', sys.htf.escape_sc(l_hidden_cols)) || l_crlf
         || '   ' || apex_javascript.add_attribute('searchableCols', l_searchable_cols) || l_crlf
         || '   ' || apex_javascript.add_attribute('mapFromCols', l_map_from_cols) || l_crlf
         || '   ' || apex_javascript.add_attribute('mapToItems', l_map_to_items) || l_crlf
         || '   ' || apex_javascript.add_attribute('maxRowsPerPage', l_max_rows_per_page) || l_crlf
         || '   ' || apex_javascript.add_attribute('noDataFoundMsg', sys.htf.escape_sc(l_no_data_found_msg)) || l_crlf
         || '   ' || apex_javascript.add_attribute('dialogTitle', sys.htf.escape_sc(l_dialog_title)) || l_crlf
         || '   ' || apex_javascript.add_attribute('effectsSpeed', l_effects_speed) || l_crlf
         || '   ' || apex_javascript.add_attribute('useClearProtection', l_clear_protection) || l_crlf
         || '   ' || apex_javascript.add_attribute('loadingImageSrc', sys.htf.escape_sc(l_loading_image_src)) || l_crlf
         || '   ' || apex_javascript.add_attribute('dependingOnSelector', sys.htf.escape_sc(apex_plugin_util.page_item_names_to_jquery(p_item.lov_cascade_parent_items))) || l_crlf
         || '   ' || apex_javascript.add_attribute('pageItemsToSubmit', sys.htf.escape_sc(apex_plugin_util.page_item_names_to_jquery(p_item.ajax_items_to_submit))) || l_crlf
         || '   "ajaxIdentifier": "' || apex_plugin.get_ajax_identifier() || '",' || l_crlf
         || '   "reportHeaders": ' || report_headers_js_array(p_item.lov_definition, p_item.name) || ',' || l_crlf
         || '   ' || apex_javascript.add_attribute('lovTableColumn', l_table_column, TRUE, FALSE) || l_crlf         
         || '});';
         
      apex_javascript.add_onload_code(
         p_code => l_onload_code
      ); 
   END IF;
   
   IF l_validate_value = 'Y'
   THEN
      store_validation_hash(
         p_item_name => p_item.name,
         p_hash      => hash(p_value)
      );
   END IF;

   l_retval.is_navigable := FALSE;
        
   RETURN l_retval;
    
END sbip_super_lov_render;

FUNCTION column_row_value (
   p_row           IN PLS_INTEGER,
   p_column_values IN APEX_PLUGIN_UTIL.T_COLUMN_VALUES
)

   RETURN VARCHAR2

IS

BEGIN

   IF p_column_values.data_type = apex_plugin_util.c_data_type_varchar2
   THEN
      RETURN p_column_values.value_list(p_row).varchar2_value;
   ELSIF p_column_values.data_type = apex_plugin_util.c_data_type_number
   THEN
      RETURN p_column_values.value_list(p_row).number_value;
   ELSIF p_column_values.data_type = apex_plugin_util.c_data_type_date
   THEN
      RETURN p_column_values.value_list(p_row).date_value;
   ELSIF p_column_values.data_type = apex_plugin_util.c_data_type_timestamp
   THEN
      RETURN p_column_values.value_list(p_row).timestamp_value;
   ELSIF p_column_values.data_type = apex_plugin_util.c_data_type_timestamp_tz
   THEN
      RETURN p_column_values.value_list(p_row).timestamp_tz_value;
   ELSIF p_column_values.data_type = apex_plugin_util.c_data_type_timestamp_ltz
   THEN
      RETURN p_column_values.value_list(p_row).timestamp_ltz_value;
   ELSIF p_column_values.data_type = apex_plugin_util.c_data_type_interval_y2m
   THEN
      RETURN p_column_values.value_list(p_row).interval_y2m_value;
   ELSIF p_column_values.data_type = apex_plugin_util.c_data_type_interval_d2s
   THEN
      RETURN p_column_values.value_list(p_row).interval_d2s_value;
   ELSIF p_column_values.data_type = apex_plugin_util.c_data_type_blob
   THEN
      RETURN '[BLOB_DATATYPE]';
   ELSIF p_column_values.data_type = apex_plugin_util.c_data_type_bfile
   THEN
      RETURN '[BFILE_DATATYPE]';
   ELSIF p_column_values.data_type = apex_plugin_util.c_data_type_clob
   THEN
      RETURN p_column_values.value_list(p_row).clob_value;
   ELSE
      RETURN '[INVALID_DATATYPE]';
   END IF;

END column_row_value; 

FUNCTION sbip_super_lov_ajax (
   p_item   IN APEX_PLUGIN.T_PAGE_ITEM,
   p_plugin IN APEX_PLUGIN.T_PLUGIN
)

   RETURN APEX_PLUGIN.T_PAGE_ITEM_AJAX_RESULT

IS

   l_column_value_list APEX_PLUGIN_UTIL.T_COLUMN_VALUE_LIST2;     
   l_validate_value    VARCHAR2(1) := NVL(p_item.attribute_01, 'Y');
   l_dis_ret_cols      VARCHAR2(10) := NVL(p_item.attribute_03, '2,1');
   l_searchable_cols   VARCHAR2(32767) := p_item.attribute_04;
   l_hidden_cols       VARCHAR2(32767) := p_item.attribute_05;
   l_max_rows_per_page PLS_INTEGER := NVL(p_item.attribute_09, 15); 
   l_show_null_as      VARCHAR2(10) := NVL(p_item.attribute_10, '&nbsp;');
   l_search_type       VARCHAR2(32767) := NVL(p_plugin.attribute_01, apex_plugin_util.c_search_contains_ignore);
   l_return_col_num    PLS_INTEGER;
   l_display_col_num   PLS_INTEGER;
   l_lov_base_query    VARCHAR2(32767) := p_item.lov_definition;
   l_ajax_function     VARCHAR2(32767) := apex_application.g_x01;
   l_pagination        VARCHAR2(32767) := apex_application.g_x02;
   l_search_column_no  VARCHAR2(32767) := apex_application.g_x03;
   l_search_string     VARCHAR2(32767) := apex_application.g_x04;
   l_hash              VARCHAR2(32) := apex_application.g_x05;
   l_pagination_parts  WWV_FLOW_GLOBAL.VC_ARR2;
   l_crlf              CHAR(2) := CHR(13)||CHR(10);
  
BEGIN
   
   l_display_col_num := SUBSTR(l_dis_ret_cols, 1, INSTR(l_dis_ret_cols, ',') - 1);
   l_return_col_num := SUBSTR(l_dis_ret_cols, INSTR(l_dis_ret_cols, ',') + 1);
   l_hidden_cols := ',' || l_hidden_cols || ',';

   IF l_ajax_function = 'FETCH_LOV'
   THEN
      l_pagination_parts := apex_util.string_to_table(l_pagination);    

      IF l_search_string IS NOT NULL
      THEN
         IF l_searchable_cols IS NOT NULL 
            AND INSTR(',' || l_searchable_cols || ',', ',' || l_search_column_no || ',') = 0
         THEN
            RAISE_APPLICATION_ERROR(-20001, 'Super LOV Exception: Search attempt on non-searchable column.');
         END IF;
      
         l_search_string := apex_plugin_util.get_search_string(
            p_search_type   => l_search_type,
            p_search_string => l_search_string 
         );
      
         l_column_value_list := apex_plugin_util.get_data2(
            p_sql_statement    => l_lov_base_query, 
            p_min_columns      => 2, 
            p_max_columns      => 100, 
            p_component_name   => p_item.name,
            p_search_type      => l_search_type,
            p_search_column_no => l_search_column_no,
            p_search_string    => l_search_string,
            p_first_row        => l_pagination_parts(1),
            p_max_rows         => l_pagination_parts(2) + 1
         );
      ELSE
         l_column_value_list := apex_plugin_util.get_data2(
            p_sql_statement  => l_lov_base_query, 
            p_min_columns    => 2, 
            p_max_columns    => 100, 
            p_component_name => p_item.name,
            p_first_row      => l_pagination_parts(1),
            p_max_rows       => l_pagination_parts(2) + 1
         );   
      END IF;
      
      sys.htp.p('<table id="superlov-fetch-results" cellspacing="0" cellpadding="0" border="0" class="superlov-table ui-widget ui-widget-content ui-corner-all">');
      sys.htp.p('<thead>');
      sys.htp.p('<tr>');
      

      FOR x IN 1 .. l_column_value_list.count
      LOOP
         IF INSTR(l_hidden_cols, ',' || x || ',') = 0
         THEN
            sys.htp.prn('<th class="ui-widget-header">');
            sys.htp.prn(l_column_value_list(x).name);
            sys.htp.prn('</th>');
         END IF;
      END LOOP;

      sys.htp.p('</tr>');
      sys.htp.p('</thead>');
      sys.htp.p('<tbody>');
      
      FOR x IN 1 .. LEAST(l_column_value_list(1).value_list.count, l_max_rows_per_page)
      LOOP 
         IF l_validate_value = 'Y'
         THEN
            sys.htp.p(
               '<tr data-return="' || column_row_value(x, l_column_value_list(l_return_col_num)) 
               || '" data-display="' || column_row_value(x, l_column_value_list(l_display_col_num)) 
               || '" data-hash="' || hash(column_row_value(x, l_column_value_list(l_return_col_num))) 
               || '"'
            );
            
            IF p_item.escape_output
            THEN
               FOR y IN 1 .. l_column_value_list.count
               LOOP
                  IF INSTR(l_hidden_cols, ',' || y || ',') > 0
                  THEN
                     sys.htp.prn(' data-col' || y || '-value="');
                     sys.htp.prn(NVL(sys.htf.escape_sc(column_row_value(x, l_column_value_list(y))), l_show_null_as));
                     sys.htp.prn('"');
                  END IF;
               END LOOP;
            ELSE
               FOR y IN 1 .. l_column_value_list.count
               LOOP
                  IF INSTR(l_hidden_cols, ',' || y || ',') > 0
                  THEN
                     sys.htp.prn(' data-col' || y || '-value="');
                     sys.htp.prn(NVL(column_row_value(x, l_column_value_list(y)), l_show_null_as));
                     sys.htp.prn('"');
                  END IF;
               END LOOP;
            END IF;
            
            sys.htp.p('>');
         ELSE
            sys.htp.p(
               '<tr data-return="' || column_row_value(x, l_column_value_list(l_return_col_num)) 
               || '" data-display="' || column_row_value(x, l_column_value_list(l_display_col_num)) 
               || '"'
            );
            
            IF p_item.escape_output
            THEN
               FOR y IN 1 .. l_column_value_list.count
               LOOP
                  IF INSTR(l_hidden_cols, ',' || y || ',') > 0
                  THEN
                     sys.htp.prn(' data-col' || y || '-value="');
                     sys.htp.prn(NVL(sys.htf.escape_sc(column_row_value(x, l_column_value_list(y))), l_show_null_as));
                     sys.htp.prn('"');
                  END IF;
               END LOOP;
            ELSE
               FOR y IN 1 .. l_column_value_list.count
               LOOP
                  IF INSTR(l_hidden_cols, ',' || y || ',') > 0
                  THEN
                     sys.htp.prn(' data-col' || y || '-value="');
                     sys.htp.prn(NVL(column_row_value(x, l_column_value_list(y)), l_show_null_as));
                     sys.htp.prn('"');
                  END IF;
               END LOOP;
            END IF;
            
            sys.htp.p('>');
         END IF;
         
         IF p_item.escape_output
         THEN
            FOR y IN 1 .. l_column_value_list.count
            LOOP
               IF INSTR(l_hidden_cols, ',' || y || ',') = 0
               THEN
                  sys.htp.prn('<td class="ui-state-default sbip-col' || y || '">');
                  sys.htp.prn(NVL(sys.htf.escape_sc(column_row_value(x, l_column_value_list(y))), l_show_null_as));
                  sys.htp.prn('</td>');
               END IF;
            END LOOP;
         ELSE
            FOR y IN 1 .. l_column_value_list.count
            LOOP
               IF INSTR(l_hidden_cols, ',' || y || ',') = 0
               THEN
                  sys.htp.prn('<td class="ui-state-default sbip-col' || y || '">');
                  sys.htp.prn(NVL(column_row_value(x, l_column_value_list(y)), l_show_null_as));
                  sys.htp.prn('</td>');
               END IF;
            END LOOP;
         END IF;
         
         sys.htp.p('</tr>');
      END LOOP;
      
      sys.htp.p('</tbody></table>');
      
      IF l_column_value_list(1).value_list.count > l_max_rows_per_page
      THEN
         sys.htp.p('<input id="sbip-super-lov-more-rows" type="hidden" value="Y" />');
      ELSE
         sys.htp.p('<input id="sbip-super-lov-more-rows" type="hidden" value="N" />');
      END IF;
   ELSIF l_ajax_function = 'STORE_VALIDATION_HASH'
   THEN
      store_validation_hash(
         p_item_name => p_item.name,
         p_hash      => l_hash
      );
      
      sys.htp.p('SUCCESS');
   END IF;

   RETURN NULL;

END sbip_super_lov_ajax;

FUNCTION sbip_super_lov_validation (
   p_item   IN APEX_PLUGIN.T_PAGE_ITEM,
   p_plugin IN APEX_PLUGIN.T_PLUGIN,
   p_value  IN VARCHAR2
)

   RETURN APEX_PLUGIN.T_PAGE_ITEM_VALIDATION_RESULT

IS

   l_retval          APEX_PLUGIN.T_PAGE_ITEM_VALIDATION_RESULT;
   l_collection_name VARCHAR2(50) := 'SBIP_SUPER_LOV_VALIDATION_VALUES';
   l_stored_hash     VARCHAR2(32);
   l_validate_value  VARCHAR2(1) := NVL(p_item.attribute_01, 'Y');

BEGIN

   IF l_validate_value = 'Y' AND p_value IS NOT NULL
   THEN
      SELECT c002
      INTO l_stored_hash
      FROM apex_collections
      WHERE collection_name = l_collection_name
         AND c001 = p_item.name;
         
      IF NOT l_stored_hash = hash(p_value)
      THEN
         l_retval.message := '#LABEL# contains a value that was not in the list of values.';
      END IF;
   END IF;

   RETURN l_retval;

END;