(function($){
$.widget("ui.sbip_super_lov", {
   options: {
      validateValue: null,
      returnColNum: null,
      displayColNum: null,
      hiddenCols: null,
      searchableCols: null,
      mapFromCols: null,
      mapToItems: null,
      maxRowsPerPage: null,
      dialogTitle: null,
      useClearProtection: null,
      noDataFoundMsg: null,
      loadingImageSrc: null,
      ajaxIdentifier: null,
      reportHeaders: null,
      effectsSpeed: null,
      dependingOnSelector: null,
      pageItemsToSubmit: null,
      lovTableColumn: null
   },
   _createPrivateStorage: function() {
      var uiw=this;
      
      uiw._values = {
         apexItemId: '',
         deleteIconTimeout: '',
         pagination: '',
         curPage: '',
         moreRows: false,
         wrapperHeight: 0,
         dialogHeight: 0,
         dialogWidth: 0,
         dialogTop: 0,
         dialogLeft: 0,
         percentRegExp: /^-?[0-9]+\.?[0-9]*%$/,
         pixelRegExp: /^-?[0-9]+\.?[0-9]*px$/i,
         hiddenCols: (uiw.options.hiddenCols) ? uiw.options.hiddenCols.split(',') : [],
         searchableCols: (uiw.options.searchableCols) ? uiw.options.searchableCols.split(',') : [],
         mapFromCols: (uiw.options.mapFromCols) ? uiw.options.mapFromCols.split(',') : [],
         mapToItems: (uiw.options.mapToItems) ? uiw.options.mapToItems.split(',') : []
      };
      
      uiw._elements = {
         $window: {},
         $hiddenInput: {},
         $displayInput: {},
         $clearButton: {},
         $openButton: {},
         $outerDialog: {},
         $dialog: {},
         $buttonContainer: {},
         $searchContainer: {},
         $paginationContainer: {},
         $columnSelect: {},
         $filter: {},
         $goButton: {},
         $prevButton: {},
         $paginationDisplay: {},
         $nextButton: {},
         $wrapper: {},
         $table: {},
         $nodata: {},
         $moreRows: {}
      };
   },
   _init: function() {
      var uiw = this;
      var preLoadImg;
      var bColor;
      var bWidth;
      var bStyle;
      var backColor;
      var backImage;
      var backRepeat;
      var backAttachment;
      var backPosition;

      uiw._createPrivateStorage();
      uiw._values.apexItemId = $(uiw.element).attr('id');
      uiw._initBaseElements();
      uiw._tabularLov();

      bColor = uiw._elements.$displayInput.css('border-top-color');
      bWidth = uiw._elements.$displayInput.css('border-top-width');
      bStyle = uiw._elements.$displayInput.css('border-top-style');
      backColor = uiw._elements.$displayInput.css('background-color');
      backImage = uiw._elements.$displayInput.css('background-image');
      backRepeat = uiw._elements.$displayInput.css('background-repeat');
      backAttachment = uiw._elements.$displayInput.css('background-attachment');
      backPosition = uiw._elements.$displayInput.css('background-position');

      if(($.browser.msie || $.browser.webkit) && bColor !== 'none') {
         bColor = '#aaaaaa';

         if($.browser.msie && bStyle === 'none') {
            bStyle = 'inset';
         }
      }
      
      if(bWidth === '2px') {
         bWidth = '1px';
      }

      uiw._elements.$displayInput.css('border', 'none');
      $('#' + uiw._values.apexItemId + '_controls').css({
         'border-color':bColor,
         'border-width':bWidth,
         'border-style':bStyle,
         'background-color':backColor,
         'background-image':backImage,
         'background-repeat':backRepeat,
         'background-attachment':backAttachment,
         'background-position':backPosition
      });

      uiw._elements.$openButton.bind('click', function() {
         uiw._showDialog();
      });
      
      uiw._elements.$clearButton.bind('click', function() {
         uiw._clearLov();
      });
      
      uiw._elements.$displayInput.bind('apexrefresh', function() {
         uiw._refresh();
      });
      
      if (uiw.options.dependingOnSelector) {
         $(uiw.options.dependingOnSelector).bind('change', function() {
            uiw._elements.$displayInput.trigger('apexrefresh');
         });
      }
   },
   _initBaseElements: function() {
      var uiw = this;
      
      uiw._elements.$hiddenInput = $('#' + uiw._values.apexItemId + '_HIDDENVALUE');
      uiw._elements.$displayInput = uiw.element;
      uiw._elements.$clearButton =
         $('#' + uiw._values.apexItemId + '_controls div.superlov-modal-delete');
      uiw._elements.$openButton =
         $('#' + uiw._values.apexItemId + '_controls div.superlov-modal-open');
   },
   _tabularLov: function () {
   		var uiw = this;
   	
   		var tabularColumn = uiw.options.lovTableColumn;
		var $lov = $('td[headers="'+ tabularColumn +'"]').find('span.lov');
		if($lov.length) {
		    uiw._elements.$hiddenInput.parent('td').parent('tr').hide();
		
		    $lov.each(function(i, e) {
		    	var $trigger = $(e).find('a');
		    	var $text = $(e).find('input[type="text"]');
		    	var $value = $(e).find('input[type="hidden"]');
		    	
		        $trigger.attr('href', '#').attr('onclick','').unbind('click').bind('click', function(event) {
		            uiw._elements.$openButton.click();
		            uiw._elements.$hiddenInput.bind('change', function() {
		            	if($value.length > 0) {
		            		$value.val(uiw._elements.$hiddenInput.val());
		            		$text.val(uiw._elements.$displayInput.val());
		            	} else {
		            		$text.val(uiw._elements.$hiddenInput.val());
		            	}
		            	
		            	uiw._elements.$hiddenInput.unbind('change');
			        });
			        event.preventDefault();
			    });
			});   
		}
	},
   _initElements: function() {
      var uiw = this;

      uiw._elements.$window = $(window);
      uiw._elements.$outerDialog = $('div.superlov-dialog');
      uiw._elements.$dialog = $('div.superlov-container');
      uiw._elements.$buttonContainer = $('div.superlov-button-container');
      uiw._elements.$searchContainer = $('div.superlov-search-container');
      uiw._elements.$paginationContainer = $('div.superlov-pagination-container');
      uiw._elements.$columnSelect = $('select#superlov-column-select');
      uiw._elements.$filter = $('input#superlov-filter');
      uiw._elements.$searchButton = $('div.superlov-search-icon');
      uiw._elements.$prevButton = $('button#superlov-prev-page');
      uiw._elements.$paginationDisplay = $('span#superlov-pagination-display');
      uiw._elements.$nextButton = $('button#superlov-next-page');
      uiw._elements.$wrapper = $('div.superlov-table-wrapper');;
   },
   _initTransientElements: function() {
      var uiw = this;

      uiw._elements.$table = $('table.superlov-table');
      uiw._elements.$nodata = $('div.superlov-nodata');
      uiw._elements.$moreRows = $('input#sbip-super-lov-more-rows');
   },
   _initButtons: function() {
      var uiw = this;

      uiw._elements.$searchButton
         .bind('click', {uiw: uiw}, uiw._handleSearchButtonClick);

      uiw._elements.$prevButton
         .button({
            text: false,
            icons: {
               primary: "ui-icon-arrowthick-1-w"
            }
         })
         .bind('click', {uiw: uiw}, uiw._handlePrevButtonClick);

      uiw._elements.$nextButton
         .button({
            text: false,
            icons: {
               primary: "ui-icon-arrowthick-1-e"
            }
         })
         .bind('click', {uiw: uiw}, uiw._handleNextButtonClick);
   },
   _initColumnSelect: function() {
      var uiw = this;
      var columnSelect = uiw._elements.$columnSelect.get(0);
      var count = 1;
      
      for (x=0; x<uiw.options.reportHeaders.length; x++) {
         if (!uiw._isHiddenCol(x+1) && uiw._isSearchableCol(x+1)) {
            columnSelect.options[count] = new Option(uiw.options.reportHeaders[x], x+1);
            count += 1;
         }
      }
      
      //Select the correct default option in the select list
      if (uiw._values.searchableCols.length) {
         $('select#superlov-column-select option[value="' + 
            uiw._values.searchableCols[0] + '"]'
         ).attr('selected','selected');
      } else {
         $('select#superlov-column-select option:eq(1)').attr('selected','selected');
      }
   },
   _handleColumnChange: function() {
      var uiw = this;

      if (uiw._elements.$columnSelect.val()) {
         uiw._elements.$filter.removeAttr('disabled');
      } else {
         uiw._elements.$filter
            .val('')
            .attr('disabled','disabled');
      }
      uiw._updateStyledFilter();
   },
   _ieNoSelectText: function() {
      if(document.attachEvent) {
         $('div.superlov-table-wrapper *').each(function() {
            $(this)[0].attachEvent('onselectstart', function() {return false;});
         });
      }
   },
   _isHiddenCol: function(colNum) {
      var uiw = this;
      var retval = false;
      
      for (i = 0; i < uiw._values.hiddenCols.length; i++) {
         if (parseInt(colNum, 10) === parseInt(uiw._values.hiddenCols[i], 10)) {
            retval = true;
            break;
         }
      }
      
      return retval;
   },
   _isSearchableCol: function(colNum) {
      var uiw = this;
      var retval = false;
      
      if (uiw._values.searchableCols.length) {         
         for (i = 0; i < uiw._values.searchableCols.length; i++) {
            if (parseInt(colNum, 10) === parseInt(uiw._values.searchableCols[i], 10)) {
               retval = true;
               break;
            }
         }
      } else {
         retval = true;
      }
      
      return retval;
   },
   _showDialog: function() {
      var uiw = this;
      var buttonContainerWidth;
      var dialogHtml =
            '<div class="superlov-container ui-widget">\n'
         +  '   <div class="superlov-button-container ui-widget-header ui-corner-all ui-helper-clearfix">\n'
         +  '      <div class="superlov-search-container">\n'
         +  '         <table>\n'
         +  '            <tr>\n'
         +  '               <td valign="middle">\n'
         +  '                  Search&nbsp;\n'
         +  '               </td>\n'
         +  '               <td valign="middle">\n'
         +  '                  <select id="superlov-column-select" size="1">\n'
         +  '                     <option value="">- Select Column -</option>\n'
         +  '                  </select>\n'
         +  '               </td>\n'
         +  '               <td>\n'
         +  '                  <div id="superlov_styled_filter" class="ui-corner-all">\n'
         +  '                     <table>\n'
         +  '                        <tbody>\n'
         +  '                           <tr>\n'
         +  '                              <td>\n'
         +  '                                 <input type="text" id="superlov-filter" class="ui-corner-all"/>\n'
         +  '                              </td>\n'
         +  '                              <td>\n'
         +  '                                 <div class="ui-state-highlight superlov-search-icon"><span class="ui-icon ui-icon-circle-zoomin"></span></div>\n'
         +  '                              </td>\n'
         +  '                           </tr>\n'
         +  '                        </tbody>\n'
         +  '                     </table>\n'
         +  '                  </div>\n'
         +  '               </td>\n'
         +  '            </tr>\n'
         +  '         </table>\n'
         +  '      </div>\n'
         +  '      <div class="superlov-pagination-container">\n'
         +  '         <table>\n'
         +  '            <tr>\n'
         +  '               <td valign="middle">\n'
         +  '                  <button id="superlov-prev-page">Previous Page</button>\n'
         +  '               </td>\n'
         +  '               <td valign="middle">\n'
         +  '                  <span id="superlov-pagination-display">Page 1</span>\n'
         +  '               </td>\n'
         +  '               <td valign="middle">\n'
         +  '                  <button id="superlov-next-page">Next Page</button>\n'
         +  '               </td>\n'
         +  '            </tr>\n'
         +  '         </table>\n'
         +  '      </div>\n'
         +  '   </div>\n'
         +  '   <div class="superlov-table-wrapper">\n'
         +  '      <img src="' + uiw.options.loadingImageSrc + '">\n'
         +  '   </div>\n'
         +  '</div>\n'
      ;

      $('body').append(
         dialogHtml
      );

      uiw._initElements();

      uiw._values.pagination = '1:' + uiw.options.maxRowsPerPage;
      uiw._values.searchString = '';
      uiw._values.curPage = 1;

      uiw._initButtons();

      uiw._initColumnSelect();

      uiw._elements.$columnSelect.bind('change', function() {
         uiw._handleColumnChange();
      });

      uiw._elements.$filter
         .bind('keydown', {uiw: uiw}, uiw._handleFilterKeydown);
         
       var bColor = uiw._elements.$filter.css('border-top-color');
   	 var bWidth = uiw._elements.$filter.css('border-top-width');
	    var bStyle = uiw._elements.$filter.css('border-top-style');
	    var backColor = uiw._elements.$filter.css('background-color');
	    var backImage = uiw._elements.$filter.css('background-image');
	    var backRepeat = uiw._elements.$filter.css('background-repeat');
	    var backAttachment = uiw._elements.$filter.css('background-attachment');
	    var backPosition = uiw._elements.$filter.css('background-position');
	    
	    if(($.browser.msie || $.browser.webkit) && bColor !== 'none') {
	       bColor = '#aaaaaa';
	       
	       if($.browser.msie && bStyle === 'none') {
	          bStyle = 'inset';
	       }
	    }

	    uiw._elements.$filter.css('border', 'none');
	    $('#superlov_styled_filter').css({
	       'border-color':bColor,
	       'border-width':bWidth,
	       'border-style':bStyle,
	       'background-color':backColor,
	       'background-image':backImage,
	       'background-repeat':backRepeat,
	       'background-attachment':backAttachment,
	       'background-position':backPosition
	    });

      uiw._elements.$columnSelect
         .bind('keydown', {uiw: uiw}, uiw._handleFilterKeydown);

      uiw._disableSearchButton();
      uiw._disablePrevButton();
      uiw._disableNextButton();

      buttonContainerWidth = uiw._elements.$searchContainer.width()
         + uiw._elements.$paginationContainer.width();

      //Set the appropriate width on the button container
      uiw._elements.$buttonContainer
         .css('width', buttonContainerWidth + 20 + 'px');

      uiw._elements.$dialog.dialog({
         disabled: false,
         autoOpen: false,
         closeOnEscape: true,
         closeText: "Close",
         dialogClass: "superlov-dialog",
         draggable: true,
         height: "auto",
         hide: null,
         maxhHeight: false,
         maxWidth: false,
         minHeight: 150,
         minWidth: false,
         modal: true,
         resizable: false,
         show: null,
         stack: true,
         title: uiw.options.dialogTitle,
         close: function() {
            $('body').unbind('keydown', uiw._handleBodyKeydown);
            $('table.superlov-table tbody tr').die();
            $(this).dialog('destroy');
            uiw._elements.$dialog.remove();
         }
      });
      
      uiw._initElements();
      uiw._elements.$dialog.css('overflow', 'hidden');
      uiw._elements.$outerDialog
         .css('min-width', buttonContainerWidth + 42 + 'px');

      //Set the position of the element.  Must do this after the initialization
      //of the dialog so that the calculation of leftPos can be done using the
      //superlov-dialog element.
      uiw._values.dialogTop = uiw._elements.$window.height()*.05;

      uiw._values.dialogLeft =
         (uiw._elements.$window.width()/2)
         - (uiw._elements.$outerDialog.outerWidth(true)/2);
      if (uiw._values.dialogLeft < 0) {
         uiw._values.dialogLeft = 0;
      }

      uiw._elements.$dialog.dialog('option', 'position', [uiw._values.dialogLeft, uiw._values.dialogTop]);

      uiw._ieNoSelectText();

      $('body').bind('keydown', {uiw: uiw}, uiw._handleBodyKeydown);

      $('table.superlov-table tbody tr')
         .live('mouseover', {uiw: uiw}, uiw._handleMainTrMouseover)
         .live('mouseout', {uiw: uiw}, uiw._handleMainTrMouseout)
         .live('click', {uiw: uiw}, uiw._handleMainTrClick);

      uiw._elements.$window.bind('resize', {uiw: uiw}, uiw._handleWindowResize);

      uiw._elements.$dialog.dialog('open');

      uiw._elements.$wrapper
         .html('   <img src="' + uiw.options.loadingImageSrc + '">\n');

      uiw._fetchLov();
      
      uiw._elements.$filter.trigger('focus');
   },
   _handleWindowResize: function(e) {
      var uiw = e.data.uiw;
      var leftPos;

      if (!uiw._elements.$table.length && !uiw._elements.$nodata.length) {
         uiw._initTransientElements();
      }

      uiw._updateLovMeasurements();

      uiw._elements.$outerDialog.css({
         'height':uiw._values.dialogHeight,
         'width':uiw._values.dialogWidth
      });

      uiw._elements.$wrapper.css({
         'height':uiw._values.wrapperHeight,
         'width':uiw._values.wrapperWidth,
         'overflow':'hidden'
      });

      leftPos = (uiw._elements.$window.width()/2)
      - (uiw._elements.$outerDialog.outerWidth(true)/2);

      if (leftPos < 0) {
         leftPos = 0;
      }

      uiw._elements.$outerDialog.css({
         'top':uiw._values.dialogTop,
         'left':leftPos
      });

      uiw._elements.$wrapper.css('overflow', 'auto');
   },
   _handleBodyKeydown: function(eventObj) {
      var uiw = eventObj.data.uiw;

      if (eventObj.which === 37 && !uiw._elements.$prevButton.attr('disabled')) {//left
         uiw._handlePrevButtonClick(eventObj);
      } else if (eventObj.which === 39 && !uiw._elements.$nextButton.attr('disabled')) {//right
         uiw._handleNextButtonClick(eventObj);
      }
   },
   _fetchLov: function() {
      var uiw = this;
      var searchColumnNo;
      var searchString;
      var queryString;

      uiw._disableSearchButton();
      uiw._disablePrevButton();
      uiw._disableNextButton();
      uiw._elements.$window.unbind('resize', uiw._handleWindowResize);

      if (uiw._elements.$columnSelect.val() && uiw._elements.$filter.val()) {
         searchColumnNo = uiw._elements.$columnSelect.val();
         searchString = uiw._elements.$filter.val();
      }
      
      //Breaking out the query string so that the arg_names and arg_values
      //can be added as arrays after
      queryString = {
         p_flow_id: $('#pFlowId').val(),
         p_flow_step_id: $('#pFlowStepId').val(),
         p_instance: $('#pInstance').val(),
         p_request: 'PLUGIN=' + uiw.options.ajaxIdentifier,
         x01: 'FETCH_LOV',
         x02: uiw._values.pagination,
         x03: searchColumnNo,
         x04: searchString,
         p_arg_names: [],
         p_arg_values: []
      }
      
      //Building up the arg_names and arg_values as arrays
      //jQuery's ajax will break them back up automatically
      $(uiw.options.dependingOnSelector).add(uiw.options.pageItemsToSubmit).each(function(i){
         queryString.p_arg_names[i] = this.id;
         queryString.p_arg_values[i] = $v(this);
      });

      $.ajax({
         type: 'POST',
         url: 'wwv_flow.show',
         data: queryString,
         dateType: 'text',
         async: false,
         success: function(data) {
            uiw._handleFetchLovReturn(data);
         }
      });
   },
   _handleFetchLovReturn: function(data) {
      var uiw = this;
      var noDataFoundMsg;

      uiw._elements.$wrapper
         .fadeTo(0, 0)
         .css({
            'width':'1000000000000px',
            'height':'0px',
            'overflow':'hidden'//Webkit wants hide then show scrollbars
         })
         .html(data);

      if (!$('table.superlov-table tr:eq(1)').length) {
         noDataFoundMsg =
               '<div class="ui-widget superlov-nodata">\n'
            +  '   <div class="ui-state-highlight ui-corner-all" style="padding: 0pt 0.7em;">\n'
            +  '      <p>\n'
            +  '      <span class="ui-icon ui-icon-alert" style="float: left; margin-right:0.3em;"></span>\n'
            +  '      ' + uiw.options.noDataFoundMsg + '\n'
            +  '      </p>\n'
            +  '   </div>\n'
            +  '</div>\n';

         uiw._elements.$wrapper.html(noDataFoundMsg);
      } else {
         $('table.superlov-table th:first').addClass('ui-corner-tl');
         $('table.superlov-table th:last').addClass('ui-corner-tr');
         $('table.superlov-table tr:last td:first').addClass('ui-corner-bl');
         $('table.superlov-table tr:last td:last').addClass('ui-corner-br');
      }
      uiw._ieNoSelectText()
      uiw._initTransientElements();
      uiw._values.moreRows =
         (uiw._elements.$moreRows.val() === 'Y') ? true : false;

      uiw._highlightSelectedRow();

      uiw._updatePaginationDisplay();

      uiw._enableSearchButton();

      if (uiw._values.moreRows) {
         uiw._enableNextButton();
      } else {
         uiw._disableNextButton();
      }

      if (uiw._elements.$table.length) {
         uiw._elements.$table.width(uiw._elements.$table.width());
      }
      else if (uiw._elements.$nodata.length) {
         uiw._elements.$nodata.width(uiw._elements.$nodata.width());
      }

      uiw._resizeModal();
   },
   _resizeModal: function() {
      var uiw = this;

      uiw._updateLovMeasurements();

      if (uiw.options.effectsSpeed === 0) {//had to create separate block, animate with 0 was choppy with large tables
         uiw._elements.$outerDialog.css({
            'height': uiw._values.dialogHeight,
            'width': uiw._values.dialogWidth,
            'left': uiw._values.dialogLeft
         });
         
         if (uiw._elements.$nodata.length) {
            uiw._elements.$nodata.width(uiw._values.wrapperWidth);
         }

         uiw._elements.$wrapper.css({
            'height':uiw._values.wrapperHeight,
            'width':uiw._values.wrapperWidth,
            'overflow':'auto'//Webkit wants hide then show scrollbars
         })
         .fadeTo(uiw.options.effectsSpeed, 1);

         uiw._elements.$window.bind('resize', {uiw: uiw}, uiw._handleWindowResize);
      } else {
         uiw._elements.$outerDialog.animate(
            {height: uiw._values.dialogHeight},
            uiw.options.effectsSpeed,
            function() {
               uiw._elements.$outerDialog.animate({
                     width: uiw._values.dialogWidth,
                     left: uiw._values.dialogLeft
                  },
                  uiw.options.effectsSpeed,
                  function() {
                     if (uiw._elements.$nodata.length) {
                        uiw._elements.$nodata.width(uiw._values.wrapperWidth);
                     }

                     uiw._elements.$wrapper.css({
                        'height':uiw._values.wrapperHeight,
                        'width':uiw._values.wrapperWidth,
                        'overflow':'auto'//Webkit wants hide then show scrollbars
                     })
                     .fadeTo(uiw.options.effectsSpeed, 1);

                     uiw._elements.$window.bind('resize', {uiw: uiw}, uiw._handleWindowResize);
                  }
               );
            }
         );
      }
   },
   _search: function() {
      var uiw = this;

      uiw._values.curPage = 1;
      uiw._values.pagination = '1:' + uiw.options.maxRowsPerPage;
      uiw._values.searchString = uiw._elements.$filter.val();

      if (uiw._values.searchString === '') {
         uiw._elements.$columnSelect.val('');
         uiw._handleColumnChange();
      }

      uiw._fetchLov();
      uiw._disablePrevButton();
   },
   _updatePaginationDisplay: function() {
      var uiw = this;

      uiw._elements.$paginationDisplay.html('Page ' + uiw._values.curPage);
   },
   _disableSearchButton: function() {
      var uiw = this;

      uiw._disableButton('search');
   },
   _disablePrevButton: function() {
      var uiw = this;

      uiw._disableButton('prev');
   },
   _disableNextButton: function() {
      var uiw = this;

      uiw._disableButton('next');
   },
   _disableButton: function(which) {
      var uiw = this;
      var $button;

      if (which == 'search') {
         $button = uiw._elements.$searchButton;
         
         $button
            .attr('disabled','disabled')
            .removeClass('ui-state-hover') //User may be hovering over button
            .removeClass('ui-state-focus')
            .css('cursor', 'default');
         
         return;
      } else if (which == 'prev') {
         $button = uiw._elements.$prevButton;
      } else if (which == 'next') {
         $button = uiw._elements.$nextButton;
      }

      $button
         .attr('disabled','disabled')
         .removeClass('ui-state-hover') //User may be hovering over button
         .removeClass('ui-state-focus')
         .css({
            'opacity':'0.5',
            'cursor':'default'
         });
   },
   _enableSearchButton: function() {
      var uiw = this;

      uiw._enableButton('search');
   },
   _enablePrevButton: function() {
      var uiw = this;

      uiw._enableButton('prev');
   },
   _enableNextButton: function() {
      var uiw = this;

      uiw._enableButton('next');
   },
   _enableButton: function(which) {
      var uiw = this;
      var $button;

      if (which == 'search') {
         $button = uiw._elements.$searchButton;
         
         $button
         .removeAttr('disabled')
         .css('cursor', 'pointer');
         
         return;
      } else if (which == 'prev') {
         $button = uiw._elements.$prevButton;
      } else if (which == 'next') {
         $button = uiw._elements.$nextButton;
      }

      $button
         .removeAttr('disabled')
         .css({
            'opacity':'1',
            'cursor':'pointer'
         });
   },
   _highlightSelectedRow: function() {
      var uiw = this;
      var $tblRow = $('table.superlov-table tbody tr[data-return="'
         + uiw._elements.$hiddenInput.val() + '"]');

      $tblRow.children('td')
         .removeClass('ui-state-default')
         .addClass('ui-state-active');
   },
   _handleMainTrMouseover: function(eventObj) {
      var uiw = eventObj.data.uiw;
      var $tblRow = $(eventObj.currentTarget); //currentTarget w/live

      $tblRow.children('td:not(.ui-state-active)')
         .removeClass('ui-state-default')
         .addClass('ui-state-hover');
   },
   _handleMainTrMouseout: function(eventObj) {
      var uiw = eventObj.data.uiw;
      var $tblRow = $(eventObj.currentTarget); //currentTarget w/live

      $tblRow.children('td:not(.ui-state-active)')
         .removeClass('ui-state-hover')
         .addClass('ui-state-default');
   },
   _handleMainTrClick: function(eventObj) {
      var uiw = eventObj.data.uiw;
      var valChanged;
      var $tblRow = $(eventObj.currentTarget); //currentTarget w/live
      var returnVal = $tblRow.attr('data-return');
      var displayVal = $tblRow.attr('data-display');
      var hashVal;

      valChanged = uiw._elements.$hiddenInput.val() !== returnVal;

      uiw._elements.$hiddenInput.val(returnVal);
      uiw._elements.$displayInput.val(displayVal);
      
      for (x = 0; x < uiw._values.mapToItems.length; x++) {
         if (uiw._isHiddenCol(uiw._values.mapFromCols[x])) {
            $s(uiw._values.mapToItems[x], $tblRow.attr('data-col' + uiw._values.mapFromCols[x] + '-value'));
         } else {
            $s(uiw._values.mapToItems[x], $tblRow.children('td.sbip-col' + uiw._values.mapFromCols[x]).html());
         }
      }

      if (uiw.options.validateValue === 'Y' && valChanged) {
         hashVal = $tblRow.attr('data-hash');

         $.ajax({
            type: 'POST',
            url: 'wwv_flow.show',
            data: {
               p_flow_id: $('#pFlowId').val(),
               p_flow_step_id: $('#pFlowStepId').val(),
               p_instance: $('#pInstance').val(),
               p_request: 'PLUGIN=' + uiw.options.ajaxIdentifier,
               x01: 'STORE_VALIDATION_HASH',
               x05: hashVal
            },
            dateType: 'text',
            async: true,
            success: function(data) {
               if (!data.match(/SUCCESS/)) {
                  alert(data);
               }
            }
         });
      }

      uiw._elements.$dialog.dialog('close');

      if (valChanged) {
         uiw._elements.$hiddenInput.trigger('change');
         uiw._elements.$displayInput.trigger('change');
      }
   },
   _handleFilterKeydown: function(eventObj) {
      var uiw = eventObj.data.uiw;

      if (eventObj.which === 13) {
         uiw._search();
      }
   },
   _handleSearchButtonClick: function(eventObj) {
      var uiw = eventObj.data.uiw;

      uiw._search();
   },
   _handlePrevButtonClick: function(eventObj) {
      var uiw = eventObj.data.uiw;
      var fromRow;
      var toRow;

      uiw._values.curPage = uiw._values.curPage - 1;

      if (uiw._values.curPage === 1) {
         fromRow = 1 ;
         toRow = uiw.options.maxRowsPerPage;

         uiw._values.pagination = fromRow + ':' + toRow;

         uiw._fetchLov();
         uiw._disablePrevButton();
      } else {
         fromRow = ((uiw._values.curPage-1) * uiw.options.maxRowsPerPage) + 1;
         toRow = uiw._values.curPage * uiw.options.maxRowsPerPage;

         uiw._values.pagination = fromRow + ':' + toRow;

         uiw._fetchLov();
         uiw._enablePrevButton();
      }
   },
   _handleNextButtonClick: function(eventObj) {
      var uiw = eventObj.data.uiw;
      var fromRow;
      var toRow;

      uiw._values.curPage = uiw._values.curPage + 1;
      fromRow = ((uiw._values.curPage-1) * uiw.options.maxRowsPerPage) + 1;
      toRow = uiw._values.curPage * uiw.options.maxRowsPerPage;
      uiw._values.pagination = fromRow + ':' + toRow;

      uiw._fetchLov();

      uiw._elements.$paginationDisplay.html('Page ' + uiw._values.curPage);

      if (
         uiw._values.curPage >= 2
         && uiw._elements.$prevButton.attr('disabled')
      ) {
         uiw._enablePrevButton();
      }
   },
   _refresh: function() {
      var uiw = this;
      var curVal = uiw._elements.$hiddenInput.val();
      
      uiw._elements.$displayInput.trigger('apexbeforerefresh');

      uiw._elements.$hiddenInput.val('');
      uiw._elements.$displayInput.val('');
      
      for (x = 0; x < uiw._values.mapToItems.length; x++) {
         $s(uiw._values.mapToItems[x], '');
      }
      
      uiw._elements.$displayInput.trigger('apexafterrefresh');
      
      if (curVal !== uiw._elements.$hiddenInput.val()) {
         uiw._elements.$hiddenInput.trigger('change');
         uiw._elements.$displayInput.trigger('change');
      }

      return false;
   },
   _updateLovMeasurements: function() {
      var uiw = this;
      var $innerElement
      var accountForScrollbar = 25;
      var hasVScroll = false;
      var hasHScroll = false;
      var calculateWidth = true;

      var baseDialogHeight;
      var maxHeight;
      var wrapperHeight;

      var baseWidth;
      var minWidth;
      var maxWidth;
      var wrapperWidth;

      var dialogWidth;
      var dialogHeight;

      var moveBy;
      var leftPos;

      if (!uiw._elements.$nodata.length) {
         $innerElement = uiw._elements.$table;
      }
      else {
         calculateWidth = false;
         $innerElement = uiw._elements.$nodata;
      }

      baseDialogHeight =
         $('div.superlov-dialog div.ui-dialog-titlebar').outerHeight(true)
         + uiw._elements.$buttonContainer.outerHeight(true)
         + $('div.superlov-dialog div.ui-dialog-buttonpane').outerHeight(true)
         + (uiw._elements.$dialog.outerHeight(true)
            - uiw._elements.$dialog.height())
         + (uiw._elements.$wrapper.outerHeight(true)
            - uiw._elements.$wrapper.height());

      maxHeight = uiw._elements.$outerDialog.css('max-height');
      if (uiw._values.percentRegExp.test(maxHeight)) {
         maxHeight = parseFloat(maxHeight);

         maxHeight = uiw._elements.$window.height() * (maxHeight/100);
      }
      else if (uiw._values.pixelRegExp.test(maxHeight)) {
         maxHeight = parseFloat(maxHeight);
      }
      else {
         maxHeight = uiw._elements.$window.height() * .9;
      }
      //TEMPORARY FIX.  IE not getting correct value when selecting the
      //CSS max-height value.
      maxHeight = uiw._elements.$window.height() * .9;

      baseWidth = uiw._elements.$dialog.outerWidth(true)
         - uiw._elements.$dialog.width();

      minWidth = uiw._elements.$outerDialog.css('min-width');
      if (uiw._values.percentRegExp.test(minWidth)) {
         minWidth = parseFloat(minWidth);

         minWidth = uiw._elements.$window.width() * (minWidth/100);
      }
      else if (uiw._values.pixelRegExp.test(minWidth)) {
         minWidth = parseFloat(minWidth);
      }
      else {
         minWidth = uiw._elements.$buttonContainer.outerWidth(true);
      }

      maxWidth = uiw._elements.$outerDialog.css('max-width');
      if (uiw._values.percentRegExp.test(maxWidth)) {
         maxWidth = parseFloat(maxWidth);

         maxWidth = uiw._elements.$window.width() * (maxWidth/100);
      }
      else if (uiw._values.pixelRegExp.test(maxWidth)) {
         maxWidth = parseFloat(maxWidth);
      }
      else {
         maxWidth = uiw._elements.$window.width() * .9;
      }
      //TEMPORARY FIX.  IE not getting correct value when selecting the
      //CSS max-width value.
      maxWidth = uiw._elements.$window.width() * .9;

      if (baseDialogHeight + $innerElement.outerHeight(true) > maxHeight) {
         hasVScroll = true;
         wrapperHeight = maxHeight - baseDialogHeight;
      }
      else {
         wrapperHeight = $innerElement.outerHeight(true);
      }

      if (calculateWidth) {
         wrapperWidth = $innerElement.outerWidth(true);
         if (hasVScroll) {
            wrapperWidth = wrapperWidth + accountForScrollbar;
         }

         if (baseWidth + wrapperWidth < minWidth) {
            wrapperWidth = minWidth - baseWidth;
         }
         else if (baseWidth + wrapperWidth > maxWidth) {
            hasHScroll = true;
            wrapperWidth = maxWidth - baseWidth;

            if (wrapperWidth < minWidth) {
               wrapperWidth = minWidth - baseWidth;
            }
         }

         if (hasHScroll && ! hasVScroll) {
            if (baseDialogHeight + $innerElement.outerHeight(true) + accountForScrollbar > maxHeight) {
               hasVScroll = true;
               wrapperHeight = maxHeight - baseDialogHeight;
            }
            else {
               wrapperHeight =
                  $innerElement.outerHeight(true)
                  + accountForScrollbar;
            }
         }
      }
      else {
         wrapperWidth = minWidth - baseWidth;
      }

      dialogHeight = baseDialogHeight + wrapperHeight;
      dialogWidth = baseWidth + wrapperWidth;

      uiw._values.wrapperHeight = wrapperHeight;
      uiw._values.wrapperWidth = wrapperWidth;
      uiw._values.dialogHeight = dialogHeight;
      uiw._values.dialogWidth = dialogWidth;

      moveBy =
         (uiw._values.dialogWidth - uiw._elements.$outerDialog.width())/2;
      leftPos = uiw._elements.$outerDialog.css('left');
      if (uiw._values.percentRegExp.test(leftPos)) {
         leftPos = parseFloat(leftPos);

         leftPos = uiw._elements.$window.width() * (leftPos/100);
      }
      else if (uiw._values.pixelRegExp.test(leftPos)) {
         leftPos = parseFloat(leftPos);
      }
      else {
         leftPos = 0;
      }

      leftPos = leftPos - moveBy;

      if(leftPos < 0) {
         leftPos = 0;
      }

      uiw._values.dialogLeft = leftPos;
      uiw._values.dialogTop = uiw._elements.$window.height()*.05
   },
   _updateStyledFilter: function() {
      var uiw = this;
      var backColor = uiw._elements.$filter.css('background-color');
      var backImage = uiw._elements.$filter.css('background-image');
      var backRepeat = uiw._elements.$filter.css('background-repeat');
      var backAttachment = uiw._elements.$filter.css('background-attachment');
      var backPosition = uiw._elements.$filter.css('background-position');

      $('#superlov_styled_filter').css({
         'background-color':backColor,
         'background-image':backImage,
         'background-repeat':backRepeat,
         'background-attachment':backAttachment,
         'background-position':backPosition
      });
   },
   _updateStyledInput: function() {
      var uiw = this;
	   var backColor = uiw._elements.$displayInput.css('background-color');
	   var backImage = uiw._elements.$displayInput.css('background-image');
	   var backRepeat = uiw._elements.$displayInput.css('background-repeat');
	   var backAttachment = uiw._elements.$displayInput.css('background-attachment');
	   var backPosition = uiw._elements.$displayInput.css('background-position');

	   $('#' + uiw._values.apexItemId + '_controls').css({
	      'background-color':backColor,
	      'background-image':backImage,
	      'background-repeat':backRepeat,
	      'background-attachment':backAttachment,
	      'background-position':backPosition
	   });
   },
   _clearLov: function() {
      var uiw = this;
      var $icon = uiw._elements.$clearButton.children('.ui-icon');
      
      if (uiw._elements.$displayInput.val() !== '') {
         if (uiw.options.useClearProtection === 'N') {
            uiw._refresh();
         } else {
            if($icon.hasClass('ui-icon-circle-close')) {
               $icon
                  .removeClass('ui-icon-circle-close')
                  .addClass('ui-icon-alert');

               uiw._values.deleteIconTimeout = setTimeout("$('#" + uiw._values.apexItemId + "_controls span.ui-icon-alert').removeClass('ui-icon-alert').addClass('ui-icon-circle-close');", 1000);
            }
            else {
               clearTimeout(uiw._values.deleteIconTimeout);
               uiw._values.deleteIconTimeout = '';
               
               uiw._refresh();
               
               $icon
                  .removeClass('ui-icon-alert')
                  .addClass('ui-icon-circle-close');
            }
         }
      }
   }
});
})(apex.jQuery);