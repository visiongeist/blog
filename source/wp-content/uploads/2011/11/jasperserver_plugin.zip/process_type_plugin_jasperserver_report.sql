set define off
set verify off
set serveroutput on size 1000000
set feedback off
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
begin wwv_flow.g_import_in_progress := true; end; 
/
 
--       AAAA       PPPPP   EEEEEE  XX      XX
--      AA  AA      PP  PP  EE       XX    XX
--     AA    AA     PP  PP  EE        XX  XX
--    AAAAAAAAAA    PPPPP   EEEE       XXXX
--   AA        AA   PP      EE        XX  XX
--  AA          AA  PP      EE       XX    XX
--  AA          AA  PP      EEEEEE  XX      XX
prompt  Set Credentials...
 
begin
 
  -- Assumes you are running the script connected to SQL*Plus as the Oracle user APEX_040000 or as the owner (parsing schema) of the application.
  wwv_flow_api.set_security_group_id(p_security_group_id=>nvl(wwv_flow_application_install.get_workspace_id,1246608038297798));
 
end;
/

begin wwv_flow.g_import_in_progress := true; end;
/
begin 

select value into wwv_flow_api.g_nls_numeric_chars from nls_session_parameters where parameter='NLS_NUMERIC_CHARACTERS';

end;

/
begin execute immediate 'alter session set nls_numeric_characters=''.,''';

end;

/
begin wwv_flow.g_browser_language := 'en'; end;
/
prompt  Check Compatibility...
 
begin
 
-- This date identifies the minimum version required to import this file.
wwv_flow_api.set_version(p_version_yyyy_mm_dd=>'2010.05.13');
 
end;
/

prompt  Set Application ID...
 
begin
 
   -- SET APPLICATION ID
   wwv_flow.g_flow_id := nvl(wwv_flow_application_install.get_application_id,101);
   wwv_flow_api.g_id_offset := nvl(wwv_flow_application_install.get_offset,0);
null;
 
end;
/

prompt  ...plugins
--
--application/shared_components/plugins/process_type/jasperserver_report
 
begin
 
wwv_flow_api.create_plugin (
  p_id => 2806612196351090 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_type => 'PROCESS TYPE'
 ,p_name => 'JASPERSERVER_REPORT'
 ,p_display_name => 'Jasperserver Report (1.0)'
 ,p_image_prefix => '#PLUGIN_PREFIX#'
 ,p_plsql_code => 
'--------------------------------------------------------------------------------'||chr(10)||
'-- copyright by Antipa & Zimmermann GesbR (http://www.nethead.at) '||chr(10)||
'-- written by Damien Antipa <damien.antipa@nethead.at> (http://damien.antipa.at)'||chr(10)||
'--'||chr(10)||
'--'||chr(10)||
'-- licensed under: Attribution-NoDerivs 3.0 Unported (CC BY-ND 3.0) '||chr(10)||
'-- http://creativecommons.org/licenses/by-nd/3.0/legalcode'||chr(10)||
'--'||chr(10)||
'-- You are allowed to use it for n'||
'on-commercial and commercial projects under'||chr(10)||
'-- the condition that you give credit to the author e.g. by a backlink.'||chr(10)||
'-------------------------------------------------------------------------------- '||chr(10)||
''||chr(10)||
'function nethead_jr_split(p_in VARCHAR2, p_separator varchar2 default ''&'') return jasperserver.type_parameter'||chr(10)||
'is'||chr(10)||
'  v_result      jasperserver.type_parameter;'||chr(10)||
'  v_pos         number;'||chr(10)||
'  v_pos_key     num'||
'ber;'||chr(10)||
'  v_tmp         varchar2(4000) := p_in || p_separator;'||chr(10)||
'  v_tmp_kv      varchar2(1050);'||chr(10)||
'begin'||chr(10)||
'  if p_in is null OR length(p_in) < 1 then'||chr(10)||
'    return v_result;'||chr(10)||
'  end if;'||chr(10)||
'  '||chr(10)||
'  loop'||chr(10)||
'    v_pos := instr(v_tmp, p_separator);'||chr(10)||
'    exit when (nvl(v_pos, 0) = 0);'||chr(10)||
'    '||chr(10)||
'    v_tmp_kv := ltrim(rtrim(substr(v_tmp, 1, v_pos - 1)));'||chr(10)||
'    v_result(substr(v_tmp_kv, 1, instr(v_tmp_kv, ''='') - 1)) := substr(v_tmp_kv,'||
' instr(v_tmp_kv, ''='') + 1);'||chr(10)||
'    '||chr(10)||
'    v_tmp := substr(v_tmp, v_pos + length(p_separator));'||chr(10)||
'  end loop;'||chr(10)||
'  return v_result;'||chr(10)||
'end nethead_jr_split;'||chr(10)||
''||chr(10)||
'function nethead_exec_jr_report ('||chr(10)||
'    p_process in apex_plugin.t_process,'||chr(10)||
'    p_plugin  in apex_plugin.t_plugin )'||chr(10)||
'    return apex_plugin.t_process_exec_result'||chr(10)||
'is'||chr(10)||
'  v_result apex_plugin.t_process_exec_result;'||chr(10)||
'  v_param jasperserver.type_parameter;'||chr(10)||
'begin'||chr(10)||
'  j'||
'asperserver.host             :=  p_plugin.attribute_01;'||chr(10)||
'  jasperserver.port             :=  TO_NUMBER(p_plugin.attribute_02);'||chr(10)||
'  jasperserver.username         :=  p_plugin.attribute_03;'||chr(10)||
'  jasperserver.password         :=  p_plugin.attribute_04;'||chr(10)||
'  jasperserver.https            :=  false;'||chr(10)||
'  jasperserver.reports_folder   :=  p_plugin.attribute_06;'||chr(10)||
'  jasperserver.output_format    :=  p_process.attribut'||
'e_01;'||chr(10)||
'  '||chr(10)||
'  jasperserver.call_report(p_process.attribute_02, nethead_jr_split(v(p_process.attribute_03)));'||chr(10)||
'  '||chr(10)||
'  return v_result;'||chr(10)||
'end nethead_exec_jr_report;'
 ,p_execution_function => 'nethead_exec_jr_report'
 ,p_attribute_01 => 'localhost'
 ,p_attribute_02 => '8084'
 ,p_attribute_03 => 'jasperadmin'
 ,p_attribute_04 => 'jasperadmin'
 ,p_attribute_06 => '/reports/samples/'
 ,p_help_text => '<p>'||chr(10)||
'	HOW TO INSTALL<br />'||chr(10)||
'	==============<br />'||chr(10)||
'	1. Install jasperserver package<br />'||chr(10)||
'	jasperserver.pkg.sql and jasperserver.pkg.body.sql<br />'||chr(10)||
'	<br />'||chr(10)||
'	2. Give the execution rights of the sys package utl_http to your apex schema user (change user)<br />'||chr(10)||
'	grant execute on utl_http to scott;<br />'||chr(10)||
'	<br />'||chr(10)||
'	3. For 11g only: configure the ACL list for the utl_http to give your apex schema user the rights to access the host (change user, host and port)<br />'||chr(10)||
'	&nbsp;begin<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp; dbms_network_acl_admin.create_acl (<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; acl&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; =&gt; &#39;utl_http.xml&#39;,<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; description =&gt; &#39;HTTP Access&#39;,<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; principal&nbsp;&nbsp; =&gt; &#39;SCOTT&#39;,<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; is_grant&nbsp;&nbsp;&nbsp; =&gt; TRUE,<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; privilege&nbsp;&nbsp; =&gt; &#39;connect&#39;,<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; start_date&nbsp; =&gt; null,<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; end_date&nbsp;&nbsp;&nbsp; =&gt; null<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp; );<br />'||chr(10)||
'	&nbsp;<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp; dbms_network_acl_admin.add_privilege (<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; acl&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; =&gt; &#39;utl_http.xml&#39;,<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; principal&nbsp; =&gt; &#39;SCOTT&#39;,<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; is_grant&nbsp;&nbsp; =&gt; TRUE,<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; privilege&nbsp; =&gt; &#39;resolve&#39;,<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; start_date =&gt; null,<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; end_date&nbsp;&nbsp; =&gt; null<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp; );<br />'||chr(10)||
'	&nbsp;<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp; dbms_network_acl_admin.assign_acl (<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; acl&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; =&gt; &#39;utl_http.xml&#39;,<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; host&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; =&gt; &#39;localhost&#39;,<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; lower_port =&gt; 8080,<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; upper_port =&gt; 8080<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp; );<br />'||chr(10)||
'	&nbsp;&nbsp;&nbsp; commit;<br />'||chr(10)||
'	&nbsp; end;<br />'||chr(10)||
'	<br />'||chr(10)||
'	4. If you want to use the plugin, just import it into your application.<br />'||chr(10)||
'	<br />'||chr(10)||
'	HOW TO USE THE PACKAGE<br />'||chr(10)||
'	=======================<br />'||chr(10)||
'	check out testcase.sql<br />'||chr(10)||
'	<br />'||chr(10)||
'	HOW TO USE THE PLUGIN<br />'||chr(10)||
'	=====================<br />'||chr(10)||
'	Everything is straight forward and most parameters are self explainable.<br />'||chr(10)||
'	If you want to use parameters for the report choose a page item which contains a string like that: param1=val1&amp;param2=val2<br />'||chr(10)||
'	&nbsp;</p>'||chr(10)||
''
 ,p_version_identifier => '1.0'
 ,p_about_url => 'http://www.nethead.at'
 ,p_plugin_comment => '--------------------------------------------------------------------------------'||chr(10)||
'-- copyright by Antipa & Zimmermann GesbR (http://www.nethead.at) '||chr(10)||
'-- written by Damien Antipa <damien.antipa@nethead.at> (http://damien.antipa.at)'||chr(10)||
'--'||chr(10)||
'--'||chr(10)||
'-- licensed under: Attribution-NoDerivs 3.0 Unported (CC BY-ND 3.0) '||chr(10)||
'-- http://creativecommons.org/licenses/by-nd/3.0/legalcode'||chr(10)||
'--'||chr(10)||
'-- You are allowed to use it for non-commercial and commercial projects under'||chr(10)||
'-- the condition that you give credit to the author e.g. by a backlink.'||chr(10)||
'--------------------------------------------------------------------------------'
  );
wwv_flow_api.create_plugin_attribute (
  p_id => 2806818776353030 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 2806612196351090 + wwv_flow_api.g_id_offset
 ,p_attribute_scope => 'APPLICATION'
 ,p_attribute_sequence => 1
 ,p_display_sequence => 10
 ,p_prompt => 'Host'
 ,p_attribute_type => 'TEXT'
 ,p_is_required => true
 ,p_default_value => 'localhost'
 ,p_is_translatable => false
  );
wwv_flow_api.create_plugin_attribute (
  p_id => 2807325356354959 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 2806612196351090 + wwv_flow_api.g_id_offset
 ,p_attribute_scope => 'APPLICATION'
 ,p_attribute_sequence => 2
 ,p_display_sequence => 20
 ,p_prompt => 'Port'
 ,p_attribute_type => 'INTEGER'
 ,p_is_required => true
 ,p_default_value => '8080'
 ,p_is_translatable => false
  );
wwv_flow_api.create_plugin_attribute (
  p_id => 2807800553357258 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 2806612196351090 + wwv_flow_api.g_id_offset
 ,p_attribute_scope => 'APPLICATION'
 ,p_attribute_sequence => 3
 ,p_display_sequence => 30
 ,p_prompt => 'Username'
 ,p_attribute_type => 'TEXT'
 ,p_is_required => true
 ,p_default_value => 'jasperadmin'
 ,p_is_translatable => false
  );
wwv_flow_api.create_plugin_attribute (
  p_id => 2808305055358482 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 2806612196351090 + wwv_flow_api.g_id_offset
 ,p_attribute_scope => 'APPLICATION'
 ,p_attribute_sequence => 4
 ,p_display_sequence => 40
 ,p_prompt => 'Password'
 ,p_attribute_type => 'TEXT'
 ,p_is_required => true
 ,p_default_value => 'jasperadmin'
 ,p_is_translatable => false
  );
wwv_flow_api.create_plugin_attribute (
  p_id => 2810106224368285 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 2806612196351090 + wwv_flow_api.g_id_offset
 ,p_attribute_scope => 'APPLICATION'
 ,p_attribute_sequence => 6
 ,p_display_sequence => 60
 ,p_prompt => 'Reports Folder'
 ,p_attribute_type => 'TEXT'
 ,p_is_required => true
 ,p_default_value => '/reports/samples/'
 ,p_is_translatable => false
  );
wwv_flow_api.create_plugin_attribute (
  p_id => 2810621462372696 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 2806612196351090 + wwv_flow_api.g_id_offset
 ,p_attribute_scope => 'COMPONENT'
 ,p_attribute_sequence => 1
 ,p_display_sequence => 10
 ,p_prompt => 'Report Format'
 ,p_attribute_type => 'SELECT LIST'
 ,p_is_required => true
 ,p_default_value => 'pdf'
 ,p_is_translatable => false
  );
wwv_flow_api.create_plugin_attr_value (
  p_id => 2812916707428160 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_attribute_id => 2810621462372696 + wwv_flow_api.g_id_offset
 ,p_display_sequence => 10
 ,p_display_value => 'PDF'
 ,p_return_value => 'pdf'
  );
wwv_flow_api.create_plugin_attr_value (
  p_id => 2813323633430105 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_attribute_id => 2810621462372696 + wwv_flow_api.g_id_offset
 ,p_display_sequence => 20
 ,p_display_value => 'Word (DOC)'
 ,p_return_value => 'doc'
  );
wwv_flow_api.create_plugin_attr_value (
  p_id => 2813800908433045 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_attribute_id => 2810621462372696 + wwv_flow_api.g_id_offset
 ,p_display_sequence => 30
 ,p_display_value => 'Word (DOCX)'
 ,p_return_value => 'docx'
  );
wwv_flow_api.create_plugin_attr_value (
  p_id => 2814209219435476 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_attribute_id => 2810621462372696 + wwv_flow_api.g_id_offset
 ,p_display_sequence => 40
 ,p_display_value => 'Excel (XLS)'
 ,p_return_value => 'xls'
  );
wwv_flow_api.create_plugin_attr_value (
  p_id => 2814621340438841 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_attribute_id => 2810621462372696 + wwv_flow_api.g_id_offset
 ,p_display_sequence => 50
 ,p_display_value => 'Excel (XLSX)'
 ,p_return_value => 'xlsx'
  );
wwv_flow_api.create_plugin_attr_value (
  p_id => 2815025150439939 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_attribute_id => 2810621462372696 + wwv_flow_api.g_id_offset
 ,p_display_sequence => 60
 ,p_display_value => 'CSV'
 ,p_return_value => 'csv'
  );
wwv_flow_api.create_plugin_attr_value (
  p_id => 2815409004444810 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_attribute_id => 2810621462372696 + wwv_flow_api.g_id_offset
 ,p_display_sequence => 70
 ,p_display_value => 'RTF'
 ,p_return_value => 'rtf'
  );
wwv_flow_api.create_plugin_attr_value (
  p_id => 2815818701447595 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_attribute_id => 2810621462372696 + wwv_flow_api.g_id_offset
 ,p_display_sequence => 80
 ,p_display_value => 'OpenDocument Text'
 ,p_return_value => 'odt'
  );
wwv_flow_api.create_plugin_attr_value (
  p_id => 2816202209452271 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_attribute_id => 2810621462372696 + wwv_flow_api.g_id_offset
 ,p_display_sequence => 90
 ,p_display_value => 'OpenDocument Spreadsheet'
 ,p_return_value => 'ods'
  );
wwv_flow_api.create_plugin_attribute (
  p_id => 2811607741378209 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 2806612196351090 + wwv_flow_api.g_id_offset
 ,p_attribute_scope => 'COMPONENT'
 ,p_attribute_sequence => 2
 ,p_display_sequence => 20
 ,p_prompt => 'Report Name'
 ,p_attribute_type => 'TEXT'
 ,p_is_required => true
 ,p_is_translatable => false
  );
wwv_flow_api.create_plugin_attribute (
  p_id => 2819129258915696 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 2806612196351090 + wwv_flow_api.g_id_offset
 ,p_attribute_scope => 'COMPONENT'
 ,p_attribute_sequence => 3
 ,p_display_sequence => 30
 ,p_prompt => 'Parameter'
 ,p_attribute_type => 'PAGE ITEM'
 ,p_is_required => false
 ,p_is_translatable => false
 ,p_help_text => 'choose a page item which contains:'||chr(10)||
''||chr(10)||
'list of key/values'||chr(10)||
'key=value'||chr(10)||
'seperator: &'||chr(10)||
''||chr(10)||
'e.g'||chr(10)||
'param1=val1&amp;param2=val2'
  );
null;
 
end;
/

commit;
begin 
execute immediate 'begin dbms_session.set_nls( param => ''NLS_NUMERIC_CHARACTERS'', value => '''''''' || replace(wwv_flow_api.g_nls_numeric_chars,'''''''','''''''''''') || ''''''''); end;';
end;
/
set verify on
set feedback on
prompt  ...done
