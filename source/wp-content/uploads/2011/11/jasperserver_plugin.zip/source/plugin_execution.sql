--------------------------------------------------------------------------------
-- copyright by Antipa & Zimmermann GesbR (http://www.nethead.at) 
-- written by Damien Antipa <damien.antipa@nethead.at> (http://damien.antipa.at)
--
--
-- licensed under: Attribution-NoDerivs 3.0 Unported (CC BY-ND 3.0) 
-- http://creativecommons.org/licenses/by-nd/3.0/legalcode
--
-- You are allowed to use it for non-commercial and commercial projects under
-- the condition that you give credit to the author e.g. by a backlink.
-------------------------------------------------------------------------------- 

function nethead_jr_split(p_in VARCHAR2, p_separator varchar2 default '&') return jasperserver.type_parameter
is
  v_result      jasperserver.type_parameter;
  v_pos         number;
  v_pos_key     number;
  v_tmp         varchar2(4000) := p_in || p_separator;
  v_tmp_kv      varchar2(1050);
begin
  if p_in is null OR length(p_in) < 1 then
    return v_result;
  end if;
  
  loop
    v_pos := instr(v_tmp, p_separator);
    exit when (nvl(v_pos, 0) = 0);
    
    v_tmp_kv := ltrim(rtrim(substr(v_tmp, 1, v_pos - 1)));
    v_result(substr(v_tmp_kv, 1, instr(v_tmp_kv, '=') - 1)) := substr(v_tmp_kv, instr(v_tmp_kv, '=') + 1);
    
    v_tmp := substr(v_tmp, v_pos + length(p_separator));
  end loop;
  return v_result;
end nethead_jr_split;

function nethead_exec_jr_report (
    p_process in apex_plugin.t_process,
    p_plugin  in apex_plugin.t_plugin )
    return apex_plugin.t_process_exec_result
is
  v_result apex_plugin.t_process_exec_result;
  v_param jasperserver.type_parameter;
begin
  jasperserver.host             :=  p_plugin.attribute_01;
  jasperserver.port             :=  TO_NUMBER(p_plugin.attribute_02);
  jasperserver.username         :=  p_plugin.attribute_03;
  jasperserver.password         :=  p_plugin.attribute_04;
  jasperserver.https            :=  false;
  jasperserver.reports_folder   :=  p_plugin.attribute_06;
  jasperserver.output_format    :=  p_process.attribute_01;
  
  jasperserver.call_report(p_process.attribute_02, nethead_jr_split(v(p_process.attribute_03)));
  
  return v_result;
end nethead_exec_jr_report;