--------------------------------------------------------------------------------
-- copyright by Antipa & Zimmermann GesbR (http://www.nethead.at) 
-- written by Damien Antipa <damien.antipa@nethead.at> (http://damien.antipa.at)
--
--
-- licensed under: Attribution-NoDerivs 3.0 Unported (CC BY-ND 3.0) 
-- http://creativecommons.org/licenses/by-nd/3.0/legalcode
--
-- You are allowed to use it for non-commercial and commercial projects under
-- the condition that you give credit to the author e.g. by a backlink.
-------------------------------------------------------------------------------- 
/*
  privileges necessary execute this as sys:
  
  grant execute on utl_http to scott;
  
  begin
    dbms_network_acl_admin.create_acl (
      acl         => 'utl_http.xml',
      description => 'HTTP Access',
      principal   => 'SCOTT',
      is_grant    => TRUE,
      privilege   => 'connect',
      start_date  => null,
      end_date    => null
    );
  
    dbms_network_acl_admin.add_privilege (
      acl        => 'utl_http.xml',
      principal  => 'SCOTT',
      is_grant   => TRUE,
      privilege  => 'resolve',
      start_date => null,
      end_date   => null
    );
  
    dbms_network_acl_admin.assign_acl (
      acl        => 'utl_http.xml',
      host       => 'localhost',
      lower_port => 8080,
      upper_port => 8080
    );
    commit;
  end;
*/
CREATE OR REPLACE PACKAGE jasperserver IS
--------------------------------------------------------------------------------
-- type definitions
--------------------------------------------------------------------------------
  TYPE type_parameter IS TABLE OF VARCHAR2(1000) INDEX BY VARCHAR2(50);
--------------------------------------------------------------------------------
-- configuration variables
--------------------------------------------------------------------------------
  host            VARCHAR2(255);
  port            NUMBER(5,0);
  path            VARCHAR2(255);
  username        VARCHAR2(255);
  password        VARCHAR2(255);
  https           BOOLEAN;
  reports_folder  VARCHAR2(255);
  output_format   VARCHAR2(50);
  
--------------------------------------------------------------------------------
-- report download
--------------------------------------------------------------------------------  
  PROCEDURE call_report(p_report_name VARCHAR2, p_parameter type_parameter);
END jasperserver;
/