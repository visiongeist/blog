--------------------------------------------------------------------------------
-- copyright by Antipa & Zimmermann GesbR (http://www.nethead.at) 
-- written by Damien Antipa <damien.antipa@nethead.at> (http://damien.antipa.at)
--
--
-- licensed under: Attribution-NoDerivs 3.0 Unported (CC BY-ND 3.0) 
-- http://creativecommons.org/licenses/by-nd/3.0/legalcode
--
-- You are allowed to use it for non-commercial and commercial projects under
-- the condition that you give credit to the author e.g. by a backlink.
-------------------------------------------------------------------------------- 
CREATE OR REPLACE PACKAGE BODY jasperserver IS
--------------------------------------------------------------------------------
-- private methods
-------------------------------------------------------------------------------- 
  g_user_agent VARCHAR2(255) := 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/A.B (KHTML, like Gecko) Chrome/X.Y.Z.W Safari/A.B.';
  

  FUNCTION build_url(p_report_name VARCHAR2, p_parameter type_parameter) RETURN VARCHAR2
    IS
    v_url     VARCHAR2(4000);
    v_key     VARCHAR2(1000);
  BEGIN
    IF https THEN
      v_url := 'https://';
    ELSE
      v_url := 'http://';
    END IF;
    
    v_url := v_url || host;
    v_url := v_url || ':' || port;
    v_url := v_url || path;
    v_url := v_url || '&' || 'j_username=' || username;
    v_url := v_url || '&' || 'j_password=' || password;
    v_url := v_url || '&' || 'reportUnit=' || reports_folder || p_report_name;
    v_url := v_url || '&' || 'output=' || output_format;
  
    v_key := p_parameter.FIRST;    
    WHILE v_key IS NOT NULL LOOP    
      v_url := v_url || '&' || v_key || '=' || p_parameter(v_key);
      v_key := p_parameter.NEXT(v_key);  
    END LOOP;
    
    RETURN v_url;
  END build_url;
--------------------------------------------------------------------------------
-- report download
--------------------------------------------------------------------------------  
  PROCEDURE call_report(p_report_name VARCHAR2, p_parameter type_parameter)
    IS
    v_file          BLOB;
  BEGIN
    v_file := get_report(p_report_name, p_parameter);
    
    owa_util.mime_header('application/' || output_format, false);
    htp.p('Content-length: ' || dbms_lob.getlength(v_file));
    htp.p('Content-Disposition: attachment; filename="' || p_report_name || '.'|| output_format ||'"');
    owa_util.http_header_close;
    
    wpg_docload.download_file(v_file);
    
    IF dbms_lob.istemporary(v_file) = 1 THEN
      dbms_lob.freetemporary(v_file);
    END IF;
  END call_report;

--------------------------------------------------------------------------------
-- report fetch
--------------------------------------------------------------------------------  
  FUNCTION get_report(p_report_name VARCHAR2, p_parameter type_parameter) RETURN BLOB
    IS
    v_url           VARCHAR2(4000);
    v_request       sys.utl_http.req;
    v_response      sys.utl_http.resp;
    v_file          BLOB;
    v_download      RAW(32767);
  BEGIN
    v_url := build_url(p_report_name, p_parameter);
    
    v_request := sys.utl_http.begin_request(v_url);
    sys.utl_http.set_header(v_request, 'User-Agent', g_user_agent);
    v_response := sys.utl_http.get_response(v_request);
    
    dbms_lob.createtemporary(v_file, TRUE, dbms_lob.session);
    
    LOOP
    BEGIN
      sys.utl_http.read_raw(v_response, v_download);
      dbms_lob.writeappend(v_file, utl_raw.length(v_download), v_download);
      EXCEPTION WHEN sys.utl_http.end_of_body THEN
        EXIT;
      END;
    END LOOP;
    
    sys.utl_http.end_response(v_response);
    
    --dbms_lob.freetemporary(v_file);
    
    RETURN v_file;
  END get_report;

--------------------------------------------------------------------------------
-- default configuration
--------------------------------------------------------------------------------
BEGIN

  host            := 'localhost';
  port            :=  8080;
  path            := '/jasperserver/flow.html?_flowId=viewReportFlow';
  username        := 'jasperadmin';
  password        := 'jasperadmin';
  https           :=  false;
  reports_folder  :=  '/reports/samples/';
  output_format   :=  'pdf';
  
END jasperserver;
/