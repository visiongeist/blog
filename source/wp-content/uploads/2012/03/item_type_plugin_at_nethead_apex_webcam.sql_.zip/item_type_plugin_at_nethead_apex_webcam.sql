set define off
set verify off
set feedback off
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
begin wwv_flow.g_import_in_progress := true; end; 
/
 
--       AAAA       PPPPP   EEEEEE  XX      XX
--      AA  AA      PP  PP  EE       XX    XX
--     AA    AA     PP  PP  EE        XX  XX
--    AAAAAAAAAA    PPPPP   EEEE       XXXX
--   AA        AA   PP      EE        XX  XX
--  AA          AA  PP      EE       XX    XX
--  AA          AA  PP      EEEEEE  XX      XX
prompt  Set Credentials...
 
begin
 
  -- Assumes you are running the script connected to SQL*Plus as the Oracle user APEX_040100 or as the owner (parsing schema) of the application.
  wwv_flow_api.set_security_group_id(p_security_group_id=>nvl(wwv_flow_application_install.get_workspace_id,17151373012351605525));
 
end;
/

begin wwv_flow.g_import_in_progress := true; end;
/
begin 

select value into wwv_flow_api.g_nls_numeric_chars from nls_session_parameters where parameter='NLS_NUMERIC_CHARACTERS';

end;

/
begin execute immediate 'alter session set nls_numeric_characters=''.,''';

end;

/
begin wwv_flow.g_browser_language := 'en'; end;
/
prompt  Check Compatibility...
 
begin
 
-- This date identifies the minimum version required to import this file.
wwv_flow_api.set_version(p_version_yyyy_mm_dd=>'2011.02.12');
 
end;
/

prompt  Set Application ID...
 
begin
 
   -- SET APPLICATION ID
   wwv_flow.g_flow_id := nvl(wwv_flow_application_install.get_application_id,53775);
   wwv_flow_api.g_id_offset := nvl(wwv_flow_application_install.get_offset,0);
null;
 
end;
/

prompt  ...plugins
--
--application/shared_components/plugins/item_type/at_nethead_apex_webcam
 
begin
 
wwv_flow_api.create_plugin (
  p_id => 58823121604776406111 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_type => 'ITEM TYPE'
 ,p_name => 'AT.NETHEAD.APEX.WEBCAM'
 ,p_display_name => 'Webcam (1.0)'
 ,p_image_prefix => '#PLUGIN_PREFIX#'
 ,p_plsql_code => 
'function nethead_webcam_ext_render('||unistr('\000a')||
'  p_item          in apex_plugin.t_page_item, '||unistr('\000a')||
'  p_plugin        in apex_plugin.t_plugin, '||unistr('\000a')||
'  p_value         in varchar2, '||unistr('\000a')||
'  p_is_readonly   in boolean,'||unistr('\000a')||
'  p_is_printer_friendly in boolean) '||unistr('\000a')||
'  return apex_plugin.t_page_item_render_result'||unistr('\000a')||
'is'||unistr('\000a')||
'  l_name varchar2(30);'||unistr('\000a')||
'  l_result apex_plugin.t_page_item_render_result;'||unistr('\000a')||
'  '||unistr('\000a')||
'  l_height              NUMBER := TO_NUMBER(p_it'||
'em.attribute_01);'||unistr('\000a')||
'  l_width               NUMBER := TO_NUMBER(p_item.attribute_02);'||unistr('\000a')||
'  l_items_to_submit     VARCHAR2(32767) := p_item.attribute_04;'||unistr('\000a')||
'begin'||unistr('\000a')||
'    if apex_application.g_debug then'||unistr('\000a')||
'      apex_plugin_util.debug_page_item ('||unistr('\000a')||
'        p_plugin              => p_plugin,'||unistr('\000a')||
'        p_page_item           => p_item,'||unistr('\000a')||
'        p_value               => p_value,'||unistr('\000a')||
'        p_is_readonly         => p_is_read'||
'only,'||unistr('\000a')||
'        p_is_printer_friendly => p_is_printer_friendly );'||unistr('\000a')||
'    end if;'||unistr('\000a')||
''||unistr('\000a')||
'    l_name := apex_plugin.get_input_name_for_page_item(false);'||unistr('\000a')||
'    htp.p(''<div id="''||p_item.name|| ''" class="nethead_webcam"></div>'');'||unistr('\000a')||
''||unistr('\000a')||
'    apex_css.add_file ('||unistr('\000a')||
'      p_name => ''webcam_plugin'','||unistr('\000a')||
'      p_directory => p_plugin.file_prefix,'||unistr('\000a')||
'      p_version => null '||unistr('\000a')||
'    );'||unistr('\000a')||
'    apex_javascript.add_library ('||unistr('\000a')||
'        p_name      '||
'=> ''jquery.webcam'','||unistr('\000a')||
'        p_directory => p_plugin.file_prefix,'||unistr('\000a')||
'        p_version   => null );'||unistr('\000a')||
''||unistr('\000a')||
'    apex_javascript.add_onload_code ('||unistr('\000a')||
'        p_code => '''||unistr('\000a')||
'        var pos = 0, ctx = null, image = [], audio = null;'||unistr('\000a')||
'        var itemsToSubmit = ("''|| l_items_to_submit ||''").split(",");'||unistr('\000a')||
'        var valuesToSubmit = "";'||unistr('\000a')||
'        '||unistr('\000a')||
'        var canvas = document.createElement("canvas");'||unistr('\000a')||
'        canvas.setA'||
'ttribute("width", ''|| l_width ||'');'||unistr('\000a')||
'        canvas.setAttribute("height", ''|| l_height ||'');'||unistr('\000a')||
'        '||unistr('\000a')||
'        jQuery("#''|| p_item.name ||''").webcam({'||unistr('\000a')||
'            width: ''|| l_width ||'','||unistr('\000a')||
'            height: ''|| l_height ||'','||unistr('\000a')||
'            mode: "callback",'||unistr('\000a')||
'            swffile: "''|| p_plugin.file_prefix ||''jscam.swf",'||unistr('\000a')||
'            onTick: function() {},'||unistr('\000a')||
'            onSave: function(data) {             '||
'  '||unistr('\000a')||
'              var col = data.split(";");'||unistr('\000a')||
'              var img = image;'||unistr('\000a')||
'          '||unistr('\000a')||
'              for(var i = 0; i < ''|| l_width ||''; i++) {'||unistr('\000a')||
'                  var tmp = parseInt(col[i]);'||unistr('\000a')||
'                  img.data[pos + 0] = (tmp >> 16) & 0xff;'||unistr('\000a')||
'                  img.data[pos + 1] = (tmp >> 8) & 0xff;'||unistr('\000a')||
'                  img.data[pos + 2] = tmp & 0xff;'||unistr('\000a')||
'                  img.data[pos + 3] = 0xff;'||unistr('\000a')||
'  '||
'                pos+= 4;'||unistr('\000a')||
'              }'||unistr('\000a')||
'          '||unistr('\000a')||
'              if (pos >= 4 * ''|| l_width ||'' * ''|| l_height ||'') {'||unistr('\000a')||
'                  ctx.putImageData(img, 0, 0);'||unistr('\000a')||
'                  pos = 0;'||unistr('\000a')||
'              }'||unistr('\000a')||
'            },'||unistr('\000a')||
'            onCapture: function() {'||unistr('\000a')||
'              var $this = jQuery("#''|| p_item.name ||''");'||unistr('\000a')||
'              var $flash = $this.find(".flash");'||unistr('\000a')||
'              '||unistr('\000a')||
'              audi'||
'o.play();'||unistr('\000a')||
'              $flash.css("display", "block");'||unistr('\000a')||
'              $flash.fadeOut(500, function () {'||unistr('\000a')||
'                    $flash.css("opacity", 1);'||unistr('\000a')||
'                    '||unistr('\000a')||
'                    jQuery(canvas).show();'||unistr('\000a')||
'                    jQuery("#nethead-webcam-photo").hide();'||unistr('\000a')||
'                    jQuery("#nethead-webcam-save").show();'||unistr('\000a')||
'                    jQuery("#nethead-webcam-cancel").show();'||unistr('\000a')||
'      '||
'        });'||unistr('\000a')||
'              '||unistr('\000a')||
'              ctx = canvas.getContext("2d");'||unistr('\000a')||
'              image = ctx.getImageData(0, 0, ''|| l_width ||'', ''|| l_height ||'');'||unistr('\000a')||
'              '||unistr('\000a')||
'              webcam.save(); '||unistr('\000a')||
'            },'||unistr('\000a')||
'            debug: function (type, string) {'||unistr('\000a')||
'              console.log(type + ": " + string);'||unistr('\000a')||
'            },'||unistr('\000a')||
'            onLoad: function() {'||unistr('\000a')||
'              var $this = jQuery("#''|| p_item'||
'.name ||''");'||unistr('\000a')||
'              '||unistr('\000a')||
'              $this.css({'||unistr('\000a')||
'                width: ''|| l_width ||''+30,'||unistr('\000a')||
'                height: ''|| l_height ||'''||unistr('\000a')||
'              });'||unistr('\000a')||
'              $this.append(''''<a href="#" id="nethead-webcam-photo" class="nethead-webcam-btn"><img src="''|| p_plugin.file_prefix ||''photo_24.png" /></a>'''');'||unistr('\000a')||
'              $this.append(''''<a href="#" id="nethead-webcam-save" class="nethead-webcam'||
'-btn"><img src="''|| p_plugin.file_prefix ||''save_24.png" />'''');'||unistr('\000a')||
'              $this.append(''''<a href="#" id="nethead-webcam-cancel" class="nethead-webcam-btn"><img src="''|| p_plugin.file_prefix ||''cancel_24.png" />'''');'||unistr('\000a')||
'              $this.append(canvas);'||unistr('\000a')||
'              $this.append(''''<audio ><source src="''|| p_plugin.file_prefix ||''camera1.wav"></audio>'''');'||unistr('\000a')||
'              $this.append(''''<div class="'||
'flash" style="width:''|| l_width ||''px; height:''|| l_height ||''px;"></div>'''');'||unistr('\000a')||
'              $this.append(''''<div class="loading" style="width:''''+ $this.width() +''''px; height:''''+ $this.height() +''''px; line-height:''''+ $this.height() +''''px;"><img src="''|| p_plugin.file_prefix ||''ajax-loader.gif" /></div>'''');'||unistr('\000a')||
'              jQuery("#nethead-webcam-save").hide();'||unistr('\000a')||
'              jQuery("#nethead-webcam-can'||
'cel").hide();'||unistr('\000a')||
'              '||unistr('\000a')||
'              jQuery("#nethead-webcam-photo").bind("click", function(e) {'||unistr('\000a')||
'                e.preventDefault();'||unistr('\000a')||
'                '||unistr('\000a')||
'                webcam.capture();'||unistr('\000a')||
'              });'||unistr('\000a')||
'              '||unistr('\000a')||
'              jQuery("#nethead-webcam-save").bind("click", function(e) {'||unistr('\000a')||
'                e.preventDefault();'||unistr('\000a')||
'                '||unistr('\000a')||
'                var $loading = $this.find(".loading'||
'");'||unistr('\000a')||
'                $loading.show();'||unistr('\000a')||
'                '||unistr('\000a')||
'                var dataUrl = canvas.toDataURL("image/jpeg");'||unistr('\000a')||
'                var clob_ob = new apex.ajax.clob('||unistr('\000a')||
'                  function(){'||unistr('\000a')||
'                    var rs = p.readyState;'||unistr('\000a')||
'        '||unistr('\000a')||
'                    if (rs == 4){'||unistr('\000a')||
'                      jQuery.each(itemsToSubmit, function(i, val) {'||unistr('\000a')||
'                        valuesToSubmit += $v(val) '||
'+ ",";'||unistr('\000a')||
'                      });'||unistr('\000a')||
'                      valuesToSubmit = valuesToSubmit.substring(0, valuesToSubmit.length-1);'||unistr('\000a')||
'                      '||unistr('\000a')||
'                      var args = { '||unistr('\000a')||
'                          p_flow_id: $v("pFlowId"), '||unistr('\000a')||
'                          p_flow_step_id: $v("pFlowStepId"), '||unistr('\000a')||
'                          p_instance: $v("pInstance"),'||unistr('\000a')||
'                          p_request: "PLUGIN='||
'''|| apex_plugin.get_ajax_identifier ||''",'||unistr('\000a')||
'                          p_arg_names: ("''|| p_item.name ||''," + "''|| l_items_to_submit ||''").split(","),'||unistr('\000a')||
'                          p_arg_values:  ("CLOB," + valuesToSubmit).split(",")'||unistr('\000a')||
'                      };'||unistr('\000a')||
'                      '||unistr('\000a')||
'                      if(args.p_arg_names.length == 0) {'||unistr('\000a')||
'                        delete args.p_arg_names;'||unistr('\000a')||
'                   '||
'     delete args.p_arg_values;'||unistr('\000a')||
'                      }'||unistr('\000a')||
'                      '||unistr('\000a')||
'                      $.post("wwv_flow.show", args,'||unistr('\000a')||
'                      function(data) {'||unistr('\000a')||
'                          apex.event.trigger("#''|| p_item.name ||''", "imagesaved", null);'||unistr('\000a')||
'                          $loading.hide();'||unistr('\000a')||
'                          jQuery(canvas).hide();'||unistr('\000a')||
'                          jQuery("#nethead-webcam'||
'-photo").show();'||unistr('\000a')||
'                          jQuery("#nethead-webcam-save").hide();'||unistr('\000a')||
'                          jQuery("#nethead-webcam-cancel").hide();'||unistr('\000a')||
'                      });'||unistr('\000a')||
'                    } '||unistr('\000a')||
'                  }'||unistr('\000a')||
'                );'||unistr('\000a')||
'                  '||unistr('\000a')||
'                clob_ob._set(dataUrl);'||unistr('\000a')||
'              });'||unistr('\000a')||
'              '||unistr('\000a')||
'              jQuery("#nethead-webcam-cancel").bind("click", function(e)'||
' {'||unistr('\000a')||
'                e.preventDefault();'||unistr('\000a')||
'              '||unistr('\000a')||
'                jQuery(canvas).hide();'||unistr('\000a')||
'                jQuery("#nethead-webcam-photo").show();'||unistr('\000a')||
'                jQuery("#nethead-webcam-save").hide();'||unistr('\000a')||
'                jQuery("#nethead-webcam-cancel").hide();'||unistr('\000a')||
'              });'||unistr('\000a')||
'              '||unistr('\000a')||
'              audio = $this.find("audio")[0];'||unistr('\000a')||
'              audio.load();'||unistr('\000a')||
'            }'||unistr('\000a')||
'        });'' '||unistr('\000a')||
'    '||
');'||unistr('\000a')||
'    '||unistr('\000a')||
'    return l_result;'||unistr('\000a')||
'end nethead_webcam_ext_render;'||unistr('\000a')||
''||unistr('\000a')||
'function nethead_webcam_ext_ajax ('||unistr('\000a')||
'	p_item   in apex_plugin.t_page_item,'||unistr('\000a')||
'	p_plugin in apex_plugin.t_plugin )'||unistr('\000a')||
'return apex_plugin.t_page_item_ajax_result'||unistr('\000a')||
'AS'||unistr('\000a')||
'	l_result            apex_plugin.t_page_item_ajax_result;'||unistr('\000a')||
'  l_plsql             p_item.attribute_05%type := p_item.attribute_05;'||unistr('\000a')||
'BEGIN'||unistr('\000a')||
'  apex_plugin_util.execute_plsql_code ('||unistr('\000a')||
'        p'||
'_plsql_code => l_plsql '||unistr('\000a')||
'  );'||unistr('\000a')||
'  '||unistr('\000a')||
'	return l_result;'||unistr('\000a')||
'END nethead_webcam_ext_ajax;'
 ,p_render_function => 'nethead_webcam_ext_render'
 ,p_ajax_function => 'nethead_webcam_ext_ajax'
 ,p_substitute_attributes => true
 ,p_version_identifier => '1.0'
  );
wwv_flow_api.create_plugin_attribute (
  p_id => 58823448618129649314 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 58823121604776406111 + wwv_flow_api.g_id_offset
 ,p_attribute_scope => 'COMPONENT'
 ,p_attribute_sequence => 1
 ,p_display_sequence => 10
 ,p_prompt => 'Height'
 ,p_attribute_type => 'NUMBER'
 ,p_is_required => true
 ,p_default_value => '240'
 ,p_display_length => 3
 ,p_is_translatable => false
  );
wwv_flow_api.create_plugin_attribute (
  p_id => 58823453124017650958 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 58823121604776406111 + wwv_flow_api.g_id_offset
 ,p_attribute_scope => 'COMPONENT'
 ,p_attribute_sequence => 2
 ,p_display_sequence => 20
 ,p_prompt => 'Width'
 ,p_attribute_type => 'NUMBER'
 ,p_is_required => true
 ,p_default_value => '320'
 ,p_display_length => 3
 ,p_is_translatable => false
  );
wwv_flow_api.create_plugin_attribute (
  p_id => 58824262306214027764 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 58823121604776406111 + wwv_flow_api.g_id_offset
 ,p_attribute_scope => 'COMPONENT'
 ,p_attribute_sequence => 4
 ,p_display_sequence => 40
 ,p_prompt => 'Items to submit'
 ,p_attribute_type => 'PAGE ITEMS'
 ,p_is_required => false
 ,p_is_translatable => false
  );
wwv_flow_api.create_plugin_attribute (
  p_id => 58824422535891604017 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 58823121604776406111 + wwv_flow_api.g_id_offset
 ,p_attribute_scope => 'COMPONENT'
 ,p_attribute_sequence => 5
 ,p_display_sequence => 50
 ,p_prompt => 'PL/SQL execution'
 ,p_attribute_type => 'PLSQL'
 ,p_is_required => true
 ,p_default_value => 'DECLARE'||unistr('\000a')||
'  c_collection_name   constant varchar2(200) := ''CLOB_CONTENT'';'||unistr('\000a')||
'  l_blob              BLOB;'||unistr('\000a')||
'BEGIN'||unistr('\000a')||
'  select apex_web_service.clobbase642blob(substr(clob001, instr(clob001, '','')+1, length(clob001))) into l_blob'||unistr('\000a')||
'    from apex_collections'||unistr('\000a')||
'    where collection_name = c_collection_name;'||unistr('\000a')||
'  '||unistr('\000a')||
'  insert into table1(id, img) values (1, l_blob);'||unistr('\000a')||
'END;'
 ,p_is_translatable => false
 ,p_help_text => 'DECLARE'||unistr('\000a')||
'  l_clob              CLOB;'||unistr('\000a')||
'  c_collection_name   constant varchar2(200) := ''CLOB_CONTENT'';'||unistr('\000a')||
'  l_blob              BLOB;'||unistr('\000a')||
'BEGIN'||unistr('\000a')||
'  select substr(clob001, instr(clob001, '','')+1, length(clob001)) into l_clob'||unistr('\000a')||
'    from apex_collections'||unistr('\000a')||
'    where collection_name = c_collection_name;'||unistr('\000a')||
'  l_blob := apex_web_service.clobbase642blob(l_clob);'||unistr('\000a')||
'  '||unistr('\000a')||
'  insert into table1(id, img) values (1, l_blob);'||unistr('\000a')||
'END;'
  );
wwv_flow_api.create_plugin_event (
  p_id => 59337586905442049649 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 58823121604776406111 + wwv_flow_api.g_id_offset
 ,p_name => 'imagesaved'
 ,p_display_name => 'Image was sent to server'
  );
null;
 
end;
/

 
begin
 
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '43575308E80E000078DAB4574F73DB54105FFD712C276DD2041AA7250D2E84B409C52D256D80D226A9D3A6611ADBD80D578F623F3B1A6C494872D24C2FDCE8A933CC309EE1C085035738C0572807F8201CE11398DD7DB2A51837C9010E91DF7BFBE7EDFE';
wwv_flow_api.g_varchar2_table(2) := '7EBB2BC585335F0174006614C8A9DD6E777562140014FC5B53FEC2E7CB94C2BBD5F1149F2B506D5A2E745323B885A2149D9726C54AA56856BF301BC2CF7E5ACE992DE88E67C749EDF9DFEA2390479546D3D9359BE07A4EE00487AE809669D9B004E5433F';
wwv_flow_api.g_varchar2_table(3) := '102DF045B5ED59C12198CDA673B0E1B0B4E2394E002DA72620EF64AA664B786686B619D713BEB0836B993AEA5B7623B38B1164B359109EE778702076513B5B13BBED06D49BA6BF07E269203C1B2378102EB66CFCAD9B550155F4015FB6CD26DD9FE35BC0';
wwv_flow_api.g_varchar2_table(4) := 'C61F1F9AC26E047BB053BE9FF9DCAA092793435FBE5C838C071A2200C72E0766D0F6A14AB14A17D9ED76206ABDCD8EDD8A6D337EE0B82E6E6D27B0EA87D1A9E991922F82CFC270D06F43C09EB01A7B011C58358C06A5DB744DD57483B627C0ACD5729801';
wwv_flow_api.g_varchar2_table(5) := '2100BEB92F4821D78F4DAE1E5B7E00FB326C22D20C02B3BAB7EDEC5B225CCB9C2A4FA1721803FBC0F4333511882A869585DD76BD2E3CA859BEDB340FE1BE15B44C77C30C4C4C80622122C21CB2E0079E20E27BBFBD702DC27D1F89A83685E96DF57635CF';
wwv_flow_api.g_varchar2_table(6) := '3CE8F1E6D8B95039F25BB76CCBDF23C77DA52716652C82BE8F75CFC3B0AA3D3028FDA2F55434E14E645426843041424AD652D569B95653D432969D25491D3719E23FE3BBA26AD52DBA74C7F6DBAEEB506A449E87ACB07516D6CB65BCC673DC874DB3E143';
wwv_flow_api.g_varchar2_table(7) := '47050366A7A6BE5761698C36CA2C1FBD30A873B40BF8F81A9BA6D0D1410743CDE34649CB8D2675128BF08BD64981A127A9CF8C043B18C9D333594AD38FC147A93CDD7231BC127D18A9BEA4F09D0AF3D0390BC6A831669C496AE4E92C0BC7D9D3043FCFC5';
wwv_flow_api.g_varchar2_table(8) := 'FD4DB2BFF3317F937D49A19380240E8A2EC6ABA6690332138D1D4CB1DA6BECF375CA494F630063E44AD78A520D73D474FD11DD7113068C748D4DCF6F9174429AF14DE82501F8F8B5DB4982AE72080D52BADC0B730C8C69143054D263BA44D9F7714124A7';
wwv_flow_api.g_varchar2_table(9) := '39DA48DCD1402511EEA6F35B4CD6253554E7337ACEBC18A7F9A62D826AD975079E01A5A01A17283F767EB18E865320D97B8336598AB5C4B8CF1A978EC51D15175971EE6445AA974948D670C19924E9E848B06F229129842A3943920C4B2EB344AEDFCA23';
wwv_flow_api.g_varchar2_table(10) := '7E497DD0EC6DC9BF3C9ACF77461197F957C5F24E5C79412A2F9C4AF98A54BE722AE5AB52F9EA71CAE74012BE682C493559A7EFC6FD4C73CA4A245D64F36BF1925F241DE33D06B530789C95C7FD4EBA7E4227853D3D1FD54D60B504CC2943CA4D8B1FDE08';
wwv_flow_api.g_varchar2_table(11) := '0F47A8AA12702F6AC01BAFA4528DC2789F8537CB050AF28313AA89BC2E87F7A6F2DC6F33400E21AA8D5B0C5142A140749543C32A8F0F00C4640E6447D2870377E459561995630167044B09FECD3E0FD2FDED987BCC3684EDF6006C537184564284E620E2';
wwv_flow_api.g_varchar2_table(12) := '7725E257CED80F4BE95E22BACA99B56080D378183718928FB8718C8FA564386408EB9D939BD48428E531F2F9499CA4215357CEA695BE0986F7A716A1C4F16A517A774B8510AAABFD17451051776FED3F19CDB3D019C12C746D603C531BFCDEE582E83176';
wwv_flow_api.g_varchar2_table(13) := 'E5C599FE80ACC1CF1081DF987A4CBEA6212D47E6D118F89E67C7CEEFFF73DA0D16DE822CBC114C835EFDF08732A447182FB444147E1CD6BADFB0D1EA51A3DFE0081BFF821DCB454BD2E73623F22D23B2C60CC5EC12915DA2C87BB24B24D794D0EE160D27';
wwv_flow_api.g_varchar2_table(14) := '5D47061371A46479AF9736A5434C5537EE6FF6F8FFA98BC0E349EE981A45B562171F3FD01BCE58389A9B057238E0F23A4FC78D93BF33107374B7C4EA0F4EAB2E67EFC3537CC5607C1AE6AD1686907CABDF321BCAA9664244F1F290D9B33C6CF6449CA911';
wwv_flow_api.g_varchar2_table(15) := '676A31360D8770ADC5ED62ADA917256F68A70F72AD617FEAAFE23A6C67C9B51671AD9DCC75349496798EF75E07D10B2736892664FEAAAE485A36EF522608F5B45A900B6222458BC9E40EBF5FF974A5275EC6C508F057EB6A0156B51CEA3CBF8407DB4FD6';
wwv_flow_api.g_varchar2_table(16) := 'CBB9CAF6FA561E823DCB0FFF83E4FF083942FAFC4A879FD63D16540E4C2BA5610DB7FF000000FFFF03000B88B675';
null;
 
end;
/

 
begin
 
wwv_flow_api.create_plugin_file (
  p_id => 58823138204434409762 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 58823121604776406111 + wwv_flow_api.g_id_offset
 ,p_file_name => 'jscam_canvas_only.swf'
 ,p_mime_type => 'application/x-shockwave-flash'
 ,p_file_content => wwv_flow_api.g_varchar2_table
  );
null;
 
end;
/

 
begin
 
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000018000000180806000000E0773DF80000001974455874536F6674776172650041646F626520496D616765526561647971C9653C000001AF4944415478DAAC56CB71C2400C5D76B8E354E0741077105301A4';
wwv_flow_api.g_varchar2_table(2) := '82B883F8CC8974402A003A708E9C5877103A800E4C07D132CF8C2224E338D18CC6CC7EDE3E3D49BB8C178B85B3EC998C3E05794EFE28A61BF2405ED575BDB53046DA0184FB449F1580FBD891BCA4833EE58457C0DFE8F3F50B7087E82ADABB269F9807C4';
wwv_flow_api.g_varchar2_table(3) := '0560EE0C3996F080316951CEC00FF18279A1841EC71EC8A7E4EFF029C911C7E6CA211927E9019E2ACC2B2CDE1A05E08C032E91D0FC8C47B0140B620E5EC8CF1DBAAF9588B95D088F76BB5D0A29B8DE194970EA606E81C7BD098FC42B615603C10B45E6B9';
wwv_flow_api.g_varchar2_table(4) := '57CA7133409602CD26F7E65E84E468616DB0BF07EE94C813DFA7A1FA80330BB2D19A7F047752118F92E480933F80B78DF6E380A3CCFC50F0B6B9F84DE0A566E8C221CCB5CE0EB1D1268822B993EB42BB36DAA2C3DB116ECA94169C8D1BB43773BC1F9564';
wwv_flow_api.g_varchar2_table(5) := '1F4BDEB37BE3D8C51C5D6CE91E1405CAEB658728E646C9C685AFE4291B4B31B607F34489F8107F8CD9E001602BB121BB737DDC10E2727A7689392431EF90ABCB1A30FFE0986365E101AC4B78D2037C8337E5247375FD576125916C86A832E5390DC881F9';
wwv_flow_api.g_varchar2_table(6) := '307D0B30000E97B13173EEDF070000000049454E44AE426082';
null;
 
end;
/

 
begin
 
wwv_flow_api.create_plugin_file (
  p_id => 58823630107405790926 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 58823121604776406111 + wwv_flow_api.g_id_offset
 ,p_file_name => 'cancel_24.png'
 ,p_mime_type => 'image/png'
 ,p_file_content => wwv_flow_api.g_varchar2_table
  );
null;
 
end;
/

 
begin
 
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000018000000180806000000E0773DF80000001974455874536F6674776172650041646F626520496D616765526561647971C9653C0000008D4944415478DA62DCB973E77B06060601064C70808178E080C44E';
wwv_flow_api.g_varchar2_table(2) := '3878F0E04210A3B5B595810587E120E08C43FC1412DB0C4AFF45125B606F6FCF00B3848981360064493C2D2D005B426B0B18E862010B197ACC868C0FFE0E8938189EA9889902F3FE8E8C20C255729295F158A8996B477D30387D409764FA01ADE2DF4B25';
wwv_flow_api.g_varchar2_table(3) := 'B341E63230FEFFFF9FA63E000830000E611DAE1721A8AB0000000049454E44AE426082';
null;
 
end;
/

 
begin
 
wwv_flow_api.create_plugin_file (
  p_id => 58823638604602792160 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 58823121604776406111 + wwv_flow_api.g_id_offset
 ,p_file_name => 'save_24.png'
 ,p_mime_type => 'image/png'
 ,p_file_content => wwv_flow_api.g_varchar2_table
  );
null;
 
end;
/

 
begin
 
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000018000000180806000000E0773DF80000001974455874536F6674776172650041646F626520496D616765526561647971C9653C000001204944415478DAD456DD0D82400CE60CEFDC06BA8138013A816E00';
wwv_flow_api.g_varchar2_table(2) := '6CC006F2C23B1B8023F0CA8BB2016EA013A8139C3DD34B1AE4E70E43884DBE87B6D0AFD78F5E6042086B4A5B58139B5D966557EE01E01A356AC0A619ACAACA4A92A4F7045CB34977D61149822340B4C0C4BEDEF73CCF5704F144CDA7BA23CA0107004370';
wwv_flow_api.g_varchar2_table(3) := 'F42F2D6233A2091F227802B680105090F80BFD1D20F8650F64F10AE000B2C68C338C9F08898BB95A87408EE58A456E2D9D0618572417D313C44428DEB3272915D484E04E3AED33952F665DB459089644ECA11D91B61F2B7284FBD0B5271179CE88408AB7';
wwv_flow_api.g_varchar2_table(4) := 'C6A55AB59C24C7B8CCFBB833C61AC86FDBC32221B92A18FAAA783E56648E245963C60EFA670D8D2C5BE3430874EE9C0E8D26BDAE3FC2B3BFFFAB780B3000C13649D0C105CE970000000049454E44AE426082';
null;
 
end;
/

 
begin
 
wwv_flow_api.create_plugin_file (
  p_id => 58823647134997793319 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 58823121604776406111 + wwv_flow_api.g_id_offset
 ,p_file_name => 'photo_24.png'
 ,p_mime_type => 'image/png'
 ,p_file_content => wwv_flow_api.g_varchar2_table
  );
null;
 
end;
/

 
begin
 
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '52494646FE42000057415645666D7420100000000100010022560000225600000100080064617461804200008080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080';
wwv_flow_api.g_varchar2_table(2) := '80808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080';
wwv_flow_api.g_varchar2_table(3) := '80808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080';
wwv_flow_api.g_varchar2_table(4) := '80808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080';
wwv_flow_api.g_varchar2_table(5) := '80808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080';
wwv_flow_api.g_varchar2_table(6) := '80808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080';
wwv_flow_api.g_varchar2_table(7) := '80808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080808080';
wwv_flow_api.g_varchar2_table(8) := '8080808080808080808080808080818080808180808180808081818080807F8180807B81837E7F8081838382807F7D807E7F838084807B7C8386867E7C8585837F7B787F7E807E7A808589848483818081827F7C7F817E7D7B7D7980868589838182807E';
wwv_flow_api.g_varchar2_table(9) := '7E827E7D7F7D7D7E82848083858285817F817F7B7B7B7E7E8083848182838283837E7D7E797A7C7E818683837C7E7C8286868A838376747A7E7F8180838887837B7B82867F7A7B81837D7F7E7E7F8285838081838177787E8281828583807F8181807F82';
wwv_flow_api.g_varchar2_table(10) := '807C7C7F83807F7D80828286867F7C7E8080828283807B81827F7F81898380817E807E7F7E7E7F8287817E7F7F8384807F7D7D767D8275887F707C817498955A8FA06077818488778496865F6B80A7897173928B5572968A768A916979968E926A5C4B82';
wwv_flow_api.g_varchar2_table(11) := 'A61F397E345FE2F57F2225AB9CADDFF6D9915D0389CA5D4E210D3BE1F9D58D042E5B78AF97519AE2F7F6D4664366367DA9BEAF7DB0A8392A704B41D3CF1B679B4A99895791B07386C2723564AAB4B2A56119002493BAF0C66A6C75527DACC4EDB94F3FB3';
wwv_flow_api.g_varchar2_table(12) := 'A93966793262CBB08D65222B6C71A5A3667797A7A66E7A9C756BA64874CDA38B892A4AB59D78886271658397787A9DB9A451697B576F8BA08572948669517096857D828474527D8DA19F9C7D6A80907C6B717E70857F85735C798CA49F9D8D6581996C67';
wwv_flow_api.g_varchar2_table(13) := '9A8E607866557F969C7E7468688789897B777B7C898F9D88717684867C898C81787D7E6B72858381808F8A76828C848080807D787C717B8B858386807076758383898975787289948E8C818D77627F85788A8777808F7C76887A6E8991838F8672757E77';
wwv_flow_api.g_varchar2_table(14) := '7F8F89827F706B83868A8E7D777A85827F7C82888A7E7E7F8883857E727B89828287787980848183897B81887E7D827A7681817E85847F82857F7A777D7E716C797C818785898DA7A785767D92817D92947877898E8B827E7A8076867469646967717A76';
wwv_flow_api.g_varchar2_table(15) := '666E92988793CC7C303A7FF4512933ACBC0A3C6CD04361F7B55F28B0326174E8E8D4760180DE83BFAD6E79324DD26E9A7B5E094FC9DDA6917A11BDF698614870360E84DBD49377883D5BE3F461002E95C0A3ECBD364CBA92506B58BB5F327595BCC89857';
wwv_flow_api.g_varchar2_table(16) := '2C68A69479A093BBA8604A4B87777082809293B789726F667D6C6F8D9DBFA562627786957F566385967C7F798F838C8261839BB76F5D8587787287937279755E64808F8593A29486745B7082807A8B8A7A92868186797576858A778F8C808B807E787F78';
wwv_flow_api.g_varchar2_table(17) := '7A7D8182958F797D7970858682797B827A7E7D84867E777685928B76738283888675747F807E7D828C938B7F7B767778767C8387858884827F767D786E7C848C8F8B897B85837E7E7D827B7C7D7E88858281797D888D81787D857F7F7E79747678828183';
wwv_flow_api.g_varchar2_table(18) := '83818285828182817A7B7A7B7B81837D82837F7F817C8287828483838381827A7D7A7C828688817C7E7E7F7B7F848081827D80837F7C7D7E8B837C7E7E7D808480817C7D82807F807D807D85817D7F7E7D83807F848A837A7E7F80817F7D7C8487817F7B';
wwv_flow_api.g_varchar2_table(19) := '7F7F7F7E8181818181838181837F7F7C808584827E7F7F7D81807E8281828280847C79808081807E7E7F828081868784807D8080837E7E837C7B8082807C7D808484817D7F7D7D83868281847D7E8181828080838180807E7F7C7E828181818283838482';
wwv_flow_api.g_varchar2_table(20) := '7E7E7F807D7D827F7C7F838381807F7D787B8285828187858283808080817F7D7F808280818180817D7E81807E7C7F7E8184807F7E8080818382827D7B7E8080808281808183818081807F7D7D84827F7D7E838385848181817D7D817F8080817F7E8381';
wwv_flow_api.g_varchar2_table(21) := '807F7F807F82827F7E828581808082807E7D7E7E7F8384818081817F7C7C7D7F828384807F817F7D7E808184847E7C7E7F7F81827F8180807F7E808181807E7D81817F7E7D8084838081807E7D7D7F80818181817F7F7E7E82818180808281807E818280';
wwv_flow_api.g_varchar2_table(22) := '7D7E807D7C7D81838483807E7D80818181807F818281807F80807F7F82837F7F807F7F7F807E7D8082807E7D7F7F807F7F808081807F7E808182807F808281838381827F7E8080808183817F7F80817E80817E7C7F7F7E7F82847F7F8181817F7E7E8281';
wwv_flow_api.g_varchar2_table(23) := '7F7F8080807F808282808085817F82818082817E7D7F807F828283847F7E7F817F7E7F808183837F7D7F817D7D7F80838484827F7F807F7E7F8181808080818382807F7F807E7D7F818181817F7F808281817F7F81818181807F80807F7F82837E7B7F81';
wwv_flow_api.g_varchar2_table(24) := '808082807E7E81807F8082827E7F8080808383807E7F8281807E80828280818281817E7E7F818383817F7F81808080807F80817F7E7F82827F7E807F7E7E7F7F80818382807E7F7F808182818080817F7D81817F7E7F808081808080807F7F8180808180';
wwv_flow_api.g_varchar2_table(25) := '7F807F808181807E8081818181808081808080807E80827E8181827E817E7E8080827F7F7F818081817F81827D7F80817F7F8083817D81817D8282818B8177917187717C8E757B798289997B8D83777F747282887A7A818484796F777D887E8396827B88';
wwv_flow_api.g_varchar2_table(26) := '8C7F80867F76737D82807B817E7F7C7E86867E878980837C81827E7A79777C81827F727F837F8C8E8A817B7A77797D868587837E80817E7E7A7A7E83897E7780837C7F8789898885867E7D7A7E797982857D77797C818387857E817E7E7E7D8085868480';
wwv_flow_api.g_varchar2_table(27) := '7D7A7E82827F7F82807C7A7F7F8080818385878482807C8082817E7D7B7C7C7C7E8082828081828180807F7F81808080807F7F7F80838485838381807F7F7D7F7F7E7D7F7F7F8181808182817F81828180828181807F7F7E7F81817F7E8080808180807F';
wwv_flow_api.g_varchar2_table(28) := '7E7F817D8080807E7F7F7F7F7F7E7D7E8081828282808180817F85858685838482818586878787817B7A7F7A7D8079777A7F7A786F748B8072717C8888938B8072737C7D8F7B7E806E736C9BAD9A88A1976F6D7E857A867B7977748087838F977F637D83';
wwv_flow_api.g_varchar2_table(29) := '7574758A6E6981908567748B7F7087928E8775807C7C929B93847E7C77797D8489888D8F8A8A8A8B898083857C7B7A7A77787D7C86847D7E787270717675797D767075787C7C828B87847D787774777778797D7E828088898383898D8684837F7D7C7F81';
wwv_flow_api.g_varchar2_table(30) := '807F817E80888A8A8884847F85837E7F797C8280807E8284848689868586868481828584868484898B898A8686858586848282828486848385827E7E80807E7B7A797978787B7A7A77737274757475767675767678797C7F7F7E80807F7C7D7D7E808282';
wwv_flow_api.g_varchar2_table(31) := '828384848482818386868685838181818282848382817F7F80828282807E7F8081818383838383858485858384858585858584828383848583838383838484828281807F7F7F7E7D7E7D7D7C7C7A7B7B7B7B7A7B7C7B7A7B7A7A7A797A7A7B7C7D7E7D7D';
wwv_flow_api.g_varchar2_table(32) := '7E7E7E7F7E7E7E7E7D7D7E7E7D7D7F807F7F807F807F7F807F807F7E7E7D7D7F8081808081818281818080818283828382828384848383848485858585868483838483828180818282828181808080818181807F7F7E7D7E7E7D7C7D7D7D7E7E7E7D7E7E';
wwv_flow_api.g_varchar2_table(33) := '7E7D7E7E7D7D7E7F7F80818180808080808080818181818080808081828283828282828282828281818080818183817F818282817F7E81807F8081828383828281818482858282837F8780837C8480928282937D81827E716F8B6D898375848C77707973';
wwv_flow_api.g_varchar2_table(34) := '89817A8F84827B807F8978767D7F7579857A7B80827C7F808687818285807F848787808280817D84827E80848386808385837C7C86878184887D767F847A7A7E80818283827E82838082827A7B7C797C7D7C7B797C7D7A7F83827F81817D7E7E7A797E81';
wwv_flow_api.g_varchar2_table(35) := '817E7F8280807F7F7D7F828283807F7F81808082838081817F7F7F7F807F7F807F7F817F7F808081807F7E7F80807F7F8080818181807F807F808080807E7E8082828182828181808183818081817F8081818181818080818081807E7E7D7E7E7D7F7E7E';
wwv_flow_api.g_varchar2_table(36) := '7F7F7E7F807E7F7E7E7E7E7F7F81817F7F817F80828280848383818582828282818285838183838382848285847F8282818283827F82817F817D818083807F81818184817F7D81827F7C7C7E827E7E7D8187857D7F82838581867B72777976849680887F';
wwv_flow_api.g_varchar2_table(37) := '899B967E8285788088738897876969808288897B6969727A839190768189796E69706D7F928679737F9C8F7D858E837A7A786D687284897D82878987818389848589817F82817D7D8785898B8884777774777C7C8487857A76727B7C7E888C877F746F74';
wwv_flow_api.g_varchar2_table(38) := '7D858987878988837E7A787B7F7C7B7F807F7A7A7C7E8185888585817D7D7C8083827D7E7C80828683807D828281807E7D7E81817F818283827F7D807F7E7D7B7D7C79777C7F7F7F8385817F7C82807D7C7D8080807E7F7D7D818385868584817F7E8081';
wwv_flow_api.g_varchar2_table(39) := '8382828283848383818284838182807F7D7E7F7F81848582818283807E808383807E7F8080818180818483807F80807F7F828081838181817F838181838180807F7F7F81838181817F7F7F8081828380808081817F7E7F7F80817F808181828080838380';
wwv_flow_api.g_varchar2_table(40) := '80807E7D7E7E7F7F7D7F807F8082808182838283838182828081817F7E7E7D7C7B7D7E7E818180808282818182817F7E7F808080807F7E7F7F7F80808082807E7E7F807F7F807F7D7C7F807D7D808182837F7D808181818181848482828180808180827D';
wwv_flow_api.g_varchar2_table(41) := '7C82817F7F7E7F8080827F7F82807D7E8083807D7D7F807D7C7E7D817F7A8084807D7F81818083817F81807D7C7F85827B7E81807F7C81827B81837E8080807E7D84837D7E7D7C7E7D7F7F7D8383827E7E7D838B847F7D887F6F807B87767E858474798A';
wwv_flow_api.g_varchar2_table(42) := '84837C808687838285837B838081857F818381847A83847F80838282837F7F8384817C848984818787848185837F8187837A847E7A7F7D7F807E7E767582828182807E808289867D7F7B7C827E7F7F80817C7C7F7A7C7E7C7A7F80818385818084828385';
wwv_flow_api.g_varchar2_table(43) := '81808180827D7D80807A7E85837A7F847E80837F818382807D7E808182808085857E7F80838884817E7F857F7B807C7B817E7C83858380807F8083858286867F7C7C7D7F7C7B7F7F8085847D8283807F807F807F8082837E787B7D787A7D7E85837C7A7A';
wwv_flow_api.g_varchar2_table(44) := '8189868584817E7D7E7F82807D7D7D8081807E7E82817E818382827D7A7A7E85847F7B7B7E7D7F838382817E7A7E817E84858382817B7C7E7E8083817C7F7C7F827D7F8484817F7B828789847D8081827F7E7E81807C7F8082837D7F868381878781817E';
wwv_flow_api.g_varchar2_table(45) := '7F837D7B7B7F817A7D80787B7E7780867C888881878884877A7D847C828379807875847C7F8680817F7D8884868B807E8482867F7B847F7F8079848881858581817E84837A807E7F867B7A81747484837C81838586838185848286837B7D7F817E7D827A';
wwv_flow_api.g_varchar2_table(46) := '767B7D7E7B7B8B8A85867C7A868789847A8285817D777D848081837D7C80848A8681808180787680817D8282797A7D7F84878180858383858079817D767E817A7F82807F78808783807B7E868283837C82807F837E8188847D7D7D7D7E807F7A8387807F';
wwv_flow_api.g_varchar2_table(47) := '7D797F79797F7D7F837E7F817E837C7888817A837F7D7E7B7F7E7E828285817A7E7E818981788186827F7F858384807B7F828283828180827C7A7D81817B7E817E82848381828181868284857A7B827B7B8380827C7D868488837C83837F858382827879';
wwv_flow_api.g_varchar2_table(48) := '808388877F7B7D81887F7A84847A7D817A808171747D7B7C888884878884767A7F84857D7D8078788B8880797E867D7F827E807C7A81858481828682877D7C8584818083827B7882797683848385827F827F80868086817E8A807A817B7B8082887C7F83';
wwv_flow_api.g_varchar2_table(49) := '7C8289818081818486837E7B807E8085817E807F85847F7D7C7F7E7B8385808280797D7C7F83837F7A7E84847E7C797F8282807F808387817A7E88827F85837C7C81828481807F7F80797B827C838E7E7A79777D827F80807C7F87887E807F7C80857D7B';
wwv_flow_api.g_varchar2_table(50) := '8388877F7D797E87837E7D7E7D7D81837C7E837E7F828185838389857F7A7D79797F7C7781847F827B7C83877F7A7E7F7E82847E7F7F82807E7D7F84827D7D85827E83887F7C7D7D84867E7A7E81807E81887F7A857F7D828485847D7E7E81847F7F7F7C';
wwv_flow_api.g_varchar2_table(51) := '8281788185817C797E838887817F827D7E87898181817C7E807F8283827C7A7C828A8584827B787D817C788086818C89767B77727F8D958882827973838B79797379868184888C8973767A828A7F73787B7B928F74847B787889958C88837B7C71798888';
wwv_flow_api.g_varchar2_table(52) := '65838685746A888A926C779C6574ADA55C7A966F7C866972AF8F6774899C927D949C773D2C58B5F5B94B0777CCAA666E62B6BF72502E8DF18645505FB7B27093814982B44D4AA5CCD29F821D0006659AEFE886E51248E5226EF7F7A8113E7B07861787E5';
wwv_flow_api.g_varchar2_table(53) := '61E99905BA9716DBE3360AA4C093B864E1560089B84BADF3DD30011AD9A737D1CC4E525ABBF37C837E1D034FA6B34E97F2D0CD67387272608F7E93A14B000463F0F7EB7E6529014DF4C1F0D32A14624F87E29869424D588CAC8BDAC24F90BF4B5C6B777C';
wwv_flow_api.g_varchar2_table(54) := '938B4B3B8284B3D82BD4890157A1B3F691479A6139545E888DBF7931BB7A8A54417399E7979B57877B4B764DBAE8436B9774677A9BAC657CB36C3E77B1BD652D909A78777F8F775EC0A75A4784C574578D8B535E94B69C82B696374A89828A8C876B4F7F';
wwv_flow_api.g_varchar2_table(55) := '9F9982938A705D71866BA19B797E899683717386737C9C9B7B637087816A8893888484817F71819181747A8B8D817B807E718EA4915F61898D8788858D74738E807980937F768174757F7D817973867E7C7D7D808C89877C7986807C7D859485847C746E';
wwv_flow_api.g_varchar2_table(56) := '858C7A71777E8278858B7B76858376858E8C807F837D747D8781737C7F7A7B888C7D7A8684786C7E8C87747B8984808D877780918776717F857F7C8589857978817984877E756E676A98B5A98B6A4C4F5465739FA9BBC9AB74513A46497593A9A39A837F';
wwv_flow_api.g_varchar2_table(57) := '837E64505C9799BDB18C7E96A286696081989D967E98A3858A7352697494A17A91897D7E807D82847D7D86899383616077919D908076788A7F7279797E858E7A646D788484758993817D786D6870777F89969487787A8491907E817B867E6D6359607184';
wwv_flow_api.g_varchar2_table(58) := '908877728889788A9682808D8C7C7F7D7B7C7F81807F777C7E71737B72788F83778A918181867D71798B93827B8B8B82768683717E8F837E817A7B77707474717E837C7B85867F757C88888E8A7B858A8D8B86888980858475797A7D7F8082796C6F8780';
wwv_flow_api.g_varchar2_table(59) := '778489807781877C7A86838180848C79788C888086868086877C7F8385827D7F8080787278847A7C8A81838C8B8382868077818A7D7E80787B7A8385727686888284837E8285877E778984758695897F7E767F80797F7F7F9290827D7977727C8D80727E';
wwv_flow_api.g_varchar2_table(60) := '807881817F7E7B85857B85907F7D8383837C83847B849383777880867A8284717A9583747681857A798884767982807C80897C7480858588897D7F83828480858B8179877E797B7F89817482897D7B8789817C7F827782887D7E828A7681777E70729992';
wwv_flow_api.g_varchar2_table(61) := '7E747B7D8D857E8F758880728895847679807F75747F8584898587867D7776828A7C7984797C827E807B7C81777C8F827574828B7F7C7D7F818E8878787785837C8887797E867C7A7C868676808980778484767B868A79737E838083867C818888867D83';
wwv_flow_api.g_varchar2_table(62) := '89797E85767D7D818B75748A807C8A837F807E897E778D8A80857C767B80837872898E7F7C7981877D7D8081837B7184927974777C888079827E828C837E7D81838083887B7283877E7D7C837B737D817D868E78738283807C7B8082848C7B747C818A80';
wwv_flow_api.g_varchar2_table(63) := '7C857576908D787981857A788883767C898078808C83757A83847E8786808689837A7D86807C867D797B7A8689757E877B808C837E8085887B848B807F828482797C7E787E8A8C80808381827F847F7685887A82917E75737A897E78828182918779787B';
wwv_flow_api.g_varchar2_table(64) := '817B7F8A8479828B817F7E7F7774848279808E7F747F858375758686868978726F768E8C878C74657A70706F869F8E90938D736C6D65707A7E7D777F878385917C6B7D98908895927F7D8A9982677A8F8C7899A0787C94897E7C72757D989483706A8277';
wwv_flow_api.g_varchar2_table(65) := '7F8F92726873809891887D817B8195828A7E687D8C86796D7476677788828085848486827A6E7D846F7C8B868E858C8B7870897E718784727376766D6C7F7F838D7C7E837F7C7E7A8889818E8D81817D8888747D818181817875787C867C747D7B77878B';
wwv_flow_api.g_varchar2_table(66) := '80818585777990917A86927F817B808C7675907C738783847B7A837D778882767C7E7E7D80887F7083999288817D878A858583807D737F907C767779827F7985807D8B7F8086818079768584808C827B828182776F7E8680879581747D8185807B858A84';
wwv_flow_api.g_varchar2_table(67) := '8A7D72777883837D837E74868E7A7A7B81817A8A8B7879898178798283777A84807A8483808182848085887E7B8A817979788788767D827A8A8B7D7E7D84837A86897E81827E7A767C83797E8C858483807F848485837A7E8282898D79787377877F7D81';
wwv_flow_api.g_varchar2_table(68) := '7A7D90897C7878847C7D85757B8D807F7F7C81787385817487897D7E7D82827A81817F8E86787C7C8383777E8373878C7C7E7C8484737F917F778280837F7E837C767D857F82867F808383858180867B818A7A7B7B7E8C777189927F897F797F778E8C84';
wwv_flow_api.g_varchar2_table(69) := '83716F879583876C787A6A8C957B757D7F928B817C787B76757F9489857E77827F7B827C6B817B7289887C75838A7A75827A82949388756F828A81898B88857D858D8282807E8F8E78777E7E797A7E807981907E7C7F7F817B808C87828A8878787C877D';
wwv_flow_api.g_varchar2_table(70) := '79807E8B877E7577817F898378807C7B8C8470787E8786728282758893848780858D7C888B72768373777576776F849080757C7F878580827A848779819D81717B7C82817E817F7B8B85767C82837A7785807E84887A7F7E7D7E717A83827D8C826E7B80';
wwv_flow_api.g_varchar2_table(71) := '80797C8887849289757E7D807E7C857E728E92787A7C807F7988887B808D7E7B7B84827281877F7E847E7C898A80797E848080887A767D808684788486798B907D7B7D85867B82887F8683797C7C817C758288817B838483837E807B7C8A857E8A8A7173';
wwv_flow_api.g_varchar2_table(72) := '767C8B857F7D7B8B978374767C7D7781867A819285797C7C757480868384898C7A73807F7E787C817C818E79758083847C7C827486A18B78767F8B7E7D8A817E8E847A7F82867E7B7D80828A8777818A7F7C7F7D877E7C8B7B767B7991807E797C7B838A';
wwv_flow_api.g_varchar2_table(73) := '8888717F787B907F857A867973888381787C857E7C8480807B797D80828D8677888E79767B7C807E7A7A7D887C7B86807F7C73828A76808E807F7C7D7C757E857F808A8279777F887F7E84817E8F88767379807E7C8683787F897C76798385767C8A817C';
wwv_flow_api.g_varchar2_table(74) := '8783787C8687777682888480817B8284807E7A848D7E7C847F7F7B7A8377758C807587857F7E838E7E768A88838882817A7C877F778889818482888C7E7B8187857D7581947B79787383867C82858288817E807D7F7E808A837A838C8476737E80747C82';
wwv_flow_api.g_varchar2_table(75) := '7E7C8F84717C8187827D898B788384777F7A7E7E7480887E848A7D7E7F817F747F8C7D7982837D7B82857872838A8080857B7D87847D77848D7D7D897E7679808C807A8C837A8C87807E7D8B7D738C8F82817E7E7977817C7781847F7C8787857A7C8781';
wwv_flow_api.g_varchar2_table(76) := '858B7F798B8E726B72878D7B7D827C85937D70757C837B84887E7A85897D78797E7275888279808C7A7082898278848E81818879757B8080777E8C7A79948778787E857B7B8C8376838580777A8A7E727F85838288837D8383807A8596867479937D6F79';
wwv_flow_api.g_varchar2_table(77) := '74936E78998980817F718B7C8D7D758D7C85908A757074817B838A82727D9385817C817F78868B7D7D96816B707889847E86827A8E8A7678828475768D8973828D857C79857A6F80867A7C8E87757983867E7A88877B8A877D7A7C7E7A77858C7D7E8C82';
wwv_flow_api.g_varchar2_table(78) := '7B7A838278858C7C75878D7A778085767487887F848E7E7D86817D7B8A9378728D8372777C877D778F8A76878F827D7D85847686877C80867C737B7E7E7686917B7889867F7E818181818783748C92736F737D877C8489778190827B7D7D7A76838D7F77';
wwv_flow_api.g_varchar2_table(79) := '848B837A7A7E757685857F818C7971858481787F9488768C826F7B7A817F76868678829280777E7E7C7C88887A7A8987777A837E797D87887A81897F87877C7B7F8A89737D8D74707C7D897B778C7E7D92867B7D83887C798B847D82807D77767C7F7E8B';
wwv_flow_api.g_varchar2_table(80) := '877F7F87817881827E7C7F8C8878878E706D797E877E7C857D83967F747F7E7B7982887D7E8E897E7C7F7E757C887E7383917F747D81817F85867C828F7F757B7F817879897E7F9285767984867A7F8C83747985897F8279807077867F89947B768D7284';
wwv_flow_api.g_varchar2_table(81) := '8A7D98796B8D8C7B7B76847B74818680898F7E737C888A7C838278838F857071797F798093807289958379787B807986917E81937F6C737B82817D837C778C8B7A7B8080797B8A7F758B8781807F837A728184757E867E7E807F7F7E858278819083787B';
wwv_flow_api.g_varchar2_table(82) := '817E7878817F79898D857C7F857B7C8B87787785837A7A7D82797A848380888578838581807E8886777F957F6C7A838678788A817C8F897B7E80857E7D8A7E7A86847C77797F747C9586727C8785817D7F807E85877D85917E70717B827D7B857D788C8B';
wwv_flow_api.g_varchar2_table(83) := '7E7B7B7C7B7A878A7D8187827C797A7C767D85817E8B84707E87837B7A8A8D7F878776757A807F7982867787937F7B7E838175838F7A768A857E7A818677768387808186828085827E8286827D85847E79777E8279808B7E858F7F7E7E82847A8491817D';
wwv_flow_api.g_varchar2_table(84) := '85817E73768078808C8477808A81807B80857E8B8F7F7E92856E6D738A877780807C8D8F7F7E787A7F7D8B8A7A7F8883817C7B7A727F877C7E8C89787981867C7A8D887A878774777E827F718187778A8C7F7E7F8984737F887F857E8C786B7A82808E7D';
wwv_flow_api.g_varchar2_table(85) := '7A8170858E868B7B7182898A7E80887379777B87777A8E807F948B7A767588847E867F828784746F79867D7C9581727C8B887C7E8082798693817F90856F6F758084787C7F7C908E7D787E7E787D888578868D847E73797D787F838081877D787B83847E';
wwv_flow_api.g_varchar2_table(86) := '818585818A7E73787B7F7977848579848E827E7D83837883887D7984897F797F81747986887E7E88818185827B7C88897B7B8A8076757C867D7D8C827C8C847D807E887F7B8D837C857F7A7A7C7F7A7F908675798287837980868686847E84917B727277';
wwv_flow_api.g_varchar2_table(87) := '87837983807E8C827F80797C7D818A847C8183817F777A7D768188827E8980727F85847C7C8E8F7C83877476767E8377858C78808F8780797E8377838E817982867D797E807979838C847C837F818A837D7F85867A7E8A7972767B8A827A89827B8F8B7D';
wwv_flow_api.g_varchar2_table(88) := '7C7A8381809084797E7F8279767C787A888A7E7A8480807D81857D858F8678898A6D6D748388787C867E86917D7B7E797B7C85887F7E87897D797978727B87827C858D7772858780788691807F8777757C7B7D787F8F7F798C8782837D816B7A878A8C8F';
wwv_flow_api.g_varchar2_table(89) := '826A6D7992887A7E7D7E798B8D82847A7A7A8190867688846C76868A8170808D7E859280757B888774808C81898A7E747177827B868D7C778288857D7A827F878F877B82897473747F867D81807B869181767F827E78848C7D7B8E867B747B81787B8587';
wwv_flow_api.g_varchar2_table(90) := '7A7F8A7E7B80807E7D8B8D807D877D79797D807D7D848279848D82797C837B7A8B87807C838479777F827982877F7E8389807E8481777E8D8C79798B7F71737F887B7C8A7F798B8C827E7C847F7989868082847B76787C7A7B8F8A787D85827F7C838684';
wwv_flow_api.g_varchar2_table(91) := '8084827B92856A6F7881887D818578898E7D7D7E7A7C7E858B7E798A8677767A7C787E87877C828D74748584817A869380748D806E777B8680778B857386947F79797A8280898B77778884757B807F7F7F88877B83877A8287817B7D8B8B737C8F756D76';
wwv_flow_api.g_varchar2_table(92) := '808D7E7B8E7F7892897F827E877E778C857A83867E7774747D7A8A8D8181857F7884848082828D82768D956E67727F8F7B7B877E809387777774807E7E8E8374888D7E7A767D7C75818B7D818F7B76818485787E9286778580767C7C827F74858577908D';
wwv_flow_api.g_varchar2_table(93) := '7C7E7A80827D8485797E86807F7D7B7E7B8189857C84817985867F7F828A8C74728F806F7679897F77938A7D848D7A747C85967A7B7E7189898181706E8186878D7E7B8781767F807F83828D837284997D6D6C7587837B84807E9587737C7F7C7B7F8B7F';
wwv_flow_api.g_varchar2_table(94) := '6F87927E787C83786A7B8D847E8A7D747F8480788291887682847B797B7E7E7B828879828E817B7C7F7C7C8686797C85877D797B827C7D8A7E7B8488827D8387817886927B6F828F796F7784877B878C757A948B7C7E7F87797A8C807982867D7B797D77';
wwv_flow_api.g_varchar2_table(95) := '81937E778288827F7E84867E84897C7D917F6F787B81847F8383788294817978767B7D8A8C7B7A878A79787E8179778A837A808B7C738588827586957E738B8F717178868274898B73819981787879827D848A7A77868B7E797D83787887888382837E80';
wwv_flow_api.g_varchar2_table(96) := '8589827A80897D76867A747B7E89827788887682908983788087767E897D7C8582827A757E777F8B837F7F817F818284827A878C7C7C8F876F71768A8A727C8982848E81777578837B828B7E7A84908078787E7A7584867D7F8C7E70838A82777F958471';
wwv_flow_api.g_varchar2_table(97) := '828D79777C818074858D797E917D767D80867C7B8980757F8781767C867E788287877D82857E7E828685788D8C777775777783888E7D768678859590767B7F827D7B8D817C7E7E7B7B7D7C80798382828A8984767C857F7F819085717F96847072808A7E';
wwv_flow_api.g_varchar2_table(98) := '757D7B869A8570787F82787B9187728191827577827B6F828F84758584747C89857980918B76778E8078797E8275818E8278878E79797C87837683817B7D87837378848877798783858487807E84847D7B8A8F7771898470707C8A847B8886728495827B';
wwv_flow_api.g_varchar2_table(99) := '7D878274878D797584877B727D8075859080797E82827E7E89807C88887D7A8A7F787875868880838378858C797B7B7C7D7E8888787A878977727E8479798581808089797488897F7A89907C70829176717983807B8A867879928675767C847B838B7B76';
wwv_flow_api.g_varchar2_table(100) := '818B81747C878078828B857D7F897D7A89897E7B8A8971758A7D71717E8E8482907E728B91847D78847E7889857A7C888377767D78748A8D807B82887F808385807E8C887A788A897570738A897880837E85907F7678788179868B7F7D85917B727E8078';
wwv_flow_api.g_varchar2_table(101) := '7288887D7C8A85728288807A7F9485707F8C7D7779838277858C7D7A8F8678747C867E7F8780777D8781797F877D74828A867E818780798787857B93895D7784927E667F9075719B93846C7F90817C83837A797D7C8292806F797D8379828F86787C8C80';
wwv_flow_api.g_varchar2_table(102) := '84897C78838C86776D8B917D7B727C827E8282808D93746D808681747F8B7E7A918F736F7D887871818A7F7B8A7C768788837B8594826B808A7A7B7A7F8179898E7E7885877B767C857C7A82807F828A7D74808683707689868287887B7E8386837A858C';
wwv_flow_api.g_varchar2_table(103) := '74708A856F6E7D8E867A8D8B707E95867A788487767E897A78898974757E7F767D9287797C8681838686827E85887D748686797571848C8382827880927E75797D7D79878C7E7B868C7872808375718589827D898470818C857A81938877748F826E7581';
wwv_flow_api.g_varchar2_table(104) := '857B868B7F7A818F7C74787D7F818B7F73808F876F79877F777B908E7B7C8C857C8187817A818D7F6B7B8974717B8A8C7E828A7979958C7A777F867879867E7A838A8075787B757A918F7E7C80857E8189857D7C888B7974878977717785877E7E817F88';
wwv_flow_api.g_varchar2_table(105) := '917A72777D7B76848C817D8E8D76778183747382887E7E8A7C7686898079858F8272828D77767D85817B8586777C9180757580877C7E847C7982898079828A7971848787867D8E796C83878C95807978618891747E75808883938D777E878078788A826C';
wwv_flow_api.g_varchar2_table(106) := '7C80868A8A847878797A7B818C837982877C8086827E818B8D786A80968073737C887E7D86837E8A8574787C787A7E89867C8894796D79867E6F7B8D85798783757F8885797E918B73748E8579737C847C838C85767E887C767A847D778585817D848777';
wwv_flow_api.g_varchar2_table(107) := '7984837374898A847D86837A8389857B7F8E80707690826874878D827E8D81748A917C797F87807183887A838B7C77787A7C77869280778287828684838280888778768C85787477858A80838678808C7E75787E7D7E848A847C84897476827B7375878C';
wwv_flow_api.g_varchar2_table(108) := '857A868376848A827D878E817277927F707983837D838883778788737880847D7D84817C7F8B80737C8884747C8C897F7D84807E858B817B848A796C8489796E798D8A828687777D968877748382777E83837C868877777B7C738091847A7F8887827F84';
wwv_flow_api.g_varchar2_table(109) := '877F828D83777A8A82746F788F8A7B7E7D7C878D7B7677777E81898B807D8A8A7477807B7473878B7C7D8A807A8485857D829282717D917E717583847A86897B78908471757F877D7D8B7F7881847B7D808D737A7D848A7A8B9975738678888788976B63';
wwv_flow_api.g_varchar2_table(110) := '8B897976798E81768A8F7E7D8A82757D8886737683808288877B777B7D7C7B8F8775838F877C7F7E7E8182948771798A8678747986847B84857E8A83727B827F7E7C848B7E7E8F817379817E757B888778818A75798A8C7E7D8D8D7B6B86907A727A8279';
wwv_flow_api.g_varchar2_table(111) := '7E8A8B8175878274778386797E88817E82877B787F867E6F828E837D82887D7E86897F78878C756A8A8B706E819186798A8E777A9083787B8482767F8B7F78848678777C7E757E92887A7A8785818185848183887D72818D7C7473828D837D8681768581';
wwv_flow_api.g_varchar2_table(112) := '797C7A7E80808B897D7C857E747A7D7976808C877C7B86787D89847F7C888B7C74858D74707986817E88897D77898277797E827E82847C7B838A7B7480857B77868E847B7F8A817D87897C788587746F8984707185928779868B797F9385757582827A7D';
wwv_flow_api.g_varchar2_table(113) := '848079868778797D7B768193877B7C8484808088867C808C847877878677717C8D877A7E837F868C78737A7C7F81858682828B8A78757D79767C8C867D7B83847A838B837C7E8B87767F8D7D717580837F848A7F788B8774768488837E8571787991957B';
wwv_flow_api.g_varchar2_table(114) := '747B72728B8F8E80797E878488867E7B7D887A737E8C796A7A8E907E858E7C7889897E7D797C777786807D838A817978797B828C8A7E7F837F7D878881787E8D86797885847B74788B8A827E76798C8E79777B7D7A78858B7E7A8D8778777F80757C8986';
wwv_flow_api.g_varchar2_table(115) := '7A7A867E7F8686807A89907E728187787478847D7B8A8A83777B87817A83847A7F847F807C827F797C828471788C8686828383807F87847B868A786C7F8A776D7B918A7C86917E748B8C7C797F817878867F7980887E7D7F7D797790947B79817D818886';
wwv_flow_api.g_varchar2_table(116) := '8480818A7E747C8C8075707A8B8E838384788387787A7E7D7C7E848C827C848476797F7A777D8C857E7C8681778688837B829085767A8C7D707883847D848B84777D8B7F787D7F818083827A7C8486777B84807C7A8C8C807C87867E8189857A7E8D7F69';
wwv_flow_api.g_varchar2_table(117) := '798F7A6C798D8F8085917F758C8A7E797F8375768684797D87857B79797A7C8D927C7B818683838483807B86887779818C7E70708693827B7E807E88847779777D807E87877C7F8C7F787C7C7A757F87837C80837C7D86877F7E8D8776758A8473738184';
wwv_flow_api.g_varchar2_table(118) := '7D81878272839482707C787F81857D827B7B8A71778B847A7D88898077887F8088847F7E8086866E6E8B877175878C8180938B757F8D7E7279867F707D887C7D88827B7D7C7E7F848E7F768187808189847C7C848B7A727D8F8676717B8A867E82807B88';
wwv_flow_api.g_varchar2_table(119) := '8B76787A777E8189877A7F9282747C807E747C8B867A7E807C8186847F7F8D8E7A6A88877B7979817C7E8787837D847F7D7E827B7B85817D80808783777D857E74848B7D858082887E848582828384766C7D8E786A7B8B8F828792817384867F837E7E74';
wwv_flow_api.g_varchar2_table(120) := '72867F7C87867F827D78787D938F787A827E7E8B887E7E828A7E727A8F8272757B878C827E827A7D8B7E797B7A7B7D868A827F83897F7B7C7C75758A89817D81827A8387837A80938678778D806E757F817C838C867B8187797F80807E7F827F7B7B8585';
wwv_flow_api.g_varchar2_table(121) := '7A7E8481767C8A88837C848482868B847C80897B687E8878717C918D7D868F7C798D8B7D788183777A80807880887E837E7B797A908E7F7C7D81828287877B7E88867C768489787479878E7F7A7F7E818E8275797B7C7B81888480859081757C7C797783';
wwv_flow_api.g_varchar2_table(122) := '867F7E80837A808C847D7F8B8C7D71858A796E85758E7688837B888F7C7280768982838A6C7D888B7E7B7E8378767F84877D86887D838A868284857E6E758D8272748486828793867689907C747E8174738683798087827A80807E7B868F797A8586847D';
wwv_flow_api.g_varchar2_table(123) := '86897C77848D7C747F908371758087827F83787B938672767E7D7A7D888679859380737A8177737F86847A80827A828B867B7E8B867C778D8771707B827C828B867C788B83797A81807D867E757A858A7B777F857873898682828386838184847D858A7D';
wwv_flow_api.g_varchar2_table(124) := '6D758D7F6F75888A81838D857489917B77818776728380767C89837D7C817B738C947B7680807F8689897C7E8C83737588847A7478868884828279808D7C7A7A7C7B777F878281868A7D747C7F757683838481837E798789807B81918A76788E7D6F7680';
wwv_flow_api.g_varchar2_table(125) := '817B838D867A818B7E7A7D837D7C817F797784877D7B83847873848D89818181828386848083897868838B756F76868D81859480788F867A78817F75788080767E8D868187866B6B7F898A84848E8B848370687E8B887C819D9E805F555D80989E998587';
wwv_flow_api.g_varchar2_table(126) := '956F5A6776868A8D897B74859284727076787D898C807678737E95918885818C7D6D7D857D7F877C826B7D82798D9F8D7A736F7C7B88897C79778B8C7F78847A6F77848784898183898387847F888172768C82756E798983808E8B818B917C7276827F74';
wwv_flow_api.g_varchar2_table(127) := '817F79808A8478797F827D88907C77878479858988807A8D8B757488857E787582828188807285997F747D7E7B79838B7976928E78767F83777780848183857A7D89877E818D8C7D778A867574777F7F7A878A828087857F7A7E837E84837A7A808A7D7A';
wwv_flow_api.g_varchar2_table(128) := '7F847F737E8786878A847F85828182868D8171798A796F75828A84818F88788994827979837E758281787B8A83787B7C7D788A947E7A86837B848B887F808B8370768A7F78757B868585857E758A947E787A7D7A76868A7B7A898D7B767D7D7074898B86';
wwv_flow_api.g_varchar2_table(129) := '808578798A867C78889685727F897171768481798888847B858A7C7A7A7F7E86817D797E8F80717D807A7D7D88858285857E8485817F848A816E7587786F76858D827F8F837B92907F757A887C73827E757985877F757A79758D92858080807B8489867C';
wwv_flow_api.g_varchar2_table(130) := '7987877A7886867B757D7F7A808986787E94877475807E727B87807D8E917E73798075737C8382868979778987787787938570967C6F727B888D707F8B6791918382708087828980767577878079848075747E86898689857F8088857C858A7A6C7B8C7C';
wwv_flow_api.g_varchar2_table(131) := '7172898A7A8590827C8E887F767C8D7876817C8086847B79787F817F8B7F7A888B807B82857F7B858F7A70808C7F76727A858687847B7A8F8E75757B7C7C828C80748290807378817A72828A817A84807C8388837B849084767C897D77747D817B858881';
wwv_flow_api.g_varchar2_table(132) := '7A8089827B7C807D84887C7D7D858578757F85777C87818786817E838488827B8887756E7F88776F7989877F8C8D7779958E797681857578897E78868779777A7F757A9386787F89807D848A877C82897771858B7C727384887E82887C758B8E7A737C80';
wwv_flow_api.g_varchar2_table(133) := '7C7F8B867C7C8D81717B83796F7D8A88828787747B89877D80908876758F8671707D877A7E8D8779808B7D797885898080837C7883867B7880857976858B837F848284878C8177828D77687F887C71778B847C8B8F7A78918F7E728387747786877A7B83';
wwv_flow_api.g_varchar2_table(134) := '817C787F767B8987868386857C7A86887C82897F78798B85726E808D7E7B8887797C8D8476778187807F868479858D76767B7C787786887F7F8A8279828785808990786D779380796F917A71888391857A807D6D81898B8A6D7C7F858E847B777B7F747D';
wwv_flow_api.g_varchar2_table(135) := '8C857D828E8A86837C807C868F76687B8A79717F91877880989575868972767F8A82737B8387857C7F736E7D89828485788387868E8E8584817C877D73767D8D756A798985777C898980898577767A89897D858472898D70807B6A8682728A877184926B';
wwv_flow_api.g_varchar2_table(136) := '8D9A7D8B85847F6D649F936C72747D77818D8B8169868E827A7F87838180838882847C747A837F7488837983858E88787B91877C83857A6C7B957C6C788A8B7D7F8B8774828E7C797D80808186867F7C8981787A7A7C76868A81817E8884818188887F87';
wwv_flow_api.g_varchar2_table(137) := '8177728090806C6F898B817D88877175887F797C8282898982827C847A7D7B75848C76697F8B8580877D877D7E858988847978847D7A797B898271829680707B897A6E81868C7E76828681838C78768180857F797F86898E84747C8C807A808377768585';
wwv_flow_api.g_varchar2_table(138) := '776A808E888089887B7585927C6B7D8976849069847D96866D7C8D469881907999806297656DC29656778A7378919A63858F5088996F8F7C71837D8A6B877C7E97606EAD9169858F5873A16F787085927B9B9A6A7387858A6986AE6755968D706E828A77';
wwv_flow_api.g_varchar2_table(139) := '83938A796F80847A7685847D8672778F8485867F6E77888481848184818A8071859687788282747077918A6C74848B84818F84767785857B757E81757B8482898A867E7475837F8187807F86888177868A847C7D8A817574869275657E98827484897D6F';
wwv_flow_api.g_varchar2_table(140) := '818A7A738187817F89867D7F8B7F6D7081837C8281807E858D807B878B7E7F8B7F7872818E796F798C867D818287766D8388767C8183867B7D8A8781877B757F847C79847E818986857E76858A7B7E857D7676868C786C7E938B7A808981727F8E827478';
wwv_flow_api.g_varchar2_table(141) := '837F7F847F8288887F76717A837C84867A878A867F808287827C86887A737B8F856F6B8993837D838675728A8976738085828588857F81877E70717E827E827F82878289817C8788807F88857B797F8C7C6D788D8D7A7B87897C6E7E8976758586807F7F';
wwv_flow_api.g_varchar2_table(142) := '8488848382747988897B7B828288878682787E8B837982857A76848F7C6B7795927C808B83727B8D84747188847984868082888880706F848583887C808B8787807E85837D7F8A8378777E8F7F6B7C90867981868471718E877174838780858C8A797A87';
wwv_flow_api.g_varchar2_table(143) := '817077878173737A92948780787689837F92836E797D968E6B6C808B7B76888E7C717D857B74828A82797F878680848276727C8785837D7F887F84837C8288827D84857B72758B8870718B8E827B838A7B70858D79737B817C7C838986848681736E7F88';
wwv_flow_api.g_varchar2_table(144) := '81847E7A868988867D8182797B888A7973788A8871768B877977828C80718188757281858385868B817C887E6C7083887C7A7D838587867F7C86897D7F8C807776868D787080887B7980898D72718581737E8383857E81898486897C707C857E7E847E82';
wwv_flow_api.g_varchar2_table(145) := '85868A7F75868B7E797E817C777E8F81697B91877E808C8972708F8D73748481797F8689847F86827072858080887B808B8785867F84837A81887D7878888A776C808C867F7D8683737D8B80717A858788838288838081776F78827F81817A868888857B';
wwv_flow_api.g_varchar2_table(146) := '7F867F7C898B7A797D8D826A6F86897E7E868881737C847C747F8580817E7F898681837D747D7F7C878780818486858180857E7D82807674888579797A828D817C8883818383867D727B817F7E7D818584847F807E7178858A8675758A898CA6AF98AD8D';
wwv_flow_api.g_varchar2_table(147) := '776C4969899079925F4B777C965B6E9B52426877EDF7AA382FAF8A63B4B45AB37F17C3681054A5DF62A13246C9D044566D8475189CAFCCB99138696467B87066989E958586A9923A558DA7A366557866927F6D7C5F7B94A5A88CA67C565457947898DB78';
wwv_flow_api.g_varchar2_table(148) := '283E879BA8B1A8BF6775BA73437B97866495A979555D8D8D3F77A98181938F9774577495898C817687838D908171809B9E795972766D86918F736F84A086798487929488776F787C706F867F5E617F6D582E20B3F49F7E176EBC03BB9F1CEF9B2AF65104';
wwv_flow_api.g_varchar2_table(149) := '35F8CA1142EDE31B2330CCF575096823CFD6174FC4D1C6C2B4523D015AC13AA2FACD094B08ACFBF993000B40B07A6BE895B6F8B67A8E354F521382C697B3C07C336BAE8F49418EDCA5A98B858DA66C37B4A1537E867994775B8F97688EA0876B616689B2';
wwv_flow_api.g_varchar2_table(150) := '885683A2AB865861929878736369A784509C7D667BA5928092977A8166757C9082717D7B8D7E848F948060749A899D7F53827F8783797879938662769A696D9F80868D829C946C7E8C8B90936476A59178666E7F879B9160717B7E767597A88B74A8852D';
wwv_flow_api.g_varchar2_table(151) := '6AB6B4877D7A8894576997607ABE82576F949E927879878E8A8A7A757B737B86819594746F6C8392828688748188857C7A9A8560789A867F7D757E837C8088747E918B8F7C6280827B977E6C7D84848D998C716F93806278919480687F92766E88747492';
wwv_flow_api.g_varchar2_table(152) := '9778627495AA75697A7D9185748FA46B5A757693BD97635A8A7B6A97818DB4755D8480796A7B90819C887A7A5C6D907E81908C7C7C7F727792969489816C617784908B7E877B75766F8196857F8B7F747992796C7A757D8C8C88897D6F7B7F7B808D8F80';
wwv_flow_api.g_varchar2_table(153) := '757066798286959198896B708280807D828C8A7C716C7A80818784847A79827B828A7E7E7F82878587837F7E81817E80787482878788898382847C797E7878807F7E777F8D7E7683827E868A8381817C7A7B817B7F8C847B7F88867E7E887D6F7F897E82';
wwv_flow_api.g_varchar2_table(154) := '87837B7784897D7E80777B8B7B7584837E8176718E8C7E818A7E7F84797F867F858783757A807B8187827D7B85877C808A837D797B83797A8A817C83847F8080877B74868A7D79797F8785887F7787877A7D7B7B858483848489867D7D82827A727C7F7C';
wwv_flow_api.g_varchar2_table(155) := '7F7C80898A8A777484837E797B7E7C7A8785797D838478798B8E82828A797E7B7E837A8481857E80757788857D77837A7C80776D797972849C8C747B7886929C90868676727E807C8584716E6E73878D89887A7E837E867C7F8D7C737B807A6D76898488';
wwv_flow_api.g_varchar2_table(156) := '94877E83807C7C7D7D7C7E808A948E7C76747A8B877B7A7979757A8D88838B8781787A8181837F7679847F7579878C847F82807F8586828077727F7D7B808188847977818D8C837F87887D77797B7C8986767683878282837E7F837D7C7C838D82798481';
wwv_flow_api.g_varchar2_table(157) := '7C817D7D8381857F777C868B8677797A7682827B817F817F757E8B8684848485818181818583807E7A82868386847B7779807F7B84877D777A858988867F7D8687817F807E7D7E807D7D80828682797D85827C7D7D7E7E7F7E7A7E84837E818484817D7B';
wwv_flow_api.g_varchar2_table(158) := '8187827B7D83847F7F8484827B767C84868479777E7980887F7C807E7E7D7E7F7D7F7E808584838680788087828182807F82837A767F827E7D8083817D7F81807C7A807F7C85858285827C7C828684828182827F7D808482837E797E7B7C827F7D7E8082';
wwv_flow_api.g_varchar2_table(159) := '84868784827E818584807D7C7E81807E7E7B7C7F7D807F7D7E7D7D8083827F80817D7C82848282817F7D82847B7882847B7D807F7F81807E7C7F85827E7F7F7E7C7E818082817F7E7E838480807F82857E7F85827D8185837C7C8383827F7B7F86827F80';
wwv_flow_api.g_varchar2_table(160) := '828284837E8184807F7F807F7F84827D828484817D7F828384827F818383807D80827F7F7D7E828283807D818480808383838182807C8183827F7C7E7F7E7E7E8083817E7D7F82818080808082818081817E7E81807F7E7F8082817F7F7E7E8181808180';
wwv_flow_api.g_varchar2_table(161) := '7E7F8081817F7E7F80817F7F7F7F80818382807F8080807F7F7F7F7E7F82817F80807F7E7E7D7E8181807F81838280808080817F7F8181818081807F7E8082828080807F807F7E7F81817F80807F7E8081828282817F80807E7E807F7E80817F7E7F8182';
wwv_flow_api.g_varchar2_table(162) := '7F7E80807F7F7E7F80807F7F808181818080807F7E8181807F7F807F7E7F7F7F7F7F7F808081807F8081807F8081808081818082827F7F80807F7E8081818080808081807F818281818181828081817F808081818080828180807F818281818181828180';
wwv_flow_api.g_varchar2_table(163) := '81818080808180818180818281808282817E7F818283818080808181808181807F7F7F80818180817F7E807F7F807F7F80817F7E7E80818080818181807F7F80817F7F808181808081817F7F807F7E7F7F8081807F808181807F8080818180808181807F';
wwv_flow_api.g_varchar2_table(164) := '7F808080808080818181808081818080807F80807F7F80807F7E7E7F80818080808080807F808080808080807F7F8080808080807F7F7F7F808180808080807F7E7E7E7E7F7F8080807F7E7E80807F7F7F7F7F7F7F7F7F7F808080807F7E7F8080808081';
wwv_flow_api.g_varchar2_table(165) := '808080808081807E7E7E7F7F7F7F7F8080807F7F7F808180808181818081808080818080818181808080818080807F808181808081818080818080818180818181808081818181807F80807F808081808080808081818180808181818080818180807F7F';
wwv_flow_api.g_varchar2_table(166) := '80808080818281808081818180808081807F7F807F7F808081808080807F808081818180818181808080818080808080808080808181808181818181828281818081818081808080808080818080818181818181818181818182818180807F7F7F7F8080';
wwv_flow_api.g_varchar2_table(167) := '818180808080808081818080807F808081818080807F7F7F7F818181807F80807F7F8080807F7F7F7F80808080808081808080808081807F7F80807F7F7E7F807F7F807F7F80808081818081807E818280817F7D7E807F7E7F81807F7F7F7F8181807F80';
wwv_flow_api.g_varchar2_table(168) := '8081807F7F7F808181818080808080807F8181807F7F808080818080808080808080808180808080808080818180807F7F7F808080807F80807F808080808081808080807F808080808080807F7F808080808181807F7F80808080808080807F80808080';
wwv_flow_api.g_varchar2_table(169) := '808080808080808081818180807F8081818080808080818080808080808080818080808080818181808081818181808080808181808180808080818080808080818180808081818181818181818080808181818080818180808080818180808080808080';
wwv_flow_api.g_varchar2_table(170) := '808080808080808081808080808080808080818080807F808080808080808080807F8080808080807F8080808080818180818080808080808080808080808080808080808080808080808080808080808180808080808080808080808080808080808080';
wwv_flow_api.g_varchar2_table(171) := '808081808080808080808080808080808080818080808080808080808080807F7F8080808080808080807F7F7F808080807F8080807F808080807F7F7F7F8080808080804C49535452000000494E464F494352440B000000313939342D30312D31350000';
wwv_flow_api.g_varchar2_table(172) := '494E414D1A00000033356D6D2043616D657261202853696E676C652053686F7429004953465410000000536F756E6420466F72676520322E3000';
null;
 
end;
/

 
begin
 
wwv_flow_api.create_plugin_file (
  p_id => 58823788936427157237 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 58823121604776406111 + wwv_flow_api.g_id_offset
 ,p_file_name => 'camera1.wav'
 ,p_mime_type => 'audio/x-wav'
 ,p_file_content => wwv_flow_api.g_varchar2_table
  );
null;
 
end;
/

 
begin
 
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '435753081740000078DAEC5B0D701BC7755EDC1D70070224414A244899922989FAA12C537F9444591241129440AA2200F147B6DCBAF4113852484980068E9219D7CD5FDB289D96334953D6EE8FDBBA6DECA6336DD3DA6EDA4C2AC74EEC249ECED84D93D8';
wwv_flow_api.g_varchar2_table(2) := 'EE4C1BBBF99FE92471D3B4F54C8CEE7BBBB777071C485AB1DBF14C67880FD8DDB76FDFBE7DFBEEBDBDE52209BF97905542DA7C242E95CBE558631D21C4473F03BEEF537C26E8C352AC2188F53E9299CF2D927230408B24CD9A5A5897F4F4745ACFFC9C3E';
wwv_flow_api.g_varchar2_table(3) := '67947ACE4DC4F505526ED8DC0864D7F6C81708AB9A9E9B2FCCE8F364B158300BE6F2A24116F45C9EEC2313CB25D358202523B354CC99CB449F9F2F5C1D2E60EB74B15030C942216B9064A133A32F1845BD138A9D8B45A364E4CDFD9DB3943E979FEB9CA1';
wwv_flow_api.g_varchar2_table(4) := '12F4F4F410A3582C14C955638652F7648D99A539323BAF972E13E35ED328E6A90467F88FD13CFD9ED53306C9501EE49E257D1EC68FE328244FBF4A64DEC8CF9997C9D4C450E7C55CD62874C629AF12FB4D983C64CE3049213F61EAE65289644056C6A267';
wwv_flow_api.g_varchar2_table(5) := '6CC934B256612ABFE0287696CCC2E2222DE60B666E76D9AED58B405432CC0B5C1CCA77CE20978DDCDC65935CCD65A934B4750C86C9E88BE652D1207A361BA733000D90927EC50082B8908DFD3A9F2B99E40A131B1652374D3D7379AC702567F0DF6C4ED3';
wwv_flow_api.g_varchar2_table(6) := 'F792E96587B2AFEAA5CEAC611A192A560F99599A9D358A249B2B2DCEEBCB6428672EE88BC3BAA9D309802CB0107C0E3DA464160D5878EBDB1237077ABF421722336FE8C551AB942DEA57AD752BE4E39CD8E63B9BCBE74A9781B1209ACCC18C0D53F0182C';
wwv_flow_api.g_varchar2_table(7) := '16A958194B1930FD74EE5E639E9CB43B4D80860C722E9D389387D52A520EF9EC603E7BBEA067C91D63E7E91A527E7973128C34B740D57FE05D8BC61C310B132648420CEC47D71C7B640B79B4CED9DCBCD10956D3595A3432B9D91C883A952F2D2D2E1640';
wwv_flow_api.g_varchar2_table(8) := '21B0E445CA0CEDB7870C4E4C50E18A85C5B3F3FA5C89AC4A44231DCDCDBF2B91974350F07560D58A06FB4D6EA7F041BAD552AB0A5188262569C117650599D1F8BBC963F26A90688A0ABB53F323834012501D8FC2978655C1248CB2850F49796841D1927A';
wwv_flow_api.g_varchar2_table(9) := '50225D64B59E68755A480BAB3270AAC7C606E4D4881871F26B427E2D0E7E4DA225B5EA272A752F652AAF148502613391914133926D429E9B614E4A940A1002568A9C6664748EB2A28CC0188749452745C6AE2DA3D0DAC8BAE148948B9F5078BCBCAA1245';
wwv_flow_api.g_varchar2_table(10) := '4211E68068BB25668868ADB40155C53846C761F6422F5493AD28ADDDBC2A13099A68A935398A8BB555E2E45807D8B6D2005E51EE26522E3F5B20F7119882A4B5C3FC90F99659DAB199B0D5BB090A3D20EB38EABD43DBBAA6DE296137126E5B9F10ECA589';
wwv_flow_api.g_varchar2_table(11) := 'A859FA0367A242954BD89BE94206A9AAD43668E9C496EDD8C27EEF4852FDA94A65B79D6CFD59555772B58EEAA5AB962CBB9CC4BB19F1EE0D11EF61C47B3644BC9711EF5D8B3842D882776BFB1819B3D35B9C7C5A71CA3EBBB51BBBEF779A7C37D068B7A2';
wwv_flow_api.g_varchar2_table(12) := '525395D53DAC5AECA403EBEC24BEA7BB6CBB31730B06D9E6F33037D95979905706C0AAFCA4DFDE80076B2EA5648B71081B0F4FA440C823EB581370EDE5E30693B8DFDA083024B66D1C4515F97D208822A168D4CA9D0E80EA641B613B12C20DDC91F54852';
wwv_flow_api.g_varchar2_table(13) := 'C7DC02F511D80AEA4F887560EC8F39D8D3D972B51DAB505BB35343C7B986B6117B7D8FDBEBCB7C6CDF78D49A8822E1CC1648C59A3AC538882A39811B47BB8DB578AB8CAAF5E4FA9B5427F69443C0F39473913CBC2EF34DC745172ADEB7655B4B28AF6C4F';
wwv_flow_api.g_varchar2_table(14) := 'EFF4788AAB6AAF785098F6D2F50FBC25AEB983AC06E82C14B9C23DC33678AE8C0661ADD89E95B0709059F217C456FE5CF379E0D54AA2CC65BA65C071EE5BD37FBF9DDEAED2F07633C3D3E834E0D14F7E5EF2D823A82FDA936AE1A2E4B17507B153CCDDE9';
wwv_flow_api.g_varchar2_table(15) := '59E25A8D2AB55373915508D251231F458D0CE00A39FAF9ED7EFE3496A19F5F1DF0F17E47C139290A5D41BF5353CCBC07C7138C219DAAA20D25ACF5FFF332553CAD89AF61A3942C5D86E7990FE6B6DB3DB7761F730EF4E7BFC013501BE6ED4DF63E3B3370';
wwv_flow_api.g_varchar2_table(16) := 'CA9A489C0E1C88826905B4B35A0229251CE82C8D2DB07A441BC5150968E7987D4BDDAEFD7ED0663C8C153F354E97D032FF04284EC579AADAF99526CB324B4B998C512A911D042C6D6CCD09830355546A8C400282A20EF6A1F34FAE1F46519312CF8AD406';
wwv_flow_api.g_varchar2_table(17) := 'A22E3A2D994E4B4A7918E551B1C5877D1BF261B649F67AF8CA5E2F5F69DB9864DB989476786F0FDB949DFD1CAE4449333BA3FD944ADB94A93F516AD926773FCC3665DB36E5F56DD376A2BDF8DCB11E5FF603D2E1391BD9FC25C5C796257D1A664255DD2A';
wwv_flow_api.g_varchar2_table(18) := 'A5D80F588920FC6852A7301EC0DAE35673AF84860A51762CC513681F4FA0B7B0DCDA9540DB7949B961E400D05EFB3569D499AF58A9344D88CC119A912DE8F9C919568CEBA63157282E27971666282554D14492E632FACC3C4D67EDE47B4CA789E4EC7C81';
wwv_flow_api.g_varchar2_table(19) := 'E6CA97B091DC999BBB539F2353175971366BCECC4F5FE2DF53176956B4B0483358C7802CDBA24920CF8B2003A30933B9341C9F1E99A4F95F763A9B999E5F5AC8E5F57CC698A6ED4B5488AAFA7C11E655A243BB3A662E170BDE5D9D2D56E74B83A2AF5E63';
wwv_flow_api.g_varchar2_table(20) := '50DD7B5057C71A83EADE8366B8BAC94CCEC49CF06A31671A54232532B34C7348E32A7E2F164ABC8516C85972860C9338192283E404E923C7C9316AF0BDE408CD6F0E9183D8A3B064B21EB7178A59323B1C9FC46524C5C2523ECB5A06D3E983ECD744EA2C';
wwv_flow_api.g_varchar2_table(21) := 'FF357C6192FF1899B4DA2660D5C1970D4F11FA379E183A7C892EA7951A1F394CD76B8A4CD1CF45FAE1B9ADFBC0A176AEFAE87E67AE8ADE53A1DED33A4BF97B6287822CCE3BEC8EF308468176B3CFDD9C75078959D1EA8A5690F4B0E5735A31A0B8B60902';
wwv_flow_api.g_varchar2_table(22) := '8AFA36CB3944C96A98A89FC73003F77838C4DAE8D665D1874F93C69D259996C09FA04CB4AC8C471D19B8DFCEC069138B68EAE0B9314B3EE25F3DE353331081CC016040B2083003300DF03300230006C0BD00CBA2C7ED004980018043A2C73D0097012E88';
wwv_flow_api.g_varchar2_table(23) := 'D6E3003B0120AA51C70497058061803E805D00AD00CD00FD006931DA1180AD82A409A041F43D03700260AF182802502FE8508C5300B7018067533789D6B080D362B40A56E089D59028C2DC8658DCB27E3034602DFE039855FBD9B98022852D934B58E653';
wwv_flow_api.g_varchar2_table(24) := '2F1E68810E7632E278FEF82C36CD4E6354ECB44551CB6E8B2C5B24CC10B424FB0EDA87138A0221F0F9B2B089772C0C011C5893A44F2C7DDB9A5C90A445D8A217DD01C1A55918A46513811BB089C0FF954DD4AD6113632430F5E80BB1BBFEB4F8CF81775F';
wwv_flow_api.g_varchar2_table(25) := '7825F6A9CE67EF0BE4BABE133B79FD912769A0F0FD184C3230F3FC6BB18F37CD7F2FF067DFFA61EC8B85B10F07D2877E14FB9E3EF20941A36A5C376A8573B40B9AAD282D8D65105FC39E38C3979C7947D0A60EA6B10CD4419BFA6384CD2B94A43192220B';
wwv_flow_api.g_varchar2_table(26) := '493CB6011655454B86D98F20FD1124B447272C1209D7A7187DB89A55DD9B67651B029D413F6422A1321FA07EA583867224481DB5F50897E1F16E62C8F33A71C5A8AE644A240C0D03C200B92DA8B6A6D4345B01AA2915DD187BB6FDB6D3743C968186871A';
wwv_flow_api.g_varchar2_table(27) := '8D75D52423BF1D73E900646649316EE340CAAE052D68116A4615554D8A9A72667C76804DC7FCD53233577CFA599523989B07FAB9822491425D23AB1AD434D3CF26BE089B93F07C94D8CAD4D3741B295AE8A79553443D29DAE8A79D536CF1A4B8897E3A38';
wwv_flow_api.g_varchar2_table(28) := 'C5D60A0A2E1A3FE60E7493677DEE50C1CFA885BDFBD6CE801BC5BAFC024B46BD331205936334F5256EEADB7039CAEFA1922909E4CB65BBD9D5E05CB2EA66BE50FE9A6D11E61E8A658858701BB0182414F21634088BCA0E50426C5EEFFBDF933708F272F9';
wwv_flow_api.g_varchar2_table(29) := '50A804C83E5DB6CFB432229E934519B7A6F10667D9C9C2279AB44A332512F6B1C39F48526479129C0EF0850D397C33415F0433FE2A0135F0584DC9DCCD8FA4D0B6B6C3076D8A47723B92191DB78972813143B21DD87281CBB423696D7FB48022D7E8F6A4';
wwv_flow_api.g_varchar2_table(30) := 'E5E1F134E316B2DAC08A166F382B6AE0E74F76D58318965A1C822EEA200EA7AA983A6261BB38408E5A8E6BE74AA3155B6356420A647517D1BAB45DDA6E6D8FB6174EB4B55BB4FDDAAD5A8F76403BA81DD20E6B47D0050D3135E21C7BE1934455D1D58183';
wwv_flow_api.g_varchar2_table(31) := 'AE2CCC0776C4DDC944CA8BC86AE3821C6582C8429093FCF852B3988136EEAE98237B0753DDC0991E5B6901B7DC4E9966E165A28C4927B92BE070C16D4E7F1CB57741348D6518226A3F9C9E91407E4969C31E68A75852B194101BA7160558594850F85C14';
wwv_flow_api.g_varchar2_table(32) := '01C1C3BF2605F0A81314928BC22F7804D6A408B1272FAF935D148AE0A1AE4911620F19F4672A9087AD02B4344659C41C80967AAB002D0D6E0D414B58A94FA45CDC796D0857B241694CC0D3F8A1DFFF66ACFF0163169E3211F7FC80AC5189D85C028E5AC6';
wwv_flow_api.g_varchar2_table(33) := '455382B69441A5CE16AC4E09259860386A031C97075EBDFFC5D88903773D02836D86944D44524A380C16B219FA34618B153F290D76CB264CF3EA5D4237E30821A519085AAC0228A535EA5A206869559AECE9C88EDA50CA651E50DBA26CB26955476D088E';
wwv_flow_api.g_varchar2_table(34) := '24691D587002CD1D02CC1FDFF006F84C8D0DD0B7EE06E8F3D8009A8BE2A0C706F0A2706F80888B62AFC706F0A2706F80361745A7C706F0A278BB3640E79BDC0011CF0D70F09DBA01F67A6E8036CF0DA0796E803EF706A002B5A52DDBDFF9E30D98BBC8F1';
wwv_flow_api.g_varchar2_table(35) := 'F6E3B35E52A2F049B21753519A1AB813BBE3F886FF93CED7513EAD4F84BC753E78747FAD6C3FBA8FB2A7798454559DAB7EE69FADAE1ADD1015A9AEF26DA86A9D8E476B5691757971E59C5889C29319E20E761428F383C128EAEAC96A5D35558FA6558CE6';
wwv_flow_api.g_varchar2_table(36) := '3C553BCACA5245177943F36FDA904AA40D75F4602FDF4847AEB8DBF8C59D6EF25D8C11FFA95A53BFB8FEBAACFFAA45EC80ED441C41014D4594493B3F5DF69AE60D8C50577B043EF99362F2011906FD6CF5E41FF6BD05938F58A2ED212241B5AF0F540BF8';
wwv_flow_api.g_varchar2_table(37) := 'E9F2069886447A684D7853AD093F55AEF40E3728F796B740EE3FA892BB7D6DB97D3FB9DCD1B745DFAD6BCBDDF493CBBDF56DD177476DB9F9C638259E355F47AFF072F5C608577B05F9461F061BF37CF28D3AD6D8469F22A757BA08F193087D8AC487A7AC';
wwv_flow_api.g_varchar2_table(38) := 'F44E198E13FFC824C5C0C8E4609CEC9641B101E49114E768017C9B9C64211C7B296C9D0D1D1B6701E6FA8796C28775F1A5EA771D2B06932CB862F71F9F2C0B1ACE999DD9F290B8B24D9C4784B03CCADFA1E35113EB6C9B43279A4302CFF7FCEE039A5022';
wwv_flow_api.g_varchar2_table(39) := '59415975DE124A5452F8D92260B028661EBEC082472A4198BD603BCFAE6BD9B2039598014A8CB7259F2CDB9D46F9BBB4101C653A86044DF43B4ED9823C4A0DB3BD70028FD48218B156AD8563F8A03D3C4A5747DC7C509EA7CAACAE9E47E354B806BE9981';
wwv_flow_api.g_varchar2_table(40) := 'E60EE7B16AA33D5C639A85F54188A959877AC6B505E7A3B997E3B932638C271D6D22EE0FF0AE61719616E4EB60CF81661FB516CD8BB882D4D60C44A56F30DDC750F7206CA486F2F9A68AADB4D3472C09C335AA853922DF0B6F999565C0DFF1B9CFAEED42';
wwv_flow_api.g_varchar2_table(41) := 'C0D65220CD922FDC63226FD49D5D6B9D6C0BEA1E1F4BA402091672AB0971742B6903E38E970C11D7F1D039B137B58A83A3736C4B638BA8B076DD60123C803FF0FC8E2FC53E3478F737946018929AC73EFF6A6C2672C709A52E9C80F296039F8E7DE1CADF';
wwv_flow_api.g_varchar2_table(42) := 'FD9E120AE33B9EF7C2B121D7DA106771E6C1CF5D0F5F79FA09CEE2AE235FBEFEFAF0435D160B42BEC6DE405016BC679CF7144DACE70BCFBD7CBD6BE69CE8F9A9E71FBBBE78F52B79D6D33E7BA69A7CE20D0A1FB04E3D87D9495A10D70FEEF8DF2F815BF0';
wwv_flow_api.g_varchar2_table(43) := '69BDDA19F741A0FB88907AD9172B1E1BF64BEB3E57E9B6717E7C7A36C9BE13CEA3F5132EDA93AED2A9F19AAF912A5F8CD496B4C2EC22C4B6B5847DAF0BC5436BFA3752697BAC8B2ABAA8D845C5996097C709BC310AE0ED2B99891EB336611BF7F1CD49E8';
wwv_flow_api.g_varchar2_table(44) := '24B35755961DD1A9FA19FDE97171CEECD36EE2142DD84761EFA42CC3A9E8A378F6F13BFAC4ABFAA01DEC837752AFBD517DD00C33FA69E2388F671B8866B69AD624683168C13B679A16B1CFB44553461C95A72ABD1D18CF4B15C68352F426FBABAF3A8D9C';
wwv_flow_api.g_varchar2_table(45) := '8EAE8EFAE029C91EF5FDE2EDFE09712D014E2FD42E710501DFEE9F14AF820F8B37B978FB608778ED7B4A5C19C0AB003D00BB01B68B2B089B018E01F402DC0AB007008E5DD4A8B85F80F7068E02EC17B70A6E76BF3CC65B05F07F4CEA2D00DD00DB00DAC5';
wwv_flow_api.g_varchar2_table(46) := 'ABE5B0F50E958543FBC475882DEEBB0EB03278F2C982AB0E809B001AC55D0738D1C44567511A116FAE53AB11CCD0D8BD0D1F7B9BC82BEBBC2A435E95E18ACA9FC5C4870DB336F8D6840A8989A51A2AF619CC82981AEB842E35A10F7BC68AD0A0E4661766';
wwv_flow_api.g_varchar2_table(47) := '9C50D82DEAFD1E632902FC0264B7B665013E515725EC11D8E9EDEAEB50F5DF00FF05F09F003F02F80F801F02FC3BC06B003F00F82EC07700BE0DF02D806F027C03E0EB00FF0AF02AC02B002F03BC04F022C05701BE02F065807F04F812C03F007C11E00B';
wwv_flow_api.g_varchar2_table(48) := '00700B497D16E01980CF017C16E06980A700FE16E06F003E09F0D7004F003C0EF018C05F01FC25C0C701FE04E0518047003E06F0C7007F04F087000F03FC16C083000F00FC26C02AC06F007C14E0D7013E02F02B001F02B806F041805F06F825003CC0F8';
wwv_flow_api.g_varchar2_table(49) := '00C0BBC5FD25BCC97415E00AC012800950027817404E5C62C26B4AB3E21654565CFEB813E012C01DE286D24500B860A94E024C00E029DCA8B84B9500382B2E2CE1DDA7B8DB69F509C7734CF88D5EB1E3BB8507D9233CD22EE105DA8557890A2F656F87F7';
wwv_flow_api.g_varchar2_table(50) := '0314C535AF23C23142FEA2BE00302EFCDF67003E21EEC3EC14FB09B24AF5C300EF130E74B3B8FAB5436C395D5C02DB2476E0A0F0CADB85EBF30B0FA7888D52B13F1F766CCDE88D7A8F0A906BFB91D6B7CC8F6C6586564151E14754373BC5ED51D6F3231D';
wwv_flow_api.g_varchar2_table(51) := '6FCE8FBC2917F2FFDE837B8FF7BFF35D484DEFE1E5387E20DCCA2BC2FD74B93DCA0B6E67D222FCC8B8F02D3BC506B29D89ED3D8684E3D0DCCE6487F019F7083FA20A6732281C47C0ED4CEC5DD9546B6B3EEC88716E56CBE5AAC8655B4565EDCC01C9FBBD';
wwv_flow_api.g_varchar2_table(52) := 'A29F41AFCA21AFCAB8BB92DFBC97F8CDFB76BC792F396FDEDB17D9CB0D0F21E9B5A33413B4ABABFF85BDE262345C7E874BF08E0BD217C986FF99B732FC964FF3E44A71AA881D2AA5484C06B3BCB69572189B1C9C884F8F0D8E2689793957E2FF708FFF40';
wwv_flow_api.g_varchar2_table(53) := '8FC3C258512E86F5424C4289E4F128012DFD0F000000FFFF0300B09D35EB';
null;
 
end;
/

 
begin
 
wwv_flow_api.create_plugin_file (
  p_id => 58823967725015405627 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 58823121604776406111 + wwv_flow_api.g_id_offset
 ,p_file_name => 'jscam.swf'
 ,p_mime_type => 'application/x-shockwave-flash'
 ,p_file_content => wwv_flow_api.g_varchar2_table
  );
null;
 
end;
/

 
begin
 
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '47494638396120002000F30000FFFFFF000000C6C6C6848484B6B6B69A9A9A363636565656D8D8D8E4E4E4BCBCBC1E1E1E04040400000000000000000021FF0B4E45545343415045322E30030100000021FE1A43726561746564207769746820616A6178';
wwv_flow_api.g_varchar2_table(2) := '6C6F61642E696E666F0021F904090A0000002C00000000200020000004E710C8496961A5EACDE7624B85249D460C15A35202419454B22C07A53253E22A30352F2FC96DA270217A93C1CC301902103B24C53043019C2E02492A21FC4843284140116F0104';
wwv_flow_api.g_varchar2_table(3) := '832133395435BA5CD13829A80D87A060C1EEB4B26414077778473D59040A67140483774862861D7606413D923009565C9C5C883B09020503A4A59C9F3BA5AA9B48A88AA2ABAC9DB31D9830B6B57425914873898B72593C487F2E8113C589B79609BE9262';
wwv_flow_api.g_varchar2_table(4) := 'BF135A1A62C74F45673A04987F47595D2EC03DDA41DF4F519C7386E600EA5C62C3682E39EC3D7367F57F9E638CF365E21D12D82A128FD68666003744000021F904090A0000002C00000000200020000004EA10C8496959A4EACDA7594635149D4690D4A2';
wwv_flow_api.g_varchar2_table(5) := '5206C39454621847BA4A85BBC0ECAC4CAA9D64E11AF02685596D781BE88E94C30C1504205C0C14144098191280EAC1159A200804B0043118FC265283B1921348120A34013151B4DB7C56061925027A047614047F236A30870A8E146C8C47677B307E0389';
wwv_flow_api.g_varchar2_table(6) := '3C813C09845BA25B87689178A5A147A9040A79A9A2A9A7AF87A3B6965B9E3097BA1BBC47B4911BA8A650867A9C12C768C9BEA1C4986B7AC212691A97C908798EA0D1CA687C7AD5689247DD84E256C5A2AF81E900EDB9EB5C6813E75BAF8EEF00C7A4888A';
wwv_flow_api.g_varchar2_table(7) := 'F526952B91A0579E37B738E019C821020021F904090A0000002C00000000200020000004EE10C8492931A4EACDE7314735645D852895A152C7B29454328C946A4C847BC3D33C20135BD035E04D14BEE00A30D0192985190A204CB816A4490286F06D85CD';
wwv_flow_api.g_varchar2_table(8) := '45A8C76014B404057012A5550A0B81045E66142508825EB105C8E41D0206750C3B13027A7A027D3084581B090A8953300365771D79046B3C079C25099F4FA3A389930991A67AA4AA7B92ADACAA7CA9AAA4B6A3A225B91C9ABB14BD46AF698C31C2943088';
wwv_flow_api.g_varchar2_table(9) := '898087A6CBBC59B49B139AC338C4788ABF928C097A9FC940891289D73CDDAB00E2009AC7C1DEE3E800AFBE1BEC38F1E7593CAF8CEA12C9A50838F387A75C87501524B5BBA52192C10D11000021F904090A0000002C00000000200020000004E710C849A9';
wwv_flow_api.g_varchar2_table(10) := '18A2EACD67194555109D9620D5A052876194544210D9A40E13E1BE703E27B695A46508F5248899228803145C8723453143016E80C48E1483C97ED7D5004A192C16DC2C41619508AA1A9D55775E3401492550DDDE080E750B51163333027B308106693154';
wwv_flow_api.g_varchar2_table(11) := '85470567771C797D2503882527529C9D130CA0A10B05098E858C3DA1AA0CA6A79DAB0CA3A5A7339EB6479625B99470BABD30A60A9913B34A526F853513C8863049C4A66D796B8804C378CD130854885F7DC8288F0085D75EE2E2794B9D8E73B512EC9CE9';
wwv_flow_api.g_varchar2_table(12) := '3E695FA8258ED5EE6EFA3DD912E2DACA71D83465CD2D4DC2A444000021F904090A0000002C00000000200020000004EE10C849292AA8EACD272945A5645D95901318A6C35052094108943A21ADFB7A729282939C6277930D2536802247A42864245B2287';
wwv_flow_api.g_varchar2_table(13) := '92F84AB11EC04668AD90060361121B5104508D6070251CC2862F4246505C63550DE20D3F54D07402572F70060747264F744405615F1C7304791D6C44274D9899130B9C9D71098A7463989DA50BA1A299A60B62A0A2329AB1440393904D030C0C3A1D91B5';
wwv_flow_api.g_varchar2_table(14) := '1AB9B90B8F64A188250206C00C067FA2342573290BC0BB9175830483453314B80CA300595580198B0074DA96E6E691C6448A24E64A694DED3CE059E03B8AD8B0138098643C93204F02827458F23C71272B11420E11000021F904090A0000002C00000000';
wwv_flow_api.g_varchar2_table(15) := '200020000004F310C8496952A9EACDA7224A25209D969014A1A645515AAA90AE12D212EF4C64928AF72D59AEA60AF56882966BE851A17C80841235E17512BE0C3459F84914830115ABA002044E0D62570B878D80759187359B0AEEC17282F609AC257962';
wwv_flow_api.g_varchar2_table(16) := '1B173E5E25026F2F72761D6C39274C929313069697073B1F868739979F069B9C93A0069985A394AA390380258D1C050B0B038B6939B3B3069D12A820430807B90B072286421D030C420406B9B54473138F14070C0C061403CE5E5804667D245009D70C7B';
wwv_flow_api.g_varchar2_table(17) := '4CDE3F5000CA0C0B949B4F34000BD7D0C045D3F304E5929B56EB2418B8E6CA11016400024AD0232912850F705611C2C024020021F904090A0000002C00000000200020000004EB10C8496952A9EACDA7224A85645D952015A152C25A4E892A502A01ABE1';
wwv_flow_api.g_varchar2_table(18) := '3BD524507B2A944E82C0ED5C45D090F221087F31554F32DD4409995F723649F6620AA1A4E5D4C448979A380942973B09B2AC222708AA9C5ADBDA74BD92621C804B2343274B888913038C8D05777D3F888D940391924B95038F697A368AA03A0378824B04';
wwv_flow_api.g_varchar2_table(19) := '0606057F4143A8A8079F267D397F07AE0607747A5C1D050B5C04B6A8AA4435183B78030B0BB91305A8B1518164280CD60009CB0BB14B5712D60C12CA0B068A4D42E01306CB038849B4E91204DA884D3DF11207CBA41B7313F8E2B8BD384461018305A14A';
wwv_flow_api.g_varchar2_table(20) := '1460404C47040021F904090A0000002C00000000200020000004EF10C8496952A9EACDA7224A85645D952015A152C25A4E892A502A01ABE13BD524507B2A944E82C0ED5C45D090F221087F31554F32DD4409995F723649F6620AA1A4E5D4C448979A3809';
wwv_flow_api.g_varchar2_table(21) := '42973B09B2AC222708AA9C5ADBDA74BD92621C804B2343274B8889477A18697A36888F387D7A89928D947E8A9B2558844B020303391D833AA2A881307DA4250905A80305747A5C1D04064208B1A46C18630C031A030606074CA2625181060C0CC70BD100';
wwv_flow_api.g_varchar2_table(22) := '09C506908805CE0C19D10B1205C5C7890BCEC200DD1307C5B34B03CEDE12E812B8C588E40CECE7D2E9C5781CCE0628C89B50E09A0E58150C2C08C8E9D6827C2F22000021F904090A0000002C00000000200020000004F010C8496952A9EACDA7224A8564';
wwv_flow_api.g_varchar2_table(23) := '5D952015A152C25A4E892A502A01ABE13BD524507B2A944E82C0ED5C45D090F221087F31554F32DD4409995F723649F6620AA1A4E5D4C448979A380942973B09B2AC222708AA9C5ADBDA74BD92621C804B2343274B8889477A18697A36888F387D7A8992';
wwv_flow_api.g_varchar2_table(24) := '8D947E8A9B25853A080784412F030C0C03437D181B040BA6A686755C1306AF0C06B31B0203687D62A5A60B0544C21A040303C35D1F3D05A6A813070B0BA806D60009C803815629D30B19D606120ADA8A06D3D0E21305C8394303D3E312EB44E64BE80B90';
wwv_flow_api.g_varchar2_table(25) := '00F512EDBC4BA685A2758D09B712C72A1C303090531E03CA7444000021F904090A0000002C00000000200020000004EB10C8496952A9EACDA7224A85645D952015A152C25A4E892A502A01ABE13BD524507B2A944E82C0ED5C45D090F221087F31554F32';
wwv_flow_api.g_varchar2_table(26) := 'DD4409995F723649F6620AA1A4E5D4C448979A380942973B09B2AC222708AA9C5ADBDA74BD92621C804B2343274B8889477A18050B0C9091897A350A91970C93948D8F988A9F43853A090384412F030B0B05437D181B0406AAAA86755C1307B30B07B71B';
wwv_flow_api.g_varchar2_table(27) := '45687D62A9AA06360008C51A5B14081F3D04AAA5B80606A503D70057782629D40619D7D249398807D4AC00E1406F4305D40713EA543F4BDEC6E9D81364DB1BEF14F25DF8C14237A1C00082A0360818D0AB44040021F904090A0000002C00000000200020';
wwv_flow_api.g_varchar2_table(28) := '000004E810C8496952A9EACDA7224A85645D952015A152C25A4E892A502A01ABE13BD524507B2A944E82C0ED5C45D090F221087F31554F32DD4409995F723649F6080CC68015D4C448979A103008331605AAB39468D5B813839B61C0976A205512050B7B';
wwv_flow_api.g_varchar2_table(29) := '43496B1C6D624B2387634B919212803809847B61929538996E9B9518989993A5878256903A882F050606713A4D811B0A07AFAF4375807E00B7B807891A4568B36BAEAF0736000903BD005B14081F5FAFB183030336503C2F5508D90359484692E1393F12';
wwv_flow_api.g_varchar2_table(30) := '4DC2250AE147CBCCE943E16BF30076A81BD9F13E2E5DFA3614A9F02187290E17025688000021F904090A0000002C00000000200020000004F010C8496952A9EACDA7224A85645D550C15A152C25A4E09C318944AC06AF84E32734B368F0AB19B0C648B49';
wwv_flow_api.g_varchar2_table(31) := '1080C815290B190A104CD848B057A1470C360902CA174B5818A61283ECA0B1922E36A264B0A81B7E02067A9368D9C21407757507722F362058350683493B5F861C740B054F2345097B4F9B9B8839560706A2A39C9E39A3A8349D9E1804A1A99CB19B973B';
wwv_flow_api.g_varchar2_table(32) := '5696432F0A030380B936181B08BBC3987E2ABD1227C3058A1A4D6F1FB812BABB05806ECEC7621F58C2033A127E5D2B562ACD6D15E504194B5FE04FD1724B00F1B34E402E00EA9BD164F9007ECE71D0A6E41F13811C1244A20742D68B0B08354400003B00';
wwv_flow_api.g_varchar2_table(33) := '0000000000000000';
null;
 
end;
/

 
begin
 
wwv_flow_api.create_plugin_file (
  p_id => 58824555030797839268 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 58823121604776406111 + wwv_flow_api.g_id_offset
 ,p_file_name => 'ajax-loader.gif'
 ,p_mime_type => 'image/gif'
 ,p_file_content => wwv_flow_api.g_varchar2_table
  );
null;
 
end;
/

 
begin
 
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '2E6E6574686561645F77656263616D207B0A096261636B67726F756E643A20236666663B0A09626F726465723A2031707820736F6C696420233046304630463B0A09626F726465722D7261646975733A203570783B0A0970616464696E673A203570783B';
wwv_flow_api.g_varchar2_table(2) := '0A09706F736974696F6E3A2072656C61746976653B0A7D0A0A2E6E6574686561645F77656263616D202E666C6173682C202E6E6574686561645F77656263616D2063616E766173207B0A09646973706C61793A206E6F6E653B0A09706F736974696F6E3A';
wwv_flow_api.g_varchar2_table(3) := '206162736F6C7574653B0A09746F703A203570783B0A096C6566743A203570783B0A096261636B67726F756E643A20236666663B0A7D0A0A2E6E6574686561645F77656263616D206F626A656374207B0A09666C6F61743A206C6566743B0A7D0A0A2E6E';
wwv_flow_api.g_varchar2_table(4) := '6574686561645F77656263616D202E6E6574686561642D77656263616D2D62746E207B0A096D617267696E2D6C6566743A203570783B0A7D0A0A2E6E6574686561645F77656263616D202E6C6F6164696E67207B0A096261636B67726F756E643A202366';
wwv_flow_api.g_varchar2_table(5) := '66663B0A09646973706C61793A206E6F6E653B0A09746578742D616C69676E3A2063656E7465723B0A096F7061636974793A20302E383B0A09706F736974696F6E3A206162736F6C7574653B0A09746F703A20303B0A096C6566743A20303B0A09706164';
wwv_flow_api.g_varchar2_table(6) := '64696E673A203570783B0A7D0A';
null;
 
end;
/

 
begin
 
wwv_flow_api.create_plugin_file (
  p_id => 58824580118061860351 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 58823121604776406111 + wwv_flow_api.g_id_offset
 ,p_file_name => 'webcam_plugin.css'
 ,p_mime_type => 'text/css'
 ,p_file_content => wwv_flow_api.g_varchar2_table
  );
null;
 
end;
/

 
begin
 
wwv_flow_api.g_varchar2_table := wwv_flow_api.empty_varchar2_table;
wwv_flow_api.g_varchar2_table(1) := '2F2A2A0A2A206A51756572792077656263616D0A2A20436F707972696768742028632920323031302C20526F6265727420456973656C652028726F6265727440786172672E6F7267290A2A204475616C206C6963656E73656420756E6465722074686520';
wwv_flow_api.g_varchar2_table(2) := '4D4954206F722047504C2056657273696F6E2032206C6963656E7365732E0A2A20446174653A2030392F31322F323031300A2A0A2A2040617574686F7220526F6265727420456973656C650A2A204076657273696F6E20312E300A2A0A2A204073656520';
wwv_flow_api.g_varchar2_table(3) := '687474703A2F2F7777772E786172672E6F72672F70726F6A6563742F6A71756572792D77656263616D2D706C7567696E2F0A2A2A2F0A0A2866756E6374696F6E20282429207B0A0A202020207661722077656263616D203D207B0A0A0965787465726E3A';
wwv_flow_api.g_varchar2_table(4) := '206E756C6C2C202F2F2065787465726E616C2073656C65637420746F6B656E20746F20737570706F7274206A5175657279206469616C6F67730A09617070656E643A20747275652C202F2F20617070656E64206F626A65637420696E7374656164206F66';
wwv_flow_api.g_varchar2_table(5) := '206F76657277726974696E670A0A0977696474683A203830302C0A096865696768743A203630302C0A0A096D6F64653A202263616C6C6261636B222C202F2F2063616C6C6261636B207C2073617665207C2073747265616D0A0A0973776666696C653A20';
wwv_flow_api.g_varchar2_table(6) := '226A7363616D2E737766222C0A097175616C6974793A2038352C0A0A0964656275673A092020202066756E6374696F6E202829207B7D2C0A096F6E436170747572653A202066756E6374696F6E202829207B7D2C0A096F6E5469636B3A09202020206675';
wwv_flow_api.g_varchar2_table(7) := '6E6374696F6E202829207B7D2C0A096F6E536176653A092020202066756E6374696F6E202829207B7D2C0A096F6E4C6F61643A092020202066756E6374696F6E202829207B7D0A202020207D3B0A0A2020202077696E646F772E77656263616D203D2077';
wwv_flow_api.g_varchar2_table(8) := '656263616D3B0A0A20202020242E666E2E77656263616D203D2066756E6374696F6E286F7074696F6E7329207B0A0A0969662028747970656F66206F7074696F6E73203D3D3D20226F626A6563742229207B0A0920202020666F722028766172206E6478';
wwv_flow_api.g_varchar2_table(9) := '20696E2077656263616D29207B0A0909696620286F7074696F6E735B6E64785D20213D3D20756E646566696E656429207B0A09092020202077656263616D5B6E64785D203D206F7074696F6E735B6E64785D3B0A09097D0A09202020207D0A097D0A0A09';
wwv_flow_api.g_varchar2_table(10) := '76617220736F75726365203D20273C6F626A6563742069643D225877656263616D586F626A656374582220747970653D226170706C69636174696F6E2F782D73686F636B776176652D666C6173682220646174613D22272B77656263616D2E7377666669';
wwv_flow_api.g_varchar2_table(11) := '6C652B27222077696474683D22272B77656263616D2E77696474682B2722206865696768743D22272B77656263616D2E6865696768742B27223E3C706172616D206E616D653D226D6F766965222076616C75653D22272B77656263616D2E73776666696C';
wwv_flow_api.g_varchar2_table(12) := '652B2722202F3E3C706172616D206E616D653D22466C61736856617273222076616C75653D226D6F64653D272B77656263616D2E6D6F64652B2726616D703B7175616C6974793D272B77656263616D2E7175616C6974792B2722202F3E3C706172616D20';
wwv_flow_api.g_varchar2_table(13) := '6E616D653D22616C6C6F77536372697074416363657373222076616C75653D22616C7761797322202F3E3C2F6F626A6563743E273B0A0A09696620286E756C6C20213D3D2077656263616D2E65787465726E29207B0A0920202020242877656263616D2E';
wwv_flow_api.g_varchar2_table(14) := '65787465726E295B77656263616D2E617070656E64203F2022617070656E6422203A202268746D6C225D28736F75726365293B0A097D20656C7365207B0A0920202020746869735B77656263616D2E617070656E64203F2022617070656E6422203A2022';
wwv_flow_api.g_varchar2_table(15) := '68746D6C225D28736F75726365293B0A097D0A0A09285F7265676973746572203D2066756E6374696F6E2872756E29207B0A0A09202020207661722063616D203D20646F63756D656E742E676574456C656D656E744279496428275877656263616D586F';
wwv_flow_api.g_varchar2_table(16) := '626A6563745827293B0A0A09202020206966202863616D2E6361707475726520213D3D20756E646566696E656429207B0A0A09092F2A2053696D706C652063616C6C6261636B206D6574686F647320617265206E6F7420616C6C6F776564203A2D2F202A';
wwv_flow_api.g_varchar2_table(17) := '2F0A090977656263616D2E63617074757265203D2066756E6374696F6E287829207B0A090920202020747279207B0A09090972657475726E2063616D2E636170747572652878293B0A0909202020207D206361746368286529207B7D0A09097D0A090977';
wwv_flow_api.g_varchar2_table(18) := '656263616D2E73617665203D2066756E6374696F6E287829207B0A090920202020747279207B0A09090972657475726E2063616D2E736176652878293B0A0909202020207D206361746368286529207B7D0A09097D0A090977656263616D2E7365744361';
wwv_flow_api.g_varchar2_table(19) := '6D657261203D2066756E6374696F6E287829207B0A090920202020747279207B0A09090972657475726E2063616D2E73657443616D6572612878293B0A0909202020207D206361746368286529207B7D0A09097D0A090977656263616D2E67657443616D';
wwv_flow_api.g_varchar2_table(20) := '6572614C697374203D2066756E6374696F6E2829207B0A090920202020747279207B0A09090972657475726E2063616D2E67657443616D6572614C69737428293B0A0909202020207D206361746368286529207B7D0A09097D0A0A090977656263616D2E';
wwv_flow_api.g_varchar2_table(21) := '6F6E4C6F616428293B0A09202020207D20656C7365206966202830203D3D2072756E29207B0A090977656263616D2E646562756728226572726F72222C2022466C617368206D6F766965206E6F742079657420726567697374657265642122293B0A0920';
wwv_flow_api.g_varchar2_table(22) := '2020207D20656C7365207B0A09092F2A20466C61736820696E74657266616365206E6F7420726561647920796574202A2F0A090977696E646F772E73657454696D656F7574285F72656769737465722C2031303030202A202834202D2072756E292C2072';
wwv_flow_api.g_varchar2_table(23) := '756E202D2031293B0A09202020207D0A097D292833293B0A202020207D0A0A7D29286A5175657279293B0A';
null;
 
end;
/

 
begin
 
wwv_flow_api.create_plugin_file (
  p_id => 59337388920076001059 + wwv_flow_api.g_id_offset
 ,p_flow_id => wwv_flow.g_flow_id
 ,p_plugin_id => 58823121604776406111 + wwv_flow_api.g_id_offset
 ,p_file_name => 'jquery.webcam.js'
 ,p_mime_type => 'application/x-javascript'
 ,p_file_content => wwv_flow_api.g_varchar2_table
  );
null;
 
end;
/

commit;
begin 
execute immediate 'begin dbms_session.set_nls( param => ''NLS_NUMERIC_CHARACTERS'', value => '''''''' || replace(wwv_flow_api.g_nls_numeric_chars,'''''''','''''''''''') || ''''''''); end;';
end;
/
set verify on
set feedback on
set define on
prompt  ...done
