Copyright (c) 2012 Damien Antipa, http://www.nethead.at/, http://damien.antipa.at
This work is licensed under a Creative Commons Attribution-ShareAlike 3.0 Unported License. (http://creativecommons.org/licenses/by-sa/3.0/)

HOW TO USE APEX WEBCAM PLUGIN
=============================

1. Import it (=installation).

2. Add a new page item on a page. The type of this item must be the webcam plugin.

3. Modify the PL/SQL execution to insert the BLOB into a table.


credits to http://www.xarg.org/project/jquery-webcam-plugin/ for the use of this great webcam jquery plugin.



