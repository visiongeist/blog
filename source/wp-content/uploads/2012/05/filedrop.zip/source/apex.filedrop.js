var apexFiledrop = {
	$item			: null,
	saveFunction	: null,
	p_arg_names		: [],

	init : function (item, saveFunction, p_arg_names) {
		var t = this;

		t.$item = $(item);
		t.saveFunction = saveFunction;
		if (p_arg_names.length > 0) {
			t.p_arg_names = p_arg_names.split(',');
		}

		t.$item.filedrop({
			callback: t.send
		});
		t.$item.bind('dragover', function () {
			t.$item.addClass('nethead_dropfield_hover');
		}).bind('dragleave drop', function () {
			t.$item.removeClass('nethead_dropfield_hover');
		});
	},

	send : function (file) {
		var clobObj, clobState, reader, t = this;
		reader = new FileReader();

		clobObj = new apex.ajax.clob(function (p) {
			clobState = p.readyState;

			if (clobState === 4) {
				apexFiledrop.inform(file.name);
			}
		});

		reader.readAsDataURL(file);
		reader.onload = function (e) {
			clobObj._set(e.target.result);
		};
	},

	inform : function (filename) {
		var arg, t = this, p_arg_values = [];

		$.each(t.p_arg_names, function (i, val) {
			p_arg_values.push($v(val));
		});

		args = {
			p_flow_id			: $v("pFlowId"),
			p_flow_step_id		: $v("pFlowStepId"),
			p_instance			: $v("pInstance"),
			p_request			: 'PLUGIN=' + this.saveFunction,
			p_arg_names			: t.p_arg_names,
			p_arg_values		: p_arg_values
		};

		if (args.p_arg_names.length === 0) {
			delete args.p_arg_names;
			delete args.p_arg_values;
		}

		$.post(
			'wwv_flow.show',
			args,
			function (data) {
				apex.event.trigger(t.$item, 'filesaved', null);
			}
		);
	}
};