Filedrop, 1.0
=====================================
This plugin creates a droppable area to drop files from the client into the browser window. The dropped files will be sent to the server.
This plugin uses a HTML5 feature called File API (http://caniuse.com/fileapi) Browsers which do not support this feature will receive a proper error message.

TABLE OF CONTENTS
=================

* Installation and Update
* How to use
* Additional Details
* FAQ
* Uninstall
* Credits, License and Terms of Use
* Contact and Support
* Change Log


INSTALLATION AND UPDATE
=======================
1. Ensure you are running Oracle APEX version 4.1 or higher
2. Unzip and extract all files
2. Access your target Workspace
3. Select the Application Builder
4. Select the Application where you wish to import the plug-in 
   (plug-ins belong to an application, not a workspace)
5. Access Shared Components > Plug-Ins
6. Click [Import >]
7. Browse and locate the installer file, item_type_plugin_at_nethead_apex_filedrop.sql
8. Complete the wizard

If the plug-in already exists in that application, you will need to confirm that you 
want to replace it.  Also, once imported, this plug-in can be installed into additional
applications within the same workspace.  Simply navigate to the Export Repository 
(Export > Export Repository), click Install, and then select the target application.
Once the install file is no longer needed, it can be removed from the Export Repository.


HOW TO USE
==========
1. Install the plug-in (see INSTALLATION AND UPDATE)
2. Create a new page item
3. Pick "Plug-Ins" as type
4. Select the plug-in "Filedrop (1.0)"
5. Follow the wizard and use Item Level Help to get more information about the
   purpose and usage of the different settings.

Note that you can also update existing items to use this new item-type, once installed.


ADDITIONAL DETAILS
==================
The plugin has to two attributes on plugin level. The first one, the description, will be shown in the dropable area to indicate the end user that he can drop files into this area. The second attribute will be shown if the end user's browser doesn't support the HTML5 feature.

Another two attributes are available on the component level. The first one allows the developer to choose which page elements should be sent with a file upload. The elements are available as APEX variables (with $v or bin variable syntax) in the second attribute on component level. The second contains the PL/SQL process which is called when a file was sent to the server. It is the developer's responsibility to save the sent data to his models. With this method the plugin increases flexibility. I included an example process as a default value:

DECLARE
  c_collection_name   constant varchar2(200) := 'CLOB_CONTENT';
  l_blob              BLOB;
  l_mime              VARCHAR2(50);
BEGIN
  select apex_web_service.clobbase642blob(substr(clob001, instr(clob001, ',')+1, length(clob001))) 
  into l_blob
  from apex_collections
  where collection_name = c_collection_name;
  
  insert into table1(binary, filename, mime) values (l_blob, wwv_flow.g_x01, wwv_flow.g_x02);
END;

The SELECT statement reads the file into a BLOB. The parameter wwv_flow.g_x01 contains the filename and wwv_flow.g_x02 the mime type of the file. To test this plugin you can use my demo TABLE1:

CREATE table "TABLE1" (
    "ID"         NUMBER,
    "BINARY"     BLOB,
    "MIME"       VARCHAR2(50),
    "FILENAME"   VARCHAR2(200),
    constraint  "TABLE1_PK" primary key ("ID")
)
/

CREATE sequence "TABLE1_SEQ" 
/

CREATE trigger "BI_TABLE1"  
  before insert on "TABLE1"              
  for each row 
begin  
  if :NEW."ID" is null then
    select "TABLE1_SEQ".nextval into :NEW."ID" from dual;
  end if;
end;
/   

The plug-in support the following events:

  * Upload started:  Is called when the file upload starts.
  * Upload ended:  Is called after the file uploaded ended.

Both events receive a javascript object which contain the filename and the mimetype:
data.filename and data.mimetyp 

UNINSTALL
=========
To completely remove the plug-in:

1. Access the plug-in under Shared Components > Plug-Ins
2. Click [Delete]
   Note: If the [Delete] button doesn't show that indicates the plug-in is in use within the
         application.  Click on 'Utilization' under 'Tasks' to see where it is used.


CREDITS, LICENSE AND TERMS OF USE
=================================
Copyright (c) 2012 Damien Antipa, http://www.nethead.at/, http://damien.antipa.at

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


CONTACT AND SUPPORT
===================
Damien Antipa
damien.antipa@nethead.at
http://damien.antipa.at

CHANGE LOG
==========
v1.0 (12-May-2012)
-) Initial edit
